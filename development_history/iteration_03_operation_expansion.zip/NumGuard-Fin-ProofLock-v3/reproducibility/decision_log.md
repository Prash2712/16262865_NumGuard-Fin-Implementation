# Reproducibility decision log

## Frozen design decisions for v3

- Research question: table-aware proof-locked numeric decoding with useful coverage and derivation fidelity, without language-model fine-tuning.
- FinQA train is used only to fit the lightweight candidate selector.
- FinQA development is used for candidate gates, paired method evaluation and risk calibration.
- FinQA public test is executed once only after development gates pass.
- Model: `google/flan-t5-base` as the principal open-weight, logit-accessible baseline.
- Seed: 42.
- Numeric examples only.
- Retrieval limit: 24 evidence items after role- and period-protected row expansion.
- Candidate bounds: 24 direct, 96 derived and one abstention.
- Operation portfolio: one primary intent plus bounded alternatives licensed by explicit question wording.
- Whole-answer token-prefix trie is the principal hard-lock mechanism.
- Fragment-token masking is retained only as a weak ablation.
- Selector: class-balanced logistic regression with the frozen feature schema in `selector.py`.
- Selector grouping: source report/document during cross-validation.
- Selector training uses a 2× wider pre-pruning candidate pool; rescoring occurs before heuristic confidence floors and the frozen deployment bounds.
- Derived pruning reserves operation-family diversity before global score fill.
- Semantic risk target: 0.20 with 95% one-sided upper confidence bound.
- Provenance risk target: 0.01 with 95% one-sided upper confidence bound.
- Minimum calibration coverage: 0.05.
- Minimum accepted development examples: 30.
- Candidate gate: overall recall >= 0.30 and direct/aggregate recall >= 0.75.
- Public-test execution is blocked when the candidate gate or semantic calibration is infeasible.
- No threshold or selector retuning after public-test inspection.
- Reference answers are excluded from inference-time retrieval, candidate construction, prompts, certificates and decoding.
- Official FinQA programs are used only after lattice construction for selector labels or diagnostic operation/operand analysis.

## Preserved development decisions

- V1 showed strong sequence-lock containment but low candidate recall and zero feasible semantic-risk-controlled coverage.
- V2 failed its frozen development candidate gate at 27.44% overall recall and 45.71% direct/aggregate recall; model inference and public test were not run.
- Both are method-development findings, not final public-test results.

## Change control

Any code, selector, threshold, prompt, candidate-bound or retrieval change after an authorised public-test run creates a new exploratory configuration. The original frozen run and manifests must remain unchanged.
