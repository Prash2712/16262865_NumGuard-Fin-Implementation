from numguard_fin.cli import main

raise SystemExit(main([
    "fit-selector",
    "--data-dir", "data/raw",
    "--split", "train",
    "--retrieval-top-k", "24",
    "--max-direct-candidates", "24",
    "--max-derived-candidates", "96",
    "--folds", "5",
    "--seed", "42",
    "--output", "models/candidate_selector.json",
    "--rows-output", "results/selector_training_rows.csv",
]))
