from __future__ import annotations

import hashlib
import json
import math
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable, Optional

import numpy as np

from .candidates import AnswerCandidate, build_candidate_lattice
from .evidence import build_evidence_ledger
from .intent import parse_question_intent
from .numeric import numeric_equal, parse_single_number
from .retrieval import retrieve_evidence
from .schemas import FinQAExample


FEATURE_NAMES = (
    "heuristic_confidence",
    "retrieval",
    "metric_fit",
    "type_fit",
    "period_fit",
    "role_fit",
    "proof_valid",
    "operation_match",
    "proof_depth",
    "operand_count",
    "direct",
    "percentage_answer",
)


def candidate_feature_vector(candidate: AnswerCandidate) -> np.ndarray:
    values = dict(candidate.feature_values)
    values["heuristic_confidence"] = float(candidate.confidence)
    return np.asarray([float(values.get(name, 0.0)) for name in FEATURE_NAMES], dtype=float)


def _sigmoid(value: float) -> float:
    return 1.0 / (1.0 + math.exp(-max(-30.0, min(30.0, value))))


@dataclass(frozen=True)
class LinearCandidateSelector:
    coefficients: tuple[float, ...]
    intercept: float
    feature_names: tuple[str, ...] = FEATURE_NAMES
    metadata: dict[str, Any] | None = None

    def score(self, candidate: AnswerCandidate) -> float:
        vector = candidate_feature_vector(candidate)
        if len(vector) != len(self.coefficients):
            raise ValueError("Selector feature vector and coefficient lengths differ.")
        return _sigmoid(float(np.dot(vector, np.asarray(self.coefficients))) + self.intercept)

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema_version": 1,
            "feature_names": list(self.feature_names),
            "coefficients": list(self.coefficients),
            "intercept": self.intercept,
            "metadata": self.metadata or {},
        }

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> "LinearCandidateSelector":
        names = tuple(payload.get("feature_names", ()))
        if names != FEATURE_NAMES:
            raise ValueError(
                "Selector feature schema mismatch. Expected "
                f"{FEATURE_NAMES}, found {names}."
            )
        coefficients = tuple(float(value) for value in payload["coefficients"])
        if len(coefficients) != len(FEATURE_NAMES):
            raise ValueError("Invalid selector coefficient count.")
        return cls(
            coefficients=coefficients,
            intercept=float(payload["intercept"]),
            feature_names=names,
            metadata=dict(payload.get("metadata") or {}),
        )


def load_selector(path: str | Path | None) -> Optional[LinearCandidateSelector]:
    if not path:
        return None
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"Candidate selector not found: {path}")
    return LinearCandidateSelector.from_dict(json.loads(path.read_text(encoding="utf-8")))


def _candidate_label(candidate: AnswerCandidate, reference_answer: str | None) -> int:
    reference = parse_single_number(reference_answer or "")
    predicted = parse_single_number(candidate.answer)
    if reference is None or predicted is None:
        return 0
    return int(numeric_equal(reference, predicted, require_percent_compatibility=True))


def candidate_training_rows(
    examples: Iterable[FinQAExample],
    *,
    retrieval_top_k: int = 24,
    max_direct: int = 24,
    max_derived: int = 96,
    training_pool_multiplier: int = 2,
) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for example in examples:
        intent = parse_question_intent(example.question)
        ledger = build_evidence_ledger(example)
        retrieved = retrieve_evidence(
            ledger, example.question, intent, top_k=retrieval_top_k
        )
        # Fit on a wider pre-deployment pool so the selector learns about candidates
        # that heuristic-only frozen pruning would otherwise remove. Inference still uses
        # the disclosed 24/96 bounds after selector rescoring.
        lattice = build_candidate_lattice(
            retrieved,
            intent,
            include_derived=True,
            max_direct=max(max_direct, max_direct * training_pool_multiplier),
            max_derived=max(max_derived, max_derived * training_pool_multiplier),
            minimum_direct_confidence=0.0,
            minimum_derived_confidence=0.0,
        )
        for candidate in lattice.numeric_candidates():
            vector = candidate_feature_vector(candidate)
            row = {
                "example_id": example.example_id,
                "group": example.filename or example.example_id.split("-")[0],
                "candidate_id": candidate.candidate_id,
                "answer": candidate.answer,
                "label": _candidate_label(candidate, example.reference_answer),
            }
            row.update({name: float(value) for name, value in zip(FEATURE_NAMES, vector)})
            rows.append(row)
    return rows


def fit_linear_selector(
    rows: list[dict[str, Any]],
    *,
    seed: int = 42,
    folds: int = 5,
) -> tuple[LinearCandidateSelector, dict[str, Any]]:
    if not rows:
        raise ValueError("No candidate training rows were provided.")
    try:
        from sklearn.linear_model import LogisticRegression
        from sklearn.metrics import average_precision_score, roc_auc_score
        from sklearn.model_selection import GroupKFold
    except ImportError as exc:
        raise RuntimeError("scikit-learn is required to fit the candidate selector.") from exc

    X = np.asarray([[float(row[name]) for name in FEATURE_NAMES] for row in rows])
    y = np.asarray([int(row["label"]) for row in rows])
    groups = np.asarray([str(row["group"]) for row in rows])
    if y.sum() == 0:
        raise RuntimeError(
            "The candidate lattice recalled no training references; a selector cannot be fitted."
        )

    unique_groups = np.unique(groups)
    n_splits = min(folds, len(unique_groups))
    out_of_fold = np.full(len(rows), np.nan)
    fold_metrics: list[dict[str, Any]] = []
    if n_splits >= 2:
        splitter = GroupKFold(n_splits=n_splits)
        for fold, (train_idx, valid_idx) in enumerate(splitter.split(X, y, groups), start=1):
            if len(np.unique(y[train_idx])) < 2:
                continue
            model = LogisticRegression(
                class_weight="balanced", max_iter=2000, random_state=seed, C=0.5
            )
            model.fit(X[train_idx], y[train_idx])
            probabilities = model.predict_proba(X[valid_idx])[:, 1]
            out_of_fold[valid_idx] = probabilities
            fold_y = y[valid_idx]
            metrics: dict[str, Any] = {
                "fold": fold,
                "candidate_rows": int(len(valid_idx)),
                "positives": int(fold_y.sum()),
            }
            if len(np.unique(fold_y)) == 2:
                metrics["roc_auc"] = float(roc_auc_score(fold_y, probabilities))
                metrics["average_precision"] = float(average_precision_score(fold_y, probabilities))
            fold_metrics.append(metrics)

    model = LogisticRegression(
        class_weight="balanced", max_iter=2000, random_state=seed, C=0.5
    )
    model.fit(X, y)

    # Candidate-level probability quality is useful, but the operational diagnostic is
    # top-1 selection among candidates for the same question.
    scores = np.where(np.isnan(out_of_fold), model.predict_proba(X)[:, 1], out_of_fold)
    by_example: dict[str, list[int]] = {}
    for index, row in enumerate(rows):
        by_example.setdefault(str(row["example_id"]), []).append(index)
    recalled_examples = 0
    top1_correct = 0
    for indices in by_example.values():
        if y[indices].max() == 0:
            continue
        recalled_examples += 1
        best = max(indices, key=lambda index: (scores[index], -index))
        top1_correct += int(y[best] == 1)

    selector = LinearCandidateSelector(
        coefficients=tuple(float(value) for value in model.coef_[0]),
        intercept=float(model.intercept_[0]),
        metadata={},
    )
    report = {
        "training_candidate_rows": len(rows),
        "training_examples": len(by_example),
        "positive_candidate_rows": int(y.sum()),
        "candidate_recall_on_training_examples": recalled_examples / max(1, len(by_example)),
        "top1_accuracy_given_candidate_recall": top1_correct / max(1, recalled_examples),
        "grouped_cross_validation": fold_metrics,
        "seed": seed,
        "feature_names": list(FEATURE_NAMES),
    }
    payload = selector.to_dict()
    payload["metadata"] = report
    digest = hashlib.sha256(json.dumps(payload, sort_keys=True).encode("utf-8")).hexdigest()
    report["selector_sha256"] = digest
    selector = LinearCandidateSelector(
        coefficients=selector.coefficients,
        intercept=selector.intercept,
        metadata=report,
    )
    return selector, report
