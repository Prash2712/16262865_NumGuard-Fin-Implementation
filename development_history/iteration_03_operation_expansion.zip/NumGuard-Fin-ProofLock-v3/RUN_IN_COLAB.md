# Exact Google Colab workflow for ProofLock v3

Use a fresh GPU runtime. Keep v3 in a new Google Drive folder and do not copy v1/v2 selectors, checkpoints, calibration files or result directories into it.

## 1. Mount Drive

```python
from google.colab import drive
drive.mount('/content/drive')
```

## 2. Enter the v3 project folder

```bash
%cd "/content/drive/MyDrive/NumGuard-Fin-ProofLock-v3"
!pwd
!ls
```

Do not unzip again after results or checkpoints exist.

## 3. Install the runtime environment

```bash
!python -m pip install -q -r requirements.txt
!python -m pip install -q -e . --no-deps
```

```python
import os, sys, importlib
from pathlib import Path

PROJECT = Path('/content/drive/MyDrive/NumGuard-Fin-ProofLock-v3')
SRC = PROJECT / 'src'
os.chdir(PROJECT)
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))
os.environ['PYTHONPATH'] = str(SRC)
importlib.invalidate_caches()

import numguard_fin
print(numguard_fin.__version__)
print(numguard_fin.__file__)
```

Expected version: `3.0.0`.

## 4. Confirm CUDA

Select **Runtime → Change runtime type → T4 GPU** and run:

```python
import torch
print('CUDA available:', torch.cuda.is_available())
print('GPU:', torch.cuda.get_device_name(0) if torch.cuda.is_available() else 'NO GPU')
assert torch.cuda.is_available(), 'CUDA is not active.'
```

```bash
!nvidia-smi
```

## 5. Engineering verification

```bash
!bash run_local_verification.sh
```

Required final status:

```text
133 passed
QUALITY GATE PASSED
```

Editable installation creates untracked metadata. Remove only that generated directory before checking the source manifest:

```bash
!rm -rf src/numguard_fin.egg-info
!python scripts/verify_source_manifest.py
```

Required: `SOURCE MANIFEST PASSED`.

## 6. Download official FinQA and run preflight

```bash
!python scripts/download_finqa.py
!ls -lh data/raw
!python scripts/preflight.py --require-cuda
```

Required preflight fields:

```text
"status": "passed"
"problems": []
```

## 7. Fit a fresh train-only candidate selector

```bash
!mkdir -p results models
!set -o pipefail; bash run_colab_train_selector.sh 2>&1 | tee -a results/selector_training_v3.log
```

Inspect:

```bash
!ls -lh models/candidate_selector.json
!cat models/candidate_selector_training_report.json
!tail -n 100 results/selector_training_v3.log
```

Do not reuse the v2 selector. The v3 feature meanings and candidate population differ.

## 8. Run the development candidate gate and conditional model experiment

```bash
!set -o pipefail; bash run_colab_dev.sh 2>&1 | tee -a results/dev_v3_execution.log
```

The script first runs a CPU candidate diagnostic. It creates:

```text
results/dev_candidate_diagnostic/dataset_audit.csv
results/dev_candidate_diagnostic/candidate_quality_gate.json
```

The audit contains final, pre-selector, unpruned-same-retrieval and full-ledger recall, plus operand coverage and failure-stage labels.

### Gate failure

When the output contains:

```text
CANDIDATE QUALITY GATE FAILED — do not run the expensive model experiment.
```

stop. Do not rerun, weaken the thresholds or run the public test. Package:

```bash
!zip -qr NumGuard_v3_Dev_Gate_Evidence.zip \
  results/dev_candidate_diagnostic \
  models/candidate_selector.json \
  models/candidate_selector_training_report.json \
  results/selector_training_v3.log \
  results/dev_v3_execution.log
!sha256sum NumGuard_v3_Dev_Gate_Evidence.zip
```

### Gate pass

When the candidate gate passes, the same script continues into the full FLAN-T5 development experiment and development-only calibration. Leave the cell running.

The public test is authorised only when the exact final line is:

```text
SEMANTIC CALIBRATION GATE PASSED. The frozen public-test script is now authorised.
```

Any semantic calibration failure keeps the public test blocked.

## 9. Run the frozen public test once, only after authorisation

```bash
!set -o pipefail; bash run_colab_test.sh 2>&1 | tee -a results/final_test/execution.log
!python scripts/run_counterfactual_audit.py
```

The script verifies selector, development manifest, calibration feasibility, coverage, accepted-example count, configuration identity and file hashes before test inference.

## 10. Resume after a Colab disconnect

A new runtime requires only:

1. remount Drive;
2. return to the v3 folder;
3. reinstall dependencies and editable package;
4. restore `sys.path`/`PYTHONPATH`;
5. confirm CUDA;
6. rerun the interrupted script.

The model run uses matching-configuration checkpoints through `--resume`. Do not delete or re-extract the project folder while a run is incomplete.

## 11. Package the final evidence

```bash
!zip -qr NumGuard_Fin_ProofLock_v3_Evidence.zip \
  results/dev_candidate_diagnostic \
  results/dev_calibration \
  results/final_test \
  figures/dev_calibration \
  figures/final_test \
  models \
  reproducibility \
  verification \
  reports
!sha256sum NumGuard_Fin_ProofLock_v3_Evidence.zip
```

Upload the whole evidence ZIP for audit. Screenshots or summary tables alone are not sufficient for checking candidate recall, calibration, proof validity, counterfactual behaviour and paired statistics.
