# NumGuard-Fin ProofLock v3

**Role-balanced, proof-locked numerical decoding with failure-stage diagnostics for financial question answering.**

Research question:

> Can a table-aware, proof-locked decoding lattice reduce unsupported numerical generation while preserving useful answer coverage and derivation fidelity in financial question answering, without fine-tuning the language model?

## Why v3 exists

The official ProofLock v2 development candidate gate failed before model inference. On 871 numeric FinQA development examples, the frozen v2 lattice achieved:

- final candidate recall: **27.44%** against a 30% minimum;
- direct/aggregate reference recall: **45.71%** against a 75% minimum;
- expanded-ledger diagnostic recall: approximately **30.5%**.

The gate correctly prevented an expensive FLAN-T5 development run and blocked the public test. V3 responds to the diagnosed mechanisms rather than lowering the thresholds:

1. question-operation precedence is corrected for ratio, margin, cumulative-return and cross-period aggregate wording;
2. retrieval uses protected role and period slots instead of globally re-truncating a provisional row-complete set;
3. the operation lattice contains a bounded primary-plus-alternative portfolio;
4. selector training uses a wider pre-pruning candidate pool and learned rescoring occurs before heuristic confidence floors and the frozen deployment bounds;
5. derived-candidate pruning reserves representation across proof-operation families;
6. the development audit identifies extraction, retrieval, operation-schema, candidate-generation, pruning and selector failure stages separately.

The v2 failure evidence is documented in `reports/dev_diagnostic_v2_findings.md`. It remains development evidence, not a public-test finding.

## Architecture

For each question, ProofLock v3 constructs:

1. **Structured Financial Evidence Ledger** — source value, base value, table row, column, period, metric, scale, currency and stable evidence ID.
2. **Question Intent** — expected operation, alternative licensed operations, metric terms, periods, numerator and denominator roles, entity terms, scale and explicit constants.
3. **Role-balanced Retrieval** — protected numerator/denominator rows and requested-period cells, followed by bounded global fill.
4. **Typed Proof Lattice** — direct lookup, difference, percentage change, indexed return, ratio, percentage-of-total/margin, sum, average, product, table sum, table average, minimum and maximum.
5. **Whole-sequence Proof Lock** — complete certified answer strings form a token-prefix trie; fragment-token masking is retained only as a weak ablation.
6. **Proof Certificate** — accepted answers carry evidence claims, operand IDs, operation, expression, answer type and candidate confidence.
7. **Calibrated Abstention** — development-only semantic and provenance risk calibration; zero-coverage or statistically infeasible thresholds do not authorise the public test.

The frozen default lattice is bounded to **24 direct numeric candidates, 96 derived numeric candidates and one exact abstention sequence**.

## Experimental conditions

The paired experiment includes:

1. `baseline`
2. `provenance_prompt`
3. `candidate_menu_prompt`
4. `posthoc_verifier`
5. `fragment_token_lock_ablation`
6. `soft_prefix_bias_1`
7. `soft_prefix_bias_3`
8. `soft_prefix_bias_5`
9. `soft_prefix_bias_10`
10. `direct_proof_lock`
11. `derivation_proof_lock`
12. `risk_controlled_proof_lock`

## Frozen split protocol

- **FinQA train:** fit only the lightweight candidate selector.
- **FinQA development:** candidate-quality gate, FLAN-T5 development experiment and risk calibration.
- **FinQA public test:** run once only after the development script prints the explicit authorisation line.

Reference answers and programs are never supplied to retrieval, candidate construction, prompting or decoding. They are used only after lattice construction for training labels on train or evaluation/gate labels on development and test.

## Local engineering verification

```bash
python -m pip install -r requirements.txt
python -m pip install -e . --no-deps
bash run_local_verification.sh
```

Expected engineering status:

```text
133 passed
QUALITY GATE PASSED
```

The source manifest is checked separately after removing generated editable-install metadata:

```bash
rm -rf src/numguard_fin.egg-info
python scripts/verify_source_manifest.py
```

Engineering fixtures are transparent mechanism tests. They are **not** official FinQA/FLAN-T5 findings.

## Official Colab sequence

Follow `RUN_IN_COLAB.md` or `notebooks/NumGuard_Fin_Colab.ipynb` exactly:

```text
engineering verification
→ FinQA download and preflight
→ train-only selector fitting
→ development candidate-quality gate
→ development model run only if the gate passes
→ semantic and provenance calibration
→ public test only after explicit authorisation
```

Do not reuse v1 or v2 selectors, checkpoints, calibration files or result directories in v3.

## Main outputs

Development candidate diagnostic:

```text
results/dev_candidate_diagnostic/dataset_audit.csv
results/dev_candidate_diagnostic/candidate_quality_gate.json
```

Development experiment:

```text
results/dev_calibration/predictions.csv
results/dev_calibration/predictions.jsonl
results/dev_calibration/method_summary.csv
results/dev_calibration/paired_comparisons.csv
results/dev_calibration/research_tables.xlsx
results/dev_calibration/calibration.json
results/dev_calibration/provenance_calibration.json
```

Frozen public test, only when authorised:

```text
results/final_test/predictions.csv
results/final_test/predictions.jsonl
results/final_test/method_summary.csv
results/final_test/paired_comparisons.csv
results/final_test/research_tables.xlsx
results/final_test/failure_review_blinded.xlsx
results/final_test/failure_review_key.csv
results/final_test/counterfactual_candidate_mechanism.csv
results/final_test/counterfactual_model_output.csv
figures/final_test/
```

## Scientific claim boundary

ProofLock can guarantee that a committed hard-locked answer belongs to its certified lattice. It cannot guarantee that the selected certified derivation is semantically correct. Final dissertation claims must therefore report both:

- **provenance risk:** whether an answer lacks a valid certificate;
- **semantic risk:** whether the answer is numerically wrong for the question.

No regulatory-compliance, universal-safety or production-readiness claim is supported by this artefact.
