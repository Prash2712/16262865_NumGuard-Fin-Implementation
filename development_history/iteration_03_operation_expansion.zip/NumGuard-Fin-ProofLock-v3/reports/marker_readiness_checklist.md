# Marker readiness checklist

## V3 package assurance

- [ ] Clean extraction produces at least 133 passing tests.
- [ ] Engineering quality gate passes.
- [ ] Source checksum manifest passes.
- [ ] No official FinQA data, model weights or fabricated empirical results are bundled.
- [ ] V1 and v2 diagnostic findings are clearly labelled development-only.

## Train and development

- [ ] FinQA train/dev/test hashes are recorded.
- [ ] Candidate selector is fitted on train only.
- [ ] Selector report and SHA-256 are retained.
- [ ] Development candidate gate passes before model inference.
- [ ] Development predictions contain equal paired method/example counts.
- [ ] Semantic and provenance calibration files are separate.
- [ ] Semantic calibration is feasible with at least 5% coverage and 30 accepted examples.
- [ ] No threshold is manually edited.

## Frozen public test

- [ ] Public test is run once only after the authorisation message.
- [ ] Selector and calibration hashes match development artefacts.
- [ ] No mixed configuration IDs or duplicate rows exist.
- [ ] Hard proof locks have zero unsupported non-abstention outputs.
- [ ] Every committed hard-lock answer includes evidence claims.
- [ ] Candidate/mechanism and model-output counterfactual audits are complete.

## Analysis

- [ ] Main table reports accuracy, semantic risk, provenance risk and coverage together.
- [ ] Confidence intervals and paired effect estimates are included.
- [ ] Candidate recall is separated from conditional selection accuracy.
- [ ] V1/v2-to-v3 comparison uses identical definitions or states differences.
- [ ] Coarse operation agreement is not called official program accuracy.
- [ ] Manual taxonomy uses the blinded workbook, not automatic suggestions.
- [ ] Worked examples include success, ranking error, candidate-recall failure, correct abstention and counterfactual failure.

## Claims and limitations

- [ ] Every headline statement satisfies the claim–evidence register.
- [ ] Findings are limited to the dataset, model and frozen configuration.
- [ ] No regulatory compliance guarantee is made.
- [ ] Proof validity is not equated with semantic correctness.
- [ ] Zero coverage is not presented as successful risk control.
- [ ] Null or negative findings are reported.
- [ ] Fixture outputs are excluded from the empirical results chapter.

## Reproducibility

- [ ] Exact commands, package versions, hardware and model revision are recorded.
- [ ] `example_ids.txt` and digest are retained.
- [ ] Dataset, selector, calibration and source hashes are retained.
- [ ] Final evidence archive opens and contains all declared files.
