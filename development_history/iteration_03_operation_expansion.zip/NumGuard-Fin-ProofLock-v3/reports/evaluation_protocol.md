# Evaluation protocol

## Split discipline

1. **Train:** fit the lightweight candidate selector using candidate correctness labels. FLAN-T5 is not fine-tuned.
2. **Development candidate gate:** audit candidate recall before expensive model inference.
3. **Development paired run:** evaluate all methods on the same ordered numeric examples.
4. **Development calibration:** select semantic- and provenance-risk thresholds under explicit non-zero coverage gates.
5. **Configuration freeze:** freeze source manifest, selector hash, configuration ID and calibration files.
6. **Public test:** execute the frozen configuration once. Any later change is labelled exploratory.

## Development gates

The default candidate gate requires:

- overall candidate recall of at least `0.30`;
- direct/aggregate reference recall of at least `0.75`.

The semantic calibration gate requires:

- target semantic risk `<= 0.20` under a 95% one-sided Clopper–Pearson upper bound;
- coverage `>= 0.05`;
- at least 30 accepted development examples.

The provenance calibration is reported separately with target risk `<= 0.01` under the same minimum-coverage and sample-size gates.

Failure of either upstream candidate gate or semantic calibration prevents the public-test script from running. A threshold above 1 with zero accepted answers is recorded as **infeasible**, not as a successful zero-risk operating point.

## Units and pairing

The principal unit is a numeric FinQA question. Every method uses the same ordered example IDs. The experiment writes `example_ids.txt`, its SHA-256 digest, dataset hash, selector hash, hardware details and configuration ID into the manifest.

## Methods

1. baseline;
2. provenance prompt;
3. candidate-menu prompt;
4. post-hoc verifier;
5. fragment-token lock ablation;
6. soft prefix bias 1;
7. soft prefix bias 3;
8. soft prefix bias 5;
9. soft prefix bias 10;
10. direct proof lock;
11. derivation proof lock;
12. risk-controlled proof lock.

## Primary outcomes

- numeric answer accuracy;
- valid numeric response rate;
- explicit abstention rate;
- invalid or fragmentary response rate;
- unsupported complete-answer rate;
- unsupported rate conditional on a valid numeric response;
- proof validity conditional on a valid numeric response;
- candidate recall;
- candidate selection accuracy conditional on recall;
- selected-candidate confidence and margin;
- semantic risk and provenance risk conditional on commitment;
- abstention precision and recall for unrecalled or incorrect cases;
- risk–coverage and accuracy–coverage curves;
- mean and 95th-percentile end-to-end latency;
- prompt token count and truncation rate.

No-number free text is invalid unless it exactly matches the declared abstention sequence.

## Operation diagnostic

FinQA annotated programs and selected proof certificates are mapped into coarse operation families. `proof_operation_match` is an operation-family diagnostic, not official FinQA program accuracy. Multi-step derivation fidelity is additionally inspected through the proof expression, operands and evidence claims.

## Statistical treatment

- 2,000 percentile-bootstrap resamples with seed 42;
- paired method-minus-baseline confidence intervals for numeric accuracy and unsupported answers;
- exact McNemar tests for paired binary outcomes;
- effect sizes and confidence intervals reported before isolated p-values;
- secondary analyses identified as exploratory;
- no threshold retuning on public-test outcomes.

## Counterfactual audit

Two layers are kept separate.

### Candidate-mechanism audit

Tests whether retrieval and the proof lattice respond to controlled evidence changes independently of model selection.

### Model-output audit

Runs the frozen risk-controlled method on original and perturbed examples and checks the actual answer and certificate.

Perturbations include:

- irrelevant-number injection;
- year-value swap;
- metric-value swap;
- support masking;
- scale change.

Applicability, denominator and pass rate are reported for each perturbation and layer. Passing a synthetic engineering fixture is assurance of implementation behaviour, not an official FinQA empirical result.

## Manual failure analysis

A stratified sample is written to `failure_review_blinded.xlsx`. Method identity and automatic routing suggestions are stored separately in `failure_review_key.csv`. The manual taxonomy distinguishes retrieval, extraction, intent, candidate recall, operand, operation, scale/unit, rounding, ranking, constraint escape, correct abstention, over-refusal, under-refusal and annotation ambiguity. Frequencies are not treated as findings until manual review is completed.

## Integrity validation

The validator rejects:

- missing scientific fields or blank responses;
- duplicate or unequal method/example pairs;
- mixed configuration IDs;
- candidate lattices above 24 direct + 96 derived + abstention;
- hard-lock constraint escapes;
- uncertified hard-lock numeric answers;
- invalid hard-lock fragments;
- empirical outputs produced by the deterministic engineering selector;
- missing selector/calibration provenance;
- legacy submission columns or synthetic identifiers.
