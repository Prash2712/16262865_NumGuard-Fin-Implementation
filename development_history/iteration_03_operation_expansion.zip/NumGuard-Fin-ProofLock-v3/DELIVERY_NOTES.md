# Delivery notes — ProofLock v3

## Delivered artefact

This package is a clean v3 research implementation. It contains source code, tests, transparent fixtures, execution scripts, documentation and local engineering-assurance outputs. It excludes official FinQA files, model weights, v1/v2 checkpoints and manufactured empirical results.

## Evidence that triggered v3

The official v2 development candidate gate failed before model inference:

- candidate recall: 27.44% (minimum 30%);
- direct/aggregate recall: 45.71% (minimum 75%);
- public test: correctly blocked.

The failure archive supplied by the student was used to identify retrieval truncation, operation misclassification, pre-selector pruning and operation-family monopolisation.

## V3 changes

- role- and period-protected evidence retrieval;
- corrected intent precedence and bounded alternative operations;
- indexed-return proof template;
- selector-before-pruning ordering;
- operation-diverse derived pruning;
- 24 direct + 96 derived + abstention frozen bounds;
- final/pre-selector/unpruned/full-ledger candidate diagnostics;
- operand-coverage and failure-stage audit columns;
- twelve additional v3 regression tests;
- strict public-test block remains unchanged.

## Verified locally

- 133 unit and integration tests;
- transparent candidate/proof fixtures;
- whole-sequence constraint integrity;
- structured proof-certificate checks;
- candidate-mechanism counterfactual checks;
- report and manifest checks.

These checks establish engineering integrity only. No official v3 train/dev/test run was executed in the delivery environment.

## Student execution rule

Run a fresh v3 selector fit and the inexpensive development candidate gate. Do not run FLAN-T5 development inference unless the candidate gate passes. Do not run the public test unless `run_colab_dev.sh` prints:

```text
SEMANTIC CALIBRATION GATE PASSED. The frozen public-test script is now authorised.
```

A failed gate is a valid research result and must not be bypassed or weakened after observing development evidence.
