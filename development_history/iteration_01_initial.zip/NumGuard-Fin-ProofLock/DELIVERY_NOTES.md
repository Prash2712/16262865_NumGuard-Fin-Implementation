# Delivery notes

## What is included

- Clean Python research package with no bundled FinQA data or model weights.
- Structured numeric evidence ledger and finance-aware retrieval.
- Bounded direct and derivation proof lattice.
- Whole-sequence hard lock, soft-bias curve, fragment-mask ablation and post-hoc verifier.
- Development-calibrated selective abstention.
- Nested proof certificates with full evidence claims.
- Paired evaluation, confidence intervals, McNemar tests and latency/truncation reporting.
- Candidate-mechanism and model-output counterfactual audits.
- Blinded manual failure-review package and separate key.
- Colab notebook, command scripts, resume checkpoints, preflight and integrity validator.
- Transparent engineering fixtures and local assurance report.

## What is deliberately not included

- No manufactured FLAN-T5 or official FinQA result tables.
- No previous prototype results.
- No official FinQA files or model weights.
- No claim that local deterministic fixtures represent empirical performance.

## Required execution sequence

```bash
pip install -r requirements.txt
pip install -e . --no-deps
export PYTHONPATH="$PYTHONPATH:src"
./run_local_verification.sh
python scripts/download_finqa.py
python scripts/preflight.py --require-cuda
./run_colab_dev.sh
./run_colab_test.sh
```

The development run selects and freezes the abstention threshold. The public-test run is the final empirical experiment. Upload the resulting evidence archive for independent result review before drafting the findings chapter.
