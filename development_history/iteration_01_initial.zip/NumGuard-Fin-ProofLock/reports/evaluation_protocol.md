# Evaluation protocol

## Split discipline

1. **Development split:** inspect candidate recall, run every paired method and select the risk threshold.
2. **Configuration freeze:** model, seed, retrieval, candidate bounds, prompt limits, threshold and method list are fixed and identified by a configuration hash.
3. **Public test split:** execute the frozen configuration once for final reporting.
4. Training data is not used for headline evaluation.

## Units of analysis

The principal unit is a numeric FinQA question. Every method is evaluated on the same ordered example IDs. The run writes `example_ids.txt` and its SHA-256 digest into the experiment manifest so pairing can be audited independently.

## Primary outcomes

- Numeric answer accuracy.
- Valid numeric response rate.
- Non-abstention and abstention rates.
- Invalid or fragmentary response rate.
- Unsupported complete-answer rate.
- Unsupported rate conditional on a valid numeric response.
- Proof validity conditional on a valid numeric response.
- Candidate recall.
- Selection accuracy conditional on candidate recall.
- Accuracy and risk conditional on a valid numeric response.
- Abstention precision and recall for unrecalled references.
- Area under the risk–coverage curve.
- Mean and 95th-percentile end-to-end method latency.
- Prompt input-token count and truncation rate.

No-number responses are not awarded perfect provenance. Invalid text fragments are separated from explicit abstention.

## Derivation diagnostic

FinQA supplies annotated programs. The package maps both the annotation and the selected proof into a coarse operation family such as lookup, difference, percentage change, ratio, sum or average. The resulting `proof_operation_match` is a **diagnostic of operation-family agreement**. It is not the official FinQA program-accuracy metric and must not be reported as such.

## Statistical treatment

- Percentile bootstrap confidence intervals use 2,000 resamples with seed 42.
- Paired bootstrap intervals report method-minus-baseline effects for numeric accuracy and unsupported complete answers.
- Exact McNemar tests compare paired binary outcomes with the baseline.
- Effect sizes and confidence intervals take precedence over isolated p-values.
- Multiple comparisons and the exploratory status of secondary outcomes must be acknowledged in the report.

## Safety–coverage analysis

The soft-prefix conditions create a constraint-strength curve. The risk-controlled proof lock uses a development-selected confidence threshold based on an upper confidence bound for selective risk. The threshold is frozen before the public-test experiment. Coverage loss, over-refusal and invalid outputs are reported alongside safety gains.

## Counterfactual provenance audit

Two layers are reported separately.

### Candidate-mechanism audit

Tests whether retrieval, candidate construction and the proof lattice respond appropriately to controlled evidence changes without involving model selection.

### Model-output audit

Runs the frozen `risk_controlled_proof_lock` on the original and perturbed examples and compares the actual response and proof certificate.

Perturbations:

- irrelevant-number injection — response and proof should remain invariant;
- year-value swap — response or proof should follow the requested period;
- metric-value swap — response or proof should follow row semantics;
- support masking — response should change or become an explicit abstention;
- scale flip — the scale in the proof certificate should change.

Only applicable perturbations are generated. Pass rates, denominators and worked examples are reported by perturbation and audit layer.

## Manual failure analysis

A stratified sample is written to `failure_review_blinded.xlsx`. Method identity and automatic routing suggestions are kept separately in `failure_review_key.csv`. Manual labels, evidence locations, reviewer confidence and ambiguous cases must be completed before taxonomy frequencies are treated as findings. A double-coded subset should be used to report inter-review agreement.

## Integrity checks

The validator rejects:

- missing scientific fields or blank model responses;
- legacy submission columns;
- synthetic/engineering identifiers in empirical outputs;
- duplicate or unequal method/example pairs;
- mixed configuration IDs;
- candidate lattices above the declared bound;
- unsupported or uncertified non-abstention outputs from hard proof locks;
- retained uncertified numeric outputs from the post-hoc verifier;
- empirical claims produced by the deterministic engineering selector;
- prompt and timing fields missing from empirical records.
