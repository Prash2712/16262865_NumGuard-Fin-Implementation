# Research design

## Aim

The experiment tests an inference-stage numeric safety mechanism rather than model training. The independent variable is the answer-control strategy; all paired conditions use the same FinQA examples, retrieved evidence, frozen model, decoding seed and candidate construction rules.

## Mechanism

### Structured evidence ledger

Every extracted number retains its exact source location and financial context. Table values record row and column coordinates, labels, reporting period, currency and scale. Narrative values record sentence and character locations. Whole-number parsing preserves years and long integers and handles percentages, leading decimals, comma grouping and negative parentheses.

### Question-conditioned proof lattice

The question parser identifies a bounded operation schema: direct lookup, subtraction, percentage change, addition, average, ratio, margin or multiplication. Candidate derivations are generated only when the selected operands satisfy operation, period, metric and unit constraints. The default maximum is 12 direct candidates and 20 derived candidates.

### Whole-sequence proof lock

Each certified answer is tokenised as a complete sequence. A prefix trie rejects a decoder token whenever the new prefix cannot lead to a complete candidate. The exact abstention response is also a legal terminal sequence.

### Calibrated abstention

The development split selects a confidence threshold using an upper confidence bound on selective risk. The threshold is frozen before the public-test run. This separates model development from final evaluation.

## Causal interpretation

Because all conditions are paired on identical examples and evidence, differences can be attributed to the answer-control strategy under the stated implementation. The study does not isolate every source of error: retrieval failure, intent classification and candidate construction remain upstream mediators.

## Primary hypotheses

- H1: whole-sequence proof locking reduces unsupported complete-answer generation relative to unconstrained generation.
- H2: whole-sequence locking produces fewer constraint escapes than fragment-level token masking.
- H3: derivation-aware locking increases candidate recall relative to direct-only locking, with a possible increase in selection risk.
- H4: calibrated abstention reduces risk among committed numeric answers at the cost of coverage.
- H5: correct provenance is sensitive to period, metric, scale and support perturbations but invariant to irrelevant-number injection.

## Scope

The claims are restricted to numeric FinQA questions, the selected frozen model and the disclosed retrieval and candidate rules. No human participants, private financial records or model fine-tuning are used.
