# Numeric normalisation and derivation rules

## Number parsing

The parser consumes a complete numeric span. It does not split a four-digit year or long integer into token fragments.

Supported forms include:

- integers and decimals;
- leading decimals such as `.5`;
- comma-grouped numbers;
- explicit plus/minus signs;
- accounting negatives in parentheses;
- currency symbols;
- percent and percentage suffixes;
- thousand, million, billion and trillion scales.

Each number stores both its displayed value and, when a scale exists, a base-unit value. Displayed values are used for FinQA answer comparison; base values support scale audits.

## Equality

Numeric comparison uses an absolute tolerance of `0.01` and a relative tolerance of `0.005`. Percentage compatibility is required: `12.45` is not treated as equivalent to `12.45%`. Tolerances are fixed before final evaluation.

## Direct proof

A direct candidate must originate from retrieved evidence and retain a source identifier. Metric and period matching influence confidence. A period-only match is heavily penalised when the question names a financial metric.

## Derivation schemas

### Subtraction

For questions containing ordered periods, later minus earlier is enforced. Absolute change is applied only when explicitly requested.

### Percentage change

```text
(new - old) / old * 100
```

The old and new operands follow the ordered periods in the question.

### Addition and average

Operands must share the requested metric or both strongly match the same question metric. Currency and scale must be compatible.

### Ratio

Operand order follows question order when periods are stated. Division by zero is rejected.

### Margin

The numerator must be an income, profit or earnings metric; the denominator must be revenue or sales. The result is multiplied by 100.

### Product

Multiplication is enabled only when the question explicitly requests a product or multiplication.

## Bounds

Candidate construction is capped at 12 direct and 20 derived values by default. This prevents the proof lattice from becoming an unrestricted arithmetic search space.

## Abstention

`INSUFFICIENT_EVIDENCE` is the sole hard-lock abstention sequence. It is not scored as a valid numeric response or a valid numeric proof.
