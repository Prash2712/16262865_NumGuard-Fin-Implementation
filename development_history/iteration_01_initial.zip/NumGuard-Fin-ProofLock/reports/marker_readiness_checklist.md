# Marker readiness checklist

## Technical artefact

- [ ] All local tests and the quality gate pass from a clean extraction.
- [ ] FinQA manifest contains train/dev/test SHA-256 values.
- [ ] Development threshold is saved before public-test execution.
- [ ] Public-test predictions contain one row per method/example pair.
- [ ] No mixed configuration IDs or duplicate rows.
- [ ] Hard proof locks have no unsupported non-abstention outputs.
- [ ] Every hard-lock committed response includes evidence claims.
- [ ] Prompt truncation and end-to-end latency are reported.
- [ ] Candidate and model-output counterfactual audits are complete.

## Analysis

- [ ] Main table reports accuracy, safety and coverage together.
- [ ] Confidence intervals and paired effect estimates are included.
- [ ] Soft-strength curve is interpreted rather than merely displayed.
- [ ] Candidate recall is separated from selection accuracy.
- [ ] Coarse operation agreement is not called official program accuracy.
- [ ] Manual taxonomy is based on the blinded sheet, not automatic suggestions.
- [ ] Worked examples include success, over-refusal, candidate-recall failure and counterfactual failure.

## Claims and limitations

- [ ] Every headline statement satisfies the claim–evidence register.
- [ ] Findings are limited to FinQA, FLAN-T5 and the frozen configuration.
- [ ] No EU AI Act compliance claim is made.
- [ ] A valid proof is not equated with semantic correctness.
- [ ] Null or negative findings are reported transparently.
- [ ] Engineering fixture outputs are excluded from the results chapter.

## Reproducibility

- [ ] Exact command, package versions, hardware and model revision are recorded.
- [ ] `example_ids.txt` and its digest are retained.
- [ ] Source checksum manifest matches the submitted package.
- [ ] Final evidence archive opens and contains all declared files.
