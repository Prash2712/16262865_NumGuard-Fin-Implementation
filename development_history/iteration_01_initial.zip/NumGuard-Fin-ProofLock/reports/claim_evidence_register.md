# Claim–evidence register

This register prevents conclusions from being written before the corresponding evidence passes validation.

| Candidate claim | Required evidence | Decision rule | Prohibited overclaim |
|---|---|---|---|
| Whole-sequence proof locking reduces unsupported numeric emission | Public-test paired comparison: `direct_proof_lock` or `derivation_proof_lock` versus `baseline` | Directional reduction, paired effect interval reported, hard-lock constraint escapes equal zero | “The model cannot hallucinate” |
| Sequence locking is stronger than fragment masking | `fragment_token_lock_ablation` versus hard proof locks | Lower unsupported complete-answer rate and documented fragment escape examples, or an honest null finding | “All token constraints are equivalent” |
| Derivation-aware locking improves candidate availability | Direct versus derivation candidate recall | Higher recall with confidence interval; selection-risk cost reported | “Derivation guarantees correctness” |
| Calibrated abstention reduces committed-answer risk | Development threshold plus frozen public-test risk–coverage result | Public-test risk at/near target with coverage reported; calibration shortfall acknowledged | “Abstention solves errors” |
| Certificates are auditable | Proof-validity rate, certificate fields and manually inspected examples | Every hard-lock committed response has a valid complete certificate | “A certificate proves the dataset answer is correct” |
| Decisions depend on correct evidence | Candidate-mechanism and model-output counterfactual audits | Pass rates reported separately by perturbation and denominator; failures analysed | “The model understands financial reports” |
| Residual errors have identifiable causes | Completed blinded manual review | Manual labels frozen, ambiguous cases retained, agreement reported for double-coded subset | Automatic suggestions presented as observed taxonomy |
| The method preserves usefulness | Accuracy, valid numeric response rate, invalid rate, abstention and latency | Benefits and costs reported together | Safety metric reported without coverage/accuracy cost |

Null or adverse results remain valid findings. Code, thresholds or hypotheses must not be changed after viewing the public-test outcomes unless the run is explicitly reclassified as exploratory and a new untouched evaluation split is available.
