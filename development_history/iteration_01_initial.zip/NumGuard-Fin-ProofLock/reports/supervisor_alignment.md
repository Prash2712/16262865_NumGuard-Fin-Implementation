# Alignment with supervisor feedback

## 1. Evaluation rigour and safety–coverage cost

The experiment reports accuracy, valid numeric coverage, explicit abstention, invalid responses, unsupported complete answers, proof validity, candidate recall, selective risk, latency and confidence intervals. Four soft-prefix strengths create a trade-off curve. A development-calibrated risk threshold is frozen before public-test evaluation.

## 2. Operational definitions of provenance and derivation

`reports/numeric_and_derivation_rules.md` fixes whole-span parsing, normalisation, percent compatibility, scale handling, operation schemas, operand order, unit checks, rounding and lattice bounds. Provenance is represented through structured source claims and derivations are admitted only when licensed by the question schema.

## 3. FLAN-T5 justification and generalisation limit

FLAN-T5 is used because the weights and decoder logits are accessible, the model is reproducible in standard research environments and Hugging Face exposes prefix constraints and logits processors. Conclusions are restricted to the tested model, dataset and decoding configuration. Model limitations are separated from mechanism-level candidate recall and proof validity.

## 4. Controlled claims

The artefact is described as constraining unsupported complete-number generation relative to a constructed proof lattice under stated conditions. It is not described as universal correctness, deterministic financial safety or regulatory compliance.

## 5. Artefact–narrative integration

- Evidence ledger: operationalises provenance.
- Retrieval: controls which evidence is presented to every paired condition.
- Intent parser: defines admissible operation families.
- Proof lattice: bounds complete answer candidates and exposes candidate recall.
- Prefix trie: implements the sequence-level safety lock.
- Post-hoc verifier: supplies the supervisor-requested fallback comparison.
- Calibration: quantifies the safety–coverage cost.
- Counterfactual audits: test whether decisions depend on the correct evidence.
- Blinded taxonomy: explains residual errors without treating automatic labels as findings.

## 6. Ethics and data

The study uses public secondary data, no human participants and no newly collected personal data. Dataset source, checksums and split discipline are recorded. The official FinQA licence and model-card terms must be referenced in the final report.

## 7. Marker-facing evidence

Every headline claim is linked to a required output and decision rule in `reports/claim_evidence_register.md`. Engineering verification and empirical findings are stored separately so synthetic or deterministic checks cannot be mistaken for final results.
