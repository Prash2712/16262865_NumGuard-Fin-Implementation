# Literature positioning

## Benchmark and task structure

FinQA established a benchmark for numerical reasoning over financial reports with structured tables, supporting evidence and annotated reasoning programs. NumGuard-Fin uses that structure to preserve table row, column, reporting period, scale and currency provenance rather than flattening the report into an undifferentiated text prompt.

## Constrained decoding

PICARD demonstrated that autoregressive decoding can reject inadmissible tokens incrementally. NumGuard-Fin adopts the general principle of prefix admissibility but constructs an input-dependent language of complete certified numeric answers rather than a fixed SQL grammar.

KCTS showed that frozen language models can be guided at inference time with knowledge-constrained decoding. The present artefact differs by making every admissible complete answer auditable through a deterministic financial evidence certificate and by separating candidate recall, model selection, proof validity and selective risk.

## Abstention and evaluation incentives

Selective question answering establishes that abstention must be evaluated through risk and coverage, not praised solely for reducing errors. Recent work on hallucination incentives further reinforces the need to measure the cost of forced answering. NumGuard-Fin therefore calibrates a development-set threshold and reports coverage loss, invalid responses and over-refusal alongside safety.

## Financial hallucination and robustness work

FAITH evaluates intrinsic hallucinations in financial tables, while FinReflectKG–HalluBench evaluates groundedness detection in financial QA with structured evidence and noisy knowledge-graph signals. These works focus primarily on evaluation or detection. NumGuard-Fin instead tests an answer-generation control that prevents uncertified complete answers relative to an explicit lattice.

Table-QA robustness work, including RobuT and fine-grained robustness evaluation, motivates testing whether a system responds to the correct table semantics rather than merely matching surface numbers. The counterfactual audit therefore separates irrelevant-number invariance from sensitivity to period, metric, support and scale changes.

## Closest recent financial reasoning systems

Recent finance-specific systems sharply limit any broad novelty claim:

- FIND combines model adaptation with constraint-aware financial reasoning.
- FinCARDS applies finance-aware structured constraints for auditable evidence reranking.
- The Data-centric Reasoning Compiler (DCRC) uses adversarial data construction, multi-stage training and compile-and-execute program synthesis to reduce numerical hallucination in online financial QA.

NumGuard-Fin does **not** claim to invent verifiable financial reasoning, structured evidence selection or constrained decoding. Its narrower contribution is:

> an inference-only, table-aware and question-conditioned numeric proof lattice joined to whole-sequence answer locking, development-calibrated abstention and two-layer counterfactual provenance auditing, evaluated without model fine-tuning on FinQA.

The contrast with DCRC is material: DCRC trains a structuring agent to compile executable programs, whereas NumGuard-Fin tests whether a deterministic candidate language and decoder-level complete-answer lock can be added to a frozen model. The resulting contribution is a lightweight safety mechanism and evaluation decomposition, not a new state-of-the-art financial reasoning model.

## Core references

- Chen, Z. et al. (2021). *FinQA: A Dataset of Numerical Reasoning over Financial Data*. EMNLP. DOI: 10.18653/v1/2021.emnlp-main.300.
- Scholak, T., Schucher, N. and Bahdanau, D. (2021). *PICARD: Parsing Incrementally for Constrained Auto-Regressive Decoding from Language Models*. EMNLP. DOI: 10.18653/v1/2021.emnlp-main.779.
- Choi, S. et al. (2023). *KCTS: Knowledge-Constrained Tree Search Decoding with Token-Level Hallucination Detection*. EMNLP. DOI: 10.18653/v1/2023.emnlp-main.867.
- Kamath, A., Jia, R. and Liang, P. (2020). *Selective Question Answering under Domain Shift*. ACL.
- Zhao, Y. et al. (2022). *RobuT: A Systematic Study of Table QA Robustness Against Human-Annotated Adversarial Perturbations*. KDD.
- *FAITH: A Framework for Assessing Intrinsic Tabular Hallucinations in Finance* (2025). ACM International Conference on AI in Finance. DOI: 10.1145/3768292.3770433.
- Kumar, M., Sarmah, B. and Pasquali, S. (2026). *FinReflectKG–HalluBench: GraphRAG Hallucination Benchmark for Financial Question Answering Systems*. arXiv:2603.20252.
- Chen, H. et al. (2026). *Fighting Numerical Hallucinations via Data-centric Compilation for Online Financial QA*. arXiv:2605.31064; accepted at KDD 2026.
- Kalai, A. T. et al. (2026). *Evaluating Large Language Models for Accuracy Incentivizes Hallucinations*. Nature, 653, 1047–1051. DOI: 10.1038/s41586-026-10549-w.
- Das, S. et al. (2026). *FIND: Toward Multimodal Financial Reasoning and Question Answering for Indic Languages*. Findings of ACL.
- Zhou, Y. et al. (2026). *FinCARDS: Card-Based Analyst Reranking for Financial Document Question Answering*. Findings of ACL.

The final dissertation bibliography must be checked against publisher records before submission. Recent preprints should be identified as preprints where applicable.
