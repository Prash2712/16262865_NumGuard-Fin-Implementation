# Technical assurance

## Defects explicitly prevented

- Four-digit years and long integers are parsed as complete spans.
- Leading decimals remain decimals; `.5` is not treated as `5`.
- Percent markers, signs, grouped thousands, parentheses, scale and currency are retained.
- Relevant table evidence is selected structurally rather than placed after arbitrary flat-text truncation.
- Hard decoding uses complete candidate token sequences, not a union of digit fragments.
- Derivations are question-conditioned, unit-checked and bounded.
- Proof certificates include complete structured evidence claims, not only source IDs.
- A number embedded in prose is rejected as an invalid complete-answer response.
- No-number outputs are not awarded perfect proof validity.
- Reference answers are absent from prompts, retrieval, candidate construction and selection.
- Post-hoc latency includes the original generation time.
- Risk-controlled latency includes constrained generation and verification.
- Prompt token count and truncation are recorded per response.
- Hard locks are validated for zero unsupported complete-answer escapes relative to the lattice.
- Checkpoint resume requires the same configuration ID and prevents duplicate assembled rows.
- Submission-facing output uses `reference_answer` and `model_response` and excludes superseded labels.

## Proof certificate fields

A committed answer records:

- decision and complete response;
- candidate identifier and confidence;
- proof type and operation;
- derivation expression;
- answer type;
- each evidence claim with value, base value, source type, row, column, metric, period, scale, currency and source ID.

The certificate is saved as a nested object in JSONL and a serialised JSON field in CSV/Excel.

## Local verification boundary

The packaged verification run exercises deterministic research logic on transparent fixtures. It does not claim empirical FLAN-T5 performance. Final model evidence requires the official FinQA development and public-test files, model weights and a CUDA-capable runtime.

## Reproducibility record

Each empirical run records:

- dataset path and SHA-256;
- exact ordered example IDs and their digest;
- split and example count;
- model name and resolved revision when available;
- requested/resolved device and GPU information;
- Python, Torch, CUDA, cuDNN and dependency versions;
- seed and deterministic settings;
- prompt and generation limits;
- risk threshold and method list;
- configuration hash and exact command invocation;
- output checkpoints and final manifest.
