from __future__ import annotations

import math
import re
from collections import Counter
from typing import Iterable

from .schemas import EvidenceItem, QuestionIntent, RetrievedEvidence


TOKEN_RE = re.compile(r"[a-z0-9]+")
STOPWORDS = {
    "the", "a", "an", "of", "in", "to", "for", "and", "or", "was", "were",
    "is", "are", "what", "how", "much", "many", "during", "from", "by", "with",
    "according", "company", "year", "years", "total", "reported",
}


def _normalise_token(token: str) -> str:
    token = token.lower()
    if len(token) > 4 and token.endswith("ies"):
        return token[:-3] + "y"
    if len(token) > 4 and token.endswith("es"):
        return token[:-2]
    if len(token) > 3 and token.endswith("s"):
        return token[:-1]
    return token


def tokens(text: str) -> list[str]:
    return [
        _normalise_token(token)
        for token in TOKEN_RE.findall(text.lower())
        if token not in STOPWORDS
    ]


def _weighted_overlap(query_tokens: list[str], evidence_tokens: list[str]) -> float:
    if not query_tokens or not evidence_tokens:
        return 0.0
    query_counts = Counter(query_tokens)
    evidence_counts = Counter(evidence_tokens)
    overlap = sum(min(query_counts[token], evidence_counts[token]) for token in query_counts)
    return overlap / math.sqrt(max(1, len(query_tokens)) * max(1, len(evidence_tokens)))


def score_evidence(item: EvidenceItem, question: str, intent: QuestionIntent) -> RetrievedEvidence:
    question_tokens = tokens(question)
    evidence_tokens = tokens(f"{item.metric_text} {item.column_label or ''} {item.text}")
    lexical = _weighted_overlap(question_tokens, evidence_tokens)

    metric_tokens = {_normalise_token(term) for term in intent.metric_terms}
    evidence_metric_tokens = set(tokens(item.metric_text))
    metric_score = 0.0
    if metric_tokens:
        metric_score = len(metric_tokens & evidence_metric_tokens) / len(metric_tokens)

    period_score = 0.0
    if intent.periods:
        if item.period in intent.periods:
            period_score = 1.0
        elif any(period in (item.column_label or "") or period in item.text for period in intent.periods):
            period_score = 0.7
        else:
            period_score = -0.35

    type_score = 0.0
    expected = intent.expected_answer_type
    if expected == "percentage":
        type_score = 0.8 if item.is_percent else 0.15
    elif expected == "year":
        type_score = 1.0 if item.is_year else -1.0
    elif expected in {"plain", "count", "ratio"}:
        type_score = 0.2 if not item.is_year else -0.8

    source_bonus = 0.22 if item.source_type == "table" else 0.08
    non_year_bonus = 0.1 if not item.is_year or expected == "year" else -0.6
    score = (
        2.6 * lexical
        + 2.2 * metric_score
        + 1.8 * period_score
        + type_score
        + source_bonus
        + non_year_bonus
    )
    return RetrievedEvidence(
        item=item,
        score=score,
        lexical_score=lexical,
        period_score=period_score,
        metric_score=metric_score,
        type_score=type_score,
    )


def retrieve_evidence(
    items: Iterable[EvidenceItem],
    question: str,
    intent: QuestionIntent,
    *,
    top_k: int = 12,
    minimum_score: float = -0.2,
) -> list[RetrievedEvidence]:
    scored = [score_evidence(item, question, intent) for item in items]
    scored = [entry for entry in scored if entry.score >= minimum_score]
    scored.sort(key=lambda entry: (-entry.score, entry.item.evidence_id))

    # Avoid a long table row crowding out every other potentially relevant source.
    selected: list[RetrievedEvidence] = []
    per_row: Counter[tuple[str, int | None]] = Counter()
    for entry in scored:
        row_key = (entry.item.source_type, entry.item.row_index)
        if entry.item.source_type == "table" and per_row[row_key] >= 4:
            continue
        selected.append(entry)
        per_row[row_key] += 1
        if len(selected) >= top_k:
            break
    return selected
