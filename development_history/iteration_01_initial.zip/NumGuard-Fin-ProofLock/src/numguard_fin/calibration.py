from __future__ import annotations

import math
from dataclasses import dataclass, asdict
from typing import Any, Iterable

import numpy as np
import pandas as pd


@dataclass(frozen=True)
class CalibrationDecision:
    threshold: float
    target_risk: float
    observed_risk: float
    risk_upper_bound: float
    coverage: float
    accepted_examples: int
    calibration_examples: int
    confidence_level: float

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def clopper_pearson_upper(errors: int, total: int, confidence: float = 0.95) -> float:
    if total <= 0:
        return 1.0
    if errors >= total:
        return 1.0
    alpha = 1.0 - confidence
    try:
        from scipy.stats import beta
        return float(beta.ppf(1.0 - alpha, errors + 1, total - errors))
    except ImportError:
        # Conservative Wilson upper bound fallback.
        z = 1.959963984540054
        p = errors / total
        denominator = 1.0 + z * z / total
        centre = p + z * z / (2 * total)
        radius = z * math.sqrt(p * (1 - p) / total + z * z / (4 * total * total))
        return min(1.0, (centre + radius) / denominator)


def calibration_curve(
    rows: Iterable[dict[str, Any]],
    *,
    confidence_level: float = 0.95,
) -> pd.DataFrame:
    rows = list(rows)
    scored = [
        row for row in rows
        if row.get("selected_candidate_confidence") is not None
        and bool(row.get("valid_numeric_response"))
    ]
    thresholds = sorted(
        {0.0, 1.0, *(float(row["selected_candidate_confidence"]) for row in scored)}
    )
    output = []
    for threshold in thresholds:
        accepted = [row for row in scored if float(row["selected_candidate_confidence"]) >= threshold]
        errors = sum(not bool(row.get("numeric_exact_match")) for row in accepted)
        total = len(accepted)
        risk = errors / total if total else math.nan
        output.append(
            {
                "threshold": threshold,
                "accepted_examples": total,
                "coverage": total / len(rows) if rows else 0.0,
                "observed_risk": risk,
                "risk_upper_bound": clopper_pearson_upper(errors, total, confidence_level),
            }
        )
    return pd.DataFrame(output).sort_values(["threshold"]).reset_index(drop=True)


def select_risk_threshold(
    rows: Iterable[dict[str, Any]],
    *,
    target_risk: float = 0.20,
    confidence_level: float = 0.95,
) -> CalibrationDecision:
    rows = list(rows)
    curve = calibration_curve(rows, confidence_level=confidence_level)
    feasible = curve[
        (curve["accepted_examples"] > 0)
        & (curve["risk_upper_bound"] <= target_risk)
    ]
    if feasible.empty:
        return CalibrationDecision(
            threshold=1.000001,
            target_risk=target_risk,
            observed_risk=0.0,
            risk_upper_bound=0.0,
            coverage=0.0,
            accepted_examples=0,
            calibration_examples=len(rows),
            confidence_level=confidence_level,
        )
    best = feasible.sort_values(["coverage", "threshold"], ascending=[False, True]).iloc[0]
    return CalibrationDecision(
        threshold=float(best["threshold"]),
        target_risk=target_risk,
        observed_risk=float(best["observed_risk"]),
        risk_upper_bound=float(best["risk_upper_bound"]),
        coverage=float(best["coverage"]),
        accepted_examples=int(best["accepted_examples"]),
        calibration_examples=len(rows),
        confidence_level=confidence_level,
    )
