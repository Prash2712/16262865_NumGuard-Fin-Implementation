from __future__ import annotations

import hashlib
import math
from dataclasses import dataclass
from decimal import Decimal, DivisionByZero, InvalidOperation
from typing import Iterable, Optional

from .numeric import format_answer, numeric_equal, parse_single_number
from .schemas import (
    AnswerCandidate,
    CandidateProof,
    EvidenceItem,
    QuestionIntent,
    RetrievedEvidence,
)


ABSTAIN_RESPONSE = "INSUFFICIENT_EVIDENCE"
DERIVATION_OPERATIONS = {
    "difference",
    "percentage_change",
    "sum",
    "average",
    "ratio",
    "margin",
    "product",
}


@dataclass(frozen=True)
class CandidateLattice:
    candidates: tuple[AnswerCandidate, ...]
    direct_count: int
    derived_count: int
    retrieval_count: int

    @property
    def answer_strings(self) -> tuple[str, ...]:
        return tuple(candidate.answer for candidate in self.candidates)

    def numeric_candidates(self) -> tuple[AnswerCandidate, ...]:
        return tuple(
            candidate
            for candidate in self.candidates
            if candidate.proof.proof_type != "abstain"
        )

    def find_by_answer(self, response: str) -> Optional[AnswerCandidate]:
        cleaned = response.strip()
        exact = [candidate for candidate in self.candidates if candidate.answer == cleaned]
        if exact:
            return max(exact, key=lambda candidate: candidate.confidence)

        parsed_response = parse_single_number(cleaned)
        if parsed_response is None:
            return None
        matches: list[AnswerCandidate] = []
        for candidate in self.numeric_candidates():
            parsed_candidate = parse_single_number(candidate.answer)
            if parsed_candidate is None:
                continue
            if numeric_equal(
                parsed_response,
                parsed_candidate,
                require_percent_compatibility=True,
            ):
                matches.append(candidate)
        return max(matches, key=lambda candidate: candidate.confidence) if matches else None

    def contains_reference(self, reference_answer: Optional[str]) -> Optional[bool]:
        if reference_answer is None:
            return None
        parsed_reference = parse_single_number(reference_answer)
        if parsed_reference is None:
            return False
        for candidate in self.numeric_candidates():
            parsed_candidate = parse_single_number(candidate.answer)
            if parsed_candidate is None:
                continue
            if numeric_equal(
                parsed_reference,
                parsed_candidate,
                require_percent_compatibility=True,
            ):
                return True
        return False


def _stable_id(prefix: str, payload: str) -> str:
    return f"{prefix}_{hashlib.sha1(payload.encode('utf-8')).hexdigest()[:10]}"


def _sigmoid(value: float) -> float:
    return 1.0 / (1.0 + math.exp(-max(-20.0, min(20.0, value))))


def _candidate_answer(value: Decimal, answer_type: str) -> str:
    return format_answer(value, answer_type, places=4)


def _direct_answer_type(item: EvidenceItem, intent: QuestionIntent) -> str:
    if item.is_percent:
        return "percentage"
    if item.is_year and intent.expected_answer_type == "year":
        return "year"
    if intent.expected_answer_type == "count":
        return "count"
    # A direct rate can be reported as a bare number under a rate-labelled row.
    metric = (item.metric_text or "").lower()
    if (
        intent.operation == "direct_lookup"
        and intent.expected_answer_type == "percentage"
        and any(term in metric for term in ("rate", "margin", "percent", "percentage"))
    ):
        return "percentage"
    return "plain"


def _direct_candidate(entry: RetrievedEvidence, intent: QuestionIntent) -> AnswerCandidate:
    item = entry.item
    answer_type = _direct_answer_type(item, intent)
    answer = _candidate_answer(item.value, answer_type)

    metric_fit = entry.metric_score if intent.metric_terms else max(0.0, entry.lexical_score)
    period_fit = max(0.0, entry.period_score) if intent.periods else 1.0
    type_fit = 1.0
    if intent.expected_answer_type == "percentage":
        type_fit = 1.0 if answer_type == "percentage" else 0.25
    elif intent.expected_answer_type == "year":
        type_fit = 1.0 if item.is_year else 0.0
    elif item.is_year:
        type_fit = 0.0

    semantic_score = max(
        0.0,
        min(1.0, 0.50 * metric_fit + 0.30 * period_fit + 0.20 * type_fit),
    )
    confidence = max(
        0.0,
        min(1.0, 0.30 * _sigmoid(entry.score) + 0.55 * semantic_score + 0.15),
    )

    # When the question explicitly names a metric, a period-only match is not enough.
    if intent.metric_terms and entry.metric_score == 0.0:
        confidence *= 0.32
    # Direct source values remain in the lattice as an ablation, but operations that
    # require arithmetic should prefer a proof carrying the requested operation.
    if intent.operation in DERIVATION_OPERATIONS:
        confidence *= 0.58

    proof = CandidateProof(
        proof_type="direct",
        operation="lookup",
        operand_ids=(item.evidence_id,),
        expression=item.evidence_id,
        compatible_units=True,
        question_conditioned=True,
    )
    return AnswerCandidate(
        candidate_id=_stable_id("direct", f"{item.evidence_id}|{answer}"),
        answer=answer,
        value=item.value,
        answer_type=answer_type,
        proof=proof,
        evidence_ids=(item.evidence_id,),
        retrieval_score=entry.score,
        semantic_score=semantic_score,
        proof_score=1.0,
        confidence=confidence,
        explanation=f"Direct value from {item.evidence_id}: {item.text}",
    )


def _compatible_units(left: EvidenceItem, right: EvidenceItem, operation: str) -> bool:
    if left.currency and right.currency and left.currency != right.currency:
        return False
    if operation in {"addition", "subtraction", "average"}:
        if left.scale and right.scale and left.scale != right.scale:
            return False
    return True


def _normalised_metric(item: EvidenceItem) -> str:
    return " ".join((item.row_label or item.metric_text).strip().lower().split())


def _same_metric(left: EvidenceItem, right: EvidenceItem) -> bool:
    left_text = _normalised_metric(left)
    right_text = _normalised_metric(right)
    if not left_text or not right_text:
        return False
    return left_text == right_text or left_text in right_text or right_text in left_text


def _question_metric_compatible(
    left: RetrievedEvidence,
    right: RetrievedEvidence,
    intent: QuestionIntent,
) -> bool:
    if not intent.metric_terms:
        return True
    if _same_metric(left.item, right.item):
        return True
    # Region/product modifiers may differ while the requested metric is shared.
    return left.metric_score >= 0.5 and right.metric_score >= 0.5


def _period_pair(
    retrieved: list[RetrievedEvidence], ordered_periods: tuple[str, ...]
) -> list[tuple[RetrievedEvidence, RetrievedEvidence]]:
    if len(ordered_periods) < 2:
        return []
    first_period, second_period = ordered_periods[0], ordered_periods[1]
    first_items = [entry for entry in retrieved if entry.item.period == first_period]
    second_items = [entry for entry in retrieved if entry.item.period == second_period]
    pairs = [
        (first, second)
        for first in first_items
        for second in second_items
        if _same_metric(first.item, second.item)
    ]
    return pairs or [(first, second) for first in first_items for second in second_items]


def _operation_role_score(
    operation: str,
    left: RetrievedEvidence,
    right: RetrievedEvidence,
    intent: QuestionIntent,
) -> float:
    left_metric = _normalised_metric(left.item)
    right_metric = _normalised_metric(right.item)
    if operation == "margin":
        numerator = any(token in left_metric for token in ("income", "profit", "earnings"))
        denominator = any(token in right_metric for token in ("revenue", "sales"))
        return 1.0 if numerator and denominator else 0.0
    if operation in {"addition", "average"}:
        return 1.0 if _question_metric_compatible(left, right, intent) else 0.0
    if operation in {"difference", "percentage_change", "division"}:
        return 1.0 if _same_metric(left.item, right.item) else 0.45 * float(
            _question_metric_compatible(left, right, intent)
        )
    return 0.7


def _derived_candidate(
    operation: str,
    left: RetrievedEvidence,
    right: RetrievedEvidence,
    result: Decimal,
    intent: QuestionIntent,
    expression: str,
) -> AnswerCandidate:
    answer_type = "percentage" if operation in {"percentage_change", "margin"} else intent.expected_answer_type
    if answer_type not in {"percentage", "ratio", "count", "year", "plain"}:
        answer_type = "plain"
    answer = _candidate_answer(result, answer_type)

    period_fit = 1.0
    if intent.periods:
        represented = {left.item.period, right.item.period}
        period_fit = len(set(intent.periods[:2]) & represented) / min(2, len(intent.periods))
    metric_fit = (max(0.0, left.metric_score) + max(0.0, right.metric_score)) / 2.0
    role_fit = _operation_role_score(operation, left, right, intent)
    semantic_score = max(
        0.0,
        min(1.0, 0.35 * metric_fit + 0.25 * period_fit + 0.40 * role_fit),
    )
    compatible = _compatible_units(left.item, right.item, operation)
    proof_score = 1.0 if compatible else 0.0
    retrieval_score = (left.score + right.score) / 2.0
    confidence = max(
        0.0,
        min(
            1.0,
            0.20 * _sigmoid(retrieval_score)
            + 0.55 * semantic_score
            + 0.25 * proof_score,
        ),
    )
    # The operation must be semantically licensed, not merely arithmetically possible.
    if role_fit == 0.0:
        confidence *= 0.30

    proof = CandidateProof(
        proof_type="derived",
        operation=operation,
        operand_ids=(left.item.evidence_id, right.item.evidence_id),
        expression=expression,
        compatible_units=compatible,
        question_conditioned=True,
    )
    return AnswerCandidate(
        candidate_id=_stable_id(
            "derived",
            f"{operation}|{left.item.evidence_id}|{right.item.evidence_id}|{answer}",
        ),
        answer=answer,
        value=result,
        answer_type=answer_type,
        proof=proof,
        evidence_ids=(left.item.evidence_id, right.item.evidence_id),
        retrieval_score=retrieval_score,
        semantic_score=semantic_score,
        proof_score=proof_score,
        confidence=confidence,
        explanation=(
            f"{operation} using {left.item.evidence_id}={left.item.canonical} and "
            f"{right.item.evidence_id}={right.item.canonical}"
        ),
    )


def _safe_divide(numerator: Decimal, denominator: Decimal) -> Optional[Decimal]:
    try:
        if denominator == 0:
            return None
        return numerator / denominator
    except (DivisionByZero, InvalidOperation, ZeroDivisionError):
        return None


def _candidate_pairs(
    retrieved: list[RetrievedEvidence], intent: QuestionIntent
) -> list[tuple[RetrievedEvidence, RetrievedEvidence]]:
    period_pairs = _period_pair(retrieved, intent.ordered_periods)
    if period_pairs:
        return period_pairs

    top = [entry for entry in retrieved if not entry.item.is_year][:8]
    if intent.operation == "margin":
        return [
            (left, right)
            for left in top
            for right in top
            if left.item.evidence_id != right.item.evidence_id
            and any(token in _normalised_metric(left.item) for token in ("income", "profit", "earnings"))
            and any(token in _normalised_metric(right.item) for token in ("revenue", "sales"))
        ]
    pairs: list[tuple[RetrievedEvidence, RetrievedEvidence]] = []
    for index, left in enumerate(top):
        for right in top[index + 1 :]:
            if _question_metric_compatible(left, right, intent):
                pairs.extend([(left, right), (right, left)])
    return pairs


def _generate_derived(
    retrieved: list[RetrievedEvidence], intent: QuestionIntent, max_candidates: int
) -> list[AnswerCandidate]:
    operation = intent.operation
    if operation not in DERIVATION_OPERATIONS or max_candidates <= 0:
        return []

    candidates: list[AnswerCandidate] = []
    for first, second in _candidate_pairs(retrieved, intent):
        if len(candidates) >= max_candidates * 3:
            break
        if not _compatible_units(first.item, second.item, operation):
            continue

        left, right = first, second
        a, b = left.item.value, right.item.value
        result: Optional[Decimal] = None
        expression = ""
        proof_operation = operation

        if operation == "difference":
            if len(intent.ordered_periods) >= 2:
                earlier, later = intent.ordered_periods[:2]
                earlier_item = left if left.item.period == earlier else right
                later_item = right if right.item.period == later else left
                result = later_item.item.value - earlier_item.item.value
                expression = f"{later_item.item.evidence_id} - {earlier_item.item.evidence_id}"
                left, right = later_item, earlier_item
            else:
                result = a - b
                expression = f"{left.item.evidence_id} - {right.item.evidence_id}"
            proof_operation = "subtraction"
            if intent.asks_for_absolute_change:
                result = abs(result)
                expression = f"abs({expression})"
        elif operation == "percentage_change":
            if len(intent.ordered_periods) >= 2:
                earlier, later = intent.ordered_periods[:2]
                old = left if left.item.period == earlier else right
                new = right if right.item.period == later else left
            else:
                old, new = right, left
            ratio = _safe_divide(new.item.value - old.item.value, old.item.value)
            if ratio is not None:
                result = ratio * Decimal("100")
                expression = (
                    f"(({new.item.evidence_id} - {old.item.evidence_id}) / "
                    f"{old.item.evidence_id}) * 100"
                )
                left, right = new, old
        elif operation == "sum":
            result = a + b
            expression = f"{left.item.evidence_id} + {right.item.evidence_id}"
            proof_operation = "addition"
        elif operation == "average":
            result = (a + b) / Decimal("2")
            expression = f"({left.item.evidence_id} + {right.item.evidence_id}) / 2"
        elif operation == "ratio":
            result = _safe_divide(a, b)
            expression = f"{left.item.evidence_id} / {right.item.evidence_id}"
            proof_operation = "division"
        elif operation == "margin":
            left_metric = _normalised_metric(left.item)
            right_metric = _normalised_metric(right.item)
            if not (
                any(token in left_metric for token in ("income", "profit", "earnings"))
                and any(token in right_metric for token in ("revenue", "sales"))
            ):
                continue
            ratio = _safe_divide(a, b)
            if ratio is not None:
                result = ratio * Decimal("100")
                expression = f"({left.item.evidence_id} / {right.item.evidence_id}) * 100"
        elif operation == "product":
            result = a * b
            expression = f"{left.item.evidence_id} * {right.item.evidence_id}"
            proof_operation = "multiplication"

        if result is None or not result.is_finite() or abs(result) > Decimal("1e15"):
            continue
        candidates.append(
            _derived_candidate(
                proof_operation,
                left,
                right,
                result,
                intent,
                expression,
            )
        )

    candidates.sort(key=lambda candidate: (-candidate.confidence, candidate.candidate_id))
    return candidates[:max_candidates]


def _deduplicate(candidates: Iterable[AnswerCandidate]) -> list[AnswerCandidate]:
    best: dict[tuple[str, str], AnswerCandidate] = {}
    for candidate in candidates:
        key = (candidate.answer, candidate.proof.proof_type)
        previous = best.get(key)
        if previous is None or candidate.confidence > previous.confidence:
            best[key] = candidate
    return sorted(best.values(), key=lambda candidate: (-candidate.confidence, candidate.candidate_id))


def build_candidate_lattice(
    retrieved: Iterable[RetrievedEvidence],
    intent: QuestionIntent,
    *,
    include_derived: bool = True,
    max_direct: int = 12,
    max_derived: int = 20,
    minimum_direct_confidence: float = 0.15,
    minimum_derived_confidence: float = 0.35,
) -> CandidateLattice:
    retrieved_list = list(retrieved)
    direct = [
        _direct_candidate(entry, intent)
        for entry in retrieved_list
        if not entry.item.is_year or intent.expected_answer_type == "year"
    ]
    direct = [candidate for candidate in direct if candidate.confidence >= minimum_direct_confidence]
    direct = _deduplicate(direct)[:max_direct]

    derived = _generate_derived(retrieved_list, intent, max_derived) if include_derived else []
    derived = [candidate for candidate in derived if candidate.confidence >= minimum_derived_confidence]
    derived = _deduplicate(derived)[:max_derived]

    abstain = AnswerCandidate(
        candidate_id="abstain",
        answer=ABSTAIN_RESPONSE,
        value=None,
        answer_type="abstain",
        proof=CandidateProof(
            proof_type="abstain",
            operation="abstain",
            operand_ids=(),
            expression="",
            compatible_units=True,
            question_conditioned=True,
        ),
        evidence_ids=(),
        retrieval_score=0.0,
        semantic_score=1.0,
        proof_score=1.0,
        confidence=1.0,
        explanation="No candidate has sufficient support.",
    )
    candidates = tuple(_deduplicate([*direct, *derived]) + [abstain])
    return CandidateLattice(
        candidates=candidates,
        direct_count=len(direct),
        derived_count=len(derived),
        retrieval_count=len(retrieved_list),
    )
