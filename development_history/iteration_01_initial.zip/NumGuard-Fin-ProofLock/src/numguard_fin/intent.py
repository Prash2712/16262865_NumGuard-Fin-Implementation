from __future__ import annotations

import re
from typing import Iterable

from .schemas import QuestionIntent


YEAR_RE = re.compile(r"\b(?:19|20)\d{2}\b")
TOKEN_RE = re.compile(r"[a-z0-9]+")

STOPWORDS = {
    "what", "was", "were", "is", "are", "the", "a", "an", "of", "in", "for",
    "to", "from", "during", "how", "much", "many", "did", "does", "do", "by",
    "and", "or", "between", "compared", "with", "according", "reported", "company",
    "year", "years", "amount", "total", "approximately", "respectively",
}

OPERATION_RULES: list[tuple[str, tuple[str, ...]]] = [
    ("percentage_change", (
        r"percentage\s+(?:change|increase|decrease)",
        r"percent\s+(?:change|increase|decrease)",
        r"growth\s+rate", r"rate\s+of\s+change", r"change.*percent", r"increase.*percent",
        r"decrease.*percent",
    )),
    ("difference", (
        r"\bdifference\b", r"how much (?:more|less|higher|lower)", r"change in",
        r"increase in", r"decrease in", r"net change", r"(?:more|less) than",
    )),
    ("average", (r"^what (?:was|is|were|are) the average\b", r"what was the average .* (?:in|for) \d{4} and \d{4}", r"\bmean of\b", r"per year", r"annual average of")),
    ("sum", (r"\bsum\b", r"combined", r"together", r"total of", r"what were the total")),
    ("margin", (r"\bmargin\b", r"as a percentage of", r"what percent of")),
    ("ratio", (r"\bratio\b", r"divided by", r"relative to", r"times as")),
    ("product", (r"\bproduct\b", r"multiplied by")),
    ("direct_lookup", (
        r"^what (?:was|were|is|are)", r"^how much (?:was|were|is|are)",
        r"what amount", r"what is the value", r"how many",
    )),
]

ANSWER_TYPE_RULES: list[tuple[str, tuple[str, ...]]] = [
    ("percentage", (r"percent", r"percentage", r"\bmargin\b", r"growth rate", r"tax rate")),
    ("year", (r"what year", r"which year", r"in which year")),
    ("ratio", (r"\bratio\b", r"times as")),
    ("count", (r"how many", r"number of", r"count of")),
]

GENERIC_FINANCE_TERMS = {
    "revenue", "sales", "income", "expense", "expenses", "cost", "costs", "profit",
    "loss", "assets", "liabilities", "debt", "cash", "equity", "shares", "tax",
    "interest", "margin", "capital", "inventory", "receivables", "payables", "dividend",
    "operating", "net", "gross", "diluted", "basic", "earnings", "compensation",
    "depreciation", "amortization", "goodwill", "investment", "investments", "lease",
}


def _matches(text: str, patterns: Iterable[str]) -> bool:
    return any(re.search(pattern, text, flags=re.IGNORECASE) for pattern in patterns)


def _ordered_periods(question: str, periods: tuple[str, ...]) -> tuple[str, ...]:
    q = question.lower()
    match = re.search(r"from\s+((?:19|20)\d{2})\s+to\s+((?:19|20)\d{2})", q)
    if match:
        return (match.group(1), match.group(2))
    match = re.search(r"between\s+((?:19|20)\d{2})\s+and\s+((?:19|20)\d{2})", q)
    if match:
        return (match.group(1), match.group(2))
    return periods


def _metric_terms(question: str, periods: tuple[str, ...]) -> tuple[str, ...]:
    tokens = TOKEN_RE.findall(question.lower())
    period_set = set(periods)
    meaningful = [
        token for token in tokens
        if token not in STOPWORDS and token not in period_set and not token.isdigit()
    ]
    finance = [token for token in meaningful if token in GENERIC_FINANCE_TERMS]
    # Keep adjacent modifiers as they often disambiguate rows (e.g. interest expense).
    terms = finance or meaningful
    seen: set[str] = set()
    ordered: list[str] = []
    for term in terms:
        if term not in seen:
            seen.add(term)
            ordered.append(term)
    return tuple(ordered[:8])


def parse_question_intent(question: str) -> QuestionIntent:
    q = " ".join(question.strip().split())
    q_lower = q.lower()
    periods = tuple(dict.fromkeys(YEAR_RE.findall(q)))
    # YEAR_RE with a non-capturing group returns full matches; safeguard for future changes.
    periods = tuple(re.findall(r"\b(?:19|20)\d{2}\b", q))
    periods = tuple(dict.fromkeys(periods))

    operation = "unknown"
    for name, patterns in OPERATION_RULES:
        if _matches(q_lower, patterns):
            operation = name
            break
    if operation == "unknown" and len(periods) >= 2:
        operation = "difference"
    if operation == "unknown":
        operation = "direct_lookup"

    answer_type = "plain"
    for name, patterns in ANSWER_TYPE_RULES:
        if _matches(q_lower, patterns):
            answer_type = name
            break
    if operation in {"percentage_change", "margin"}:
        answer_type = "percentage"
    elif operation == "ratio":
        answer_type = "ratio"

    metric_terms = _metric_terms(q, periods)
    signal_count = int(bool(metric_terms)) + int(bool(periods)) + int(operation != "unknown")
    confidence = min(1.0, 0.35 + 0.2 * signal_count)
    asks_for_change = operation in {"difference", "percentage_change"}
    asks_for_absolute_change = bool(re.search(r"absolute|amount of (?:the )?change", q_lower))

    return QuestionIntent(
        operation=operation,
        expected_answer_type=answer_type,
        metric_terms=metric_terms,
        periods=periods,
        ordered_periods=_ordered_periods(q, periods),
        asks_for_change=asks_for_change,
        asks_for_absolute_change=asks_for_absolute_change,
        confidence=confidence,
    )
