from numguard_fin.cli import main

run = [
    "run", "--data-dir", "data/raw", "--split", "dev",
    "--model-name", "google/flan-t5-base", "--device", "cuda",
    "--retrieval-top-k", "10", "--max-direct-candidates", "12",
    "--max-derived-candidates", "20", "--seed", "42",
    "--resume",
    "--output-dir", "results/dev_calibration", "--figures-dir", "figures/dev_calibration",
]
if main(run):
    raise SystemExit(1)
calibrate = [
    "calibrate", "--predictions", "results/dev_calibration/predictions.csv",
    "--method", "derivation_proof_lock", "--target-risk", "0.20",
    "--confidence", "0.95", "--output", "results/dev_calibration/calibration.json",
]
raise SystemExit(main(calibrate))
