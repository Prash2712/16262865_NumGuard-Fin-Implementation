from numguard_fin.cli import main

command = [
    "run", "--data-dir", "data/raw", "--split", "test",
    "--model-name", "google/flan-t5-base", "--device", "cuda",
    "--retrieval-top-k", "10", "--max-direct-candidates", "12",
    "--max-derived-candidates", "20", "--seed", "42",
    "--resume",
    "--risk-threshold-file", "results/dev_calibration/calibration.json",
    "--output-dir", "results/final_test", "--figures-dir", "figures/final_test",
]
if main(command):
    raise SystemExit(1)
raise SystemExit(main([
    "validate", "--predictions", "results/final_test/predictions.csv",
    "--maximum-candidates", "32",
]))
