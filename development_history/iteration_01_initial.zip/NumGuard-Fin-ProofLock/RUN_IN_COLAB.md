# Running the official experiment in Google Colab

The public-test outputs are the dissertation evidence. The files in `verification/` are engineering assurance and must remain separate.

## Route A — supplied notebook

1. Upload the complete project folder to Google Drive.
2. Open `notebooks/NumGuard_Fin_Colab.ipynb` in Colab.
3. Select `Runtime -> Change runtime type -> T4 GPU`.
4. Execute each cell in order.

The notebook mounts Drive, checks CUDA, installs the environment, runs local verification, downloads FinQA, calibrates on development data, freezes the threshold, runs the public test, executes both counterfactual audits and packages the evidence.

## Route B — commands

### 1. Mount Drive and enter the project

```python
from google.colab import drive
drive.mount('/content/drive')
```

```bash
%cd "/content/drive/MyDrive/NumGuard-Fin-ProofLock"
```

### 2. Install the empirical environment

```bash
!pip install --upgrade pip
!pip install -r requirements.txt
!pip install -e . --no-deps
%env PYTHONPATH=/content/drive/MyDrive/NumGuard-Fin-ProofLock/src
```

### 3. Confirm GPU visibility

```python
import torch
print(torch.__version__)
print(torch.cuda.is_available())
print(torch.cuda.get_device_name(0) if torch.cuda.is_available() else "NO CUDA DEVICE")
```

`torch.cuda.is_available()` must return `True` before an empirical run using `--device cuda`.

### 4. Execute engineering assurance

```bash
!./run_local_verification.sh
```

Required outcome:

```text
111 passed
QUALITY GATE PASSED
```

A larger passing count is acceptable if tests are added. No failure should be ignored or removed merely to obtain a green run.

### 5. Download and validate official FinQA files

```bash
!python scripts/download_finqa.py
!python scripts/preflight.py --require-cuda
!ls -lh data/raw
```

The preflight report is stored at `reproducibility/preflight_report.json`. It verifies Python, dependencies, CUDA, the train/dev/test JSON files and available disk space.

### 6. Development calibration

```bash
!./run_colab_dev.sh
```

This runs all paired methods on the development split and saves the selective-risk threshold to:

```text
results/dev_calibration/calibration.json
```

The threshold is selected using the declared risk target and confidence bound. Do not use public-test outcomes to alter it.

### 7. Frozen public-test experiment

```bash
!./run_colab_test.sh
```

This command:

1. runs every paired method on the same shuffled numeric test examples;
2. validates row pairing, certificates, lattice bounds and configuration identity;
3. produces the candidate-mechanism counterfactual audit on 150 fixed cases;
4. produces the model-output counterfactual audit on 50 fixed cases using `risk_controlled_proof_lock`.

### 8. Runtime interruption and resume

The run writes a checkpoint after every completed example. If Colab disconnects, remount Drive, return to the folder and rerun the same script. Resume is accepted only when the configuration ID matches. Do not combine checkpoints from different models, seeds, thresholds or retrieval settings.

To restart a split deliberately, archive or remove its output folder first.

### 9. Package the evidence

```bash
!zip -r NumGuard_Fin_Final_Evidence.zip \
  results/dev_calibration \
  results/final_test \
  figures/dev_calibration \
  figures/final_test \
  reproducibility \
  reports
```

```python
from google.colab import files
files.download("NumGuard_Fin_Final_Evidence.zip")
```

## Files to inspect before writing findings

```text
results/final_test/method_summary.csv
results/final_test/paired_comparisons.csv
results/final_test/predictions.csv
results/final_test/research_tables.xlsx
results/final_test/failure_review_blinded.xlsx
results/final_test/failure_review_key.csv
results/final_test/counterfactual_candidate_mechanism.csv
results/final_test/counterfactual_model_output.csv
figures/final_test/
reproducibility/experiment_manifest.json
reproducibility/preflight_report.json
```

No result should be described as a finding until the public-test validator passes and the corresponding claim meets the decision rule in `reports/claim_evidence_register.md`.
