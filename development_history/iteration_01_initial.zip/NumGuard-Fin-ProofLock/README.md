# NumGuard-Fin

**Proof-locked numeric decoding with table-aware provenance and calibrated abstention for financial question answering**

NumGuard-Fin is a reproducible research artefact for testing whether an inference-time numeric safety layer can reduce unsupported complete-number generation without fine-tuning the underlying model. The system constructs a structured evidence ledger, retrieves question-relevant table cells and narrative spans, builds a bounded lattice of direct and derivable answers, and constrains decoding to complete certified answer sequences.

## Research question

> Can a table-aware, proof-locked decoding lattice reduce unsupported numerical generation while preserving useful answer coverage and derivation fidelity in financial question answering, without model fine-tuning?

## What is technically distinctive

The hard proof lock operates over **complete answer sequences**, not over a bag of digit tokens. Each certified answer is tokenised into a prefix trie. At every decoder step, a token is admissible only when the resulting prefix can still terminate in a complete certified answer or the explicit abstention response. The package retains a weak fragment-token mask only as an ablation, so the experiment can test whether sequence-level enforcement prevents the recombination failures that fragment masking permits.

A committed answer carries a sidecar proof certificate containing:

- direct or derived proof type;
- question-conditioned operation;
- complete structured evidence claims;
- table row, column, period, metric, scale and currency;
- derivation expression and operand identifiers;
- answer type and candidate confidence.

The reference answer is isolated in the evaluation layer. It is never used to retrieve evidence, construct candidates, select an answer or create a certificate.

## Experimental conditions

All conditions are paired on the same examples, retrieved evidence and model configuration.

1. `baseline` — unconstrained generation over retrieved evidence.
2. `provenance_prompt` — evidence-only safety instruction.
3. `candidate_menu_prompt` — certified candidate strings shown in the prompt, without decoder enforcement.
4. `posthoc_verifier` — unconstrained response checked after generation.
5. `fragment_token_lock_ablation` — deliberately weak fragment-level masking.
6. `soft_prefix_bias_1`, `3`, `5`, `10` — graded proof-prefix bias for the safety–coverage curve.
7. `direct_proof_lock` — whole-sequence lock over directly supported values.
8. `derivation_proof_lock` — whole-sequence lock over direct and question-conditioned derived values.
9. `risk_controlled_proof_lock` — derivation lock plus a development-calibrated abstention threshold.

## Evaluation discipline

- Official FinQA **development split**: diagnose candidate recall and select the risk threshold.
- Frozen configuration: threshold, model, retrieval rules, candidate bounds and seed are fixed.
- Official FinQA **public test split**: execute once for final reporting.
- Report accuracy, valid-response coverage, unsupported-answer risk, candidate recall, proof validity, abstention quality, prompt truncation, latency, confidence intervals and paired tests.
- Report coarse proof-operation agreement with the FinQA annotation as a diagnostic; do not describe it as official FinQA program accuracy.
- Run both a candidate-mechanism counterfactual audit and a model-output counterfactual audit.
- Manually code the blinded failure-review sample. Automatic routing suggestions remain in a separate key and are not findings.

## Local engineering verification

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt
./run_local_verification.sh
```

This executes parser regressions, structured provenance, bounded derivations, complete-sequence locking, proof validation, calibration, reporting and controlled perturbations on transparent FinQA-shaped fixtures. The outputs under `verification/` are engineering assurance only; they are not dissertation findings.

Verify the delivered source and documentation hashes with:

```bash
python scripts/verify_source_manifest.py
```

## Official empirical experiment

### Notebook route

Open `notebooks/NumGuard_Fin_Colab.ipynb` in Google Colab, choose a T4 GPU and execute the cells in order.

### Command route

```bash
pip install -r requirements.txt
pip install -e . --no-deps
export PYTHONPATH="$PYTHONPATH:src"
python scripts/download_finqa.py
python scripts/preflight.py --require-cuda
./run_colab_dev.sh
./run_colab_test.sh
```

Runs checkpoint after every completed example. Re-running the same command with `--resume` restores only a matching configuration and does not duplicate completed records.

Primary empirical outputs:

```text
results/dev_calibration/predictions.csv
results/dev_calibration/calibration.json
results/final_test/predictions.csv
results/final_test/method_summary.csv
results/final_test/research_tables.xlsx
results/final_test/failure_review_blinded.xlsx
results/final_test/failure_review_key.csv
results/final_test/counterfactual_candidate_mechanism.csv
results/final_test/counterfactual_model_output.csv
figures/final_test/
reproducibility/
```

## Architecture

```text
FinQA example
  -> structured evidence ledger
  -> question intent and operation schema
  -> finance-aware evidence retrieval
  -> bounded direct/derivation proof lattice
  -> prompt / post-hoc / soft / hard answer-control conditions
  -> proof certificate with source claims
  -> paired accuracy, safety and coverage evaluation
  -> candidate-level and model-level counterfactual audits
  -> blinded manual failure analysis
```

## Scientific boundaries

- The method is evaluated on numeric FinQA questions under the disclosed model and decoding conditions; it is not a universal guarantee for all financial documents or models.
- A valid certificate proves membership in the constructed question-conditioned lattice. It does not prove that retrieval, question interpretation or dataset annotation is correct.
- Whole-sequence locking prevents decoder escape relative to the lattice. Overall accuracy is still bounded by evidence retrieval, candidate recall and model selection.
- Calibrated abstention is a selective prediction policy, not a correctness guarantee.
- The artefact is a research safeguard, not a legal or regulatory compliance system.

## Research documentation

- `reports/research_design.md`
- `reports/numeric_and_derivation_rules.md`
- `reports/evaluation_protocol.md`
- `reports/failure_taxonomy_codebook.md`
- `reports/literature_positioning.md`
- `reports/novelty_stress_test.md`
- `reports/claim_evidence_register.md`
- `reports/supervisor_alignment.md`
- `reports/technical_assurance.md`
- `reports/marker_readiness_checklist.md`
- `reproducibility/decision_log.md`
- `RUN_IN_COLAB.md`
- `DELIVERY_NOTES.md`

## Data and licensing

The FinQA dataset and FLAN-T5 weights are not redistributed. `scripts/download_finqa.py` retrieves the official train, development and public test files and records source URLs, sizes and SHA-256 checksums in `data/raw/dataset_manifest.json`. Review the official FinQA repository, model card and licence terms before redistribution or publication.
