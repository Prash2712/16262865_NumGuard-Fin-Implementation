# Research decision log

## Scope freeze

- Inference-stage intervention only; no model fine-tuning.
- Numeric FinQA questions only for primary evaluation.
- Development split for calibration; public test for frozen final reporting.
- FLAN-T5-base selected for open weights and decoder-logit access.

## Mechanism decisions

- Preserve structured table coordinates and financial metadata instead of flattening source reports.
- Parse complete numeric spans to prevent year and long-integer fragmentation.
- Generate a bounded question-conditioned candidate lattice rather than enumerating arbitrary arithmetic combinations.
- Use a prefix trie over complete answers for the hard constraint.
- Retain fragment-token masking only as a named ablation.
- Include an explicit abstention terminal in every hard lattice.
- Store proof certificates separately from the visible answer.

## Evaluation decisions

- Pair all methods on identical example IDs and retrieved evidence.
- Separate candidate recall from model selection accuracy.
- Treat no-number text as invalid unless it is the declared abstention response.
- Calibrate selective risk on development data only.
- Report candidate-mechanism and model-output counterfactual audits separately.
- Blind method identity and automatic routing during first-pass failure review.
- Treat operation-family agreement as a diagnostic, not official FinQA program accuracy.

## Superseded prototype evidence

Earlier diagnostic outputs based on flat-text truncation, fragmented number parsing and token-fragment masking are excluded from the final evidence base. They motivated the present design but are not used as empirical findings.

## Change control

After public-test execution, code or threshold changes require the run to be labelled exploratory. The frozen public-test result must remain preserved, including adverse or null findings.
