# NumGuard-Fin ProofLock v5

**Proof-locked numeric decoding with bounded aggregate windows, formatting-aware financial evaluation and cross-validated safe candidate ranking.**

Research question:

> Can a table-aware, proof-locked decoding lattice reduce unsupported numerical generation while preserving useful answer coverage and derivation fidelity in financial question answering, without fine-tuning the language model?

## Why v5 exists

The official v4 development candidate gate stopped before FLAN-T5 inference. On 871 numeric FinQA development examples, v4 produced:

- final frozen-lattice candidate recall: **32.03%**, above the 30% overall minimum;
- candidate recall before learned rescoring: **43.63%**;
- unpruned same-retrieval recall: **52.81%**;
- expanded-ledger diagnostic recall: **56.49%**;
- direct/aggregate reference recall: **71.43%**, below the frozen 75% minimum.

The v4 selector also exposed a material ranking defect. Its grouped out-of-fold top-1 accuracy, conditional on the correct candidate being present, was only **0.58%**, whereas the disclosed deterministic heuristic achieved approximately **13.77%** on the same train candidate rows. V5 therefore does not allow a weak learned model to overwrite the stronger heuristic. Learned influence is selected by grouped out-of-fold validation and can resolve to zero.

The remaining direct/aggregate misses also showed three representation problems: bounded three-/five-period windows were not enumerated inside longer table axes; percentage references sometimes omitted the `%` marker; and monetary questions containing the word “margin” could be mistyped as percentages. V5 addresses these mechanisms without changing the frozen candidate-quality or calibration thresholds.

## V5 architecture

For each question, the system constructs:

1. **Structured Financial Evidence Ledger** — raw and canonical values, base value, row, column, period, scale, currency, percentage status and stable source ID.
2. **Role- and Period-Protected Retrieval** — requested metric rows/columns, numerator/denominator roles and requested periods receive non-displaceable retrieval slots.
3. **Typed Proof Lattice** — direct lookup, difference, percentage change, ratio, margin, sum, average, product, table sum/average/min/max, indexed return and bounded composite derivations.
4. **Bounded Aggregate Windows** — contiguous and small combinatorial period windows are generated only when licensed by a question count such as “three-year period.”
5. **Semantic Aggregate Fallback** — sparse or multi-header tables can form a bounded cross-axis group only from cells matching the question metric/entity terms.
6. **Safe Blended Candidate Ranker** — a train-only pairwise linear selector is blended with the deterministic heuristic. The blend weight is chosen by grouped out-of-fold top-1 accuracy; ties prefer less learned influence.
7. **Whole-Sequence Proof Lock** — only token prefixes that can terminate as a certified complete answer or exact abstention are legal.
8. **Proof Certificate and Calibrated Abstention** — every committed answer records evidence and derivation; semantic and provenance risks are calibrated separately on development.

The frozen v5 deployment lattice is bounded to **48 direct numeric candidates, 192 derived numeric candidates and one exact abstention sequence**.

## Principal v5 corrections

- A learned selector can no longer reduce ranking quality below the validated heuristic baseline.
- Selector metadata records heuristic, learned and blended grouped out-of-fold top-1 performance plus the selected blend weight.
- Percentage-typed candidates are recognised when FinQA omits only the `%` surface marker; numeric magnitude and all normal tolerances remain enforced.
- Questions such as “greatest gross margin in millions” are typed as monetary/plain answers rather than percentages.
- Three-/five-period aggregate windows are retained inside longer rows or columns.
- Small irregular aggregate layouts receive bounded subset enumeration; unrestricted arithmetic closure remains prohibited.
- Metric-matched cross-axis aggregate groups support sparse and multi-row-header tables.
- Retrieval and candidate bounds increase to 48/192 to reduce bounded-context losses while remaining explicit and auditable.

## Experimental conditions

The paired experiment contains 13 methods:

1. `baseline`
2. `provenance_prompt`
3. `candidate_menu_prompt`
4. `posthoc_verifier`
5. `fragment_token_lock_ablation`
6. `soft_prefix_bias_1`
7. `soft_prefix_bias_3`
8. `soft_prefix_bias_5`
9. `soft_prefix_bias_10`
10. `direct_proof_lock`
11. `derivation_proof_lock`
12. `selector_guided_proof_lock`
13. `risk_controlled_proof_lock`

## Frozen split protocol

- **FinQA train:** fit and cross-validate the lightweight safe-blend candidate selector.
- **FinQA development:** run the candidate-quality gate, paired model experiment and semantic/provenance calibration.
- **FinQA public test:** execute once only after the development script prints the explicit authorisation line.

Reference answers and programs are never exposed to retrieval, candidate construction, prompts or decoding. They are used only after lattice construction for train labels or development/test evaluation.

## Local engineering verification

```bash
python -m pip install -r requirements.txt
python -m pip install -e . --no-deps
bash run_local_verification.sh
```

Required engineering status:

```text
145 passed
QUALITY GATE PASSED
```

Then remove generated editable-install metadata and verify the source manifest:

```bash
rm -rf src/numguard_fin.egg-info
python scripts/verify_source_manifest.py
```

Engineering fixtures establish mechanical integrity only. They are not official FinQA/FLAN-T5 findings.

## Official execution

Follow `RUN_IN_COLAB.md` or `notebooks/NumGuard_Fin_Colab.ipynb`:

```text
engineering verification
→ official FinQA download and CUDA preflight
→ fresh v5 safe-blend selector fit on train
→ development candidate gate
→ development model experiment only if the gate passes
→ semantic and provenance calibration
→ public test only after explicit authorisation
```

Do not copy v1–v4 selectors, checkpoints, calibration files or results into v5.

## Scientific claim boundary

A hard proof lock guarantees membership in the certified answer lattice, not semantic correctness. A source-linked value can still answer the wrong row, year, metric, unit or operation. Final reporting must distinguish:

- **provenance risk:** whether a committed answer lacks a valid certificate;
- **semantic risk:** whether the committed numeric answer is wrong for the question.

No universal-safety, regulatory-compliance or production-readiness claim is supported.
