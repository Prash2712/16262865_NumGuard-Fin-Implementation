# Exact Google Colab workflow for ProofLock v5

Use a fresh **T4 GPU** runtime. Keep v5 in a separate Google Drive folder. Do not copy any v1–v4 selector, checkpoint, calibration file or result directory into it.

## 1. Mount Drive

```python
from google.colab import drive
drive.mount('/content/drive')
```

## 2. Enter the project folder

```python
import os
from pathlib import Path

PROJECT = Path('/content/drive/MyDrive/NumGuard-Fin-ProofLock-v5')
assert PROJECT.exists(), f'Missing project folder: {PROJECT}'
os.chdir(PROJECT)
print(os.getcwd())
```

Do not delete or re-extract this folder after a run has started.

## 3. Install into the active runtime

```python
%pip install -q -r "/content/drive/MyDrive/NumGuard-Fin-ProofLock-v5/requirements.txt"
%pip install -q -e "/content/drive/MyDrive/NumGuard-Fin-ProofLock-v5" --no-deps
```

```python
import os, sys, importlib
from pathlib import Path

PROJECT = Path('/content/drive/MyDrive/NumGuard-Fin-ProofLock-v5')
SRC = PROJECT / 'src'
os.chdir(PROJECT)
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))
os.environ['PYTHONPATH'] = str(SRC)
importlib.invalidate_caches()

import numguard_fin
print('Version:', numguard_fin.__version__)
print('Package:', numguard_fin.__file__)
assert numguard_fin.__version__ == '5.0.0'
```

## 4. Confirm CUDA

Select **Runtime → Change runtime type → T4 GPU**, then run:

```python
import torch
print('CUDA available:', torch.cuda.is_available())
print('GPU:', torch.cuda.get_device_name(0) if torch.cuda.is_available() else 'NO GPU')
assert torch.cuda.is_available(), 'CUDA is not active.'
```

```bash
!nvidia-smi
```

## 5. Engineering verification

```bash
!bash run_local_verification.sh
```

Required final status:

```text
145 passed
QUALITY GATE PASSED
```

Editable installation creates generated metadata. Remove only that directory before source verification:

```bash
!rm -rf src/numguard_fin.egg-info
!python scripts/verify_source_manifest.py
```

Required: `SOURCE MANIFEST PASSED`.

## 6. Download FinQA and run preflight

```bash
!python scripts/download_finqa.py
!ls -lh data/raw
!python scripts/preflight.py --require-cuda
```

Continue only when preflight reports:

```text
"status": "passed"
"problems": []
```

## 7. Fit a fresh v5 selector on FinQA train

```bash
!mkdir -p results models
!bash -lc 'set -o pipefail; bash run_colab_train_selector.sh 2>&1 | tee -a results/selector_training_v5.log'
```

Inspect:

```bash
!ls -lh models/candidate_selector.json
!cat models/candidate_selector_training_report.json
!tail -n 120 results/selector_training_v5.log
```

The report must identify the objective as:

```text
cross-validated safe blend of heuristic and within-question pairwise proof ranking
```

Check these fields:

```text
heuristic_top1_accuracy_given_candidate_recall
learned_out_of_fold_top1_accuracy_given_candidate_recall
selected_blend_weight
out_of_fold_top1_accuracy_given_candidate_recall
safe_fallback_used
```

A selected blend weight of `0.0` is valid. It means grouped out-of-fold evidence did not justify allowing the learned ranker to override the stronger deterministic heuristic.

## 8. Run the development gate and conditional model experiment

```bash
!bash -lc 'set -o pipefail; bash run_colab_dev.sh 2>&1 | tee -a results/dev_v5_execution.log'
```

The first stage is a CPU candidate diagnostic. It writes:

```text
results/dev_candidate_diagnostic/dataset_audit.csv
results/dev_candidate_diagnostic/candidate_quality_gate.json
```

The frozen gate remains:

```text
overall candidate recall >= 30%
direct/aggregate reference recall >= 75%
```

### Candidate gate failure

When the output contains `CANDIDATE QUALITY GATE FAILED`, stop. Do not lower the thresholds or rerun repeatedly. Package the evidence:

```bash
!rm -f NumGuard_v5_Dev_Gate_Failure.zip
!zip -qr NumGuard_v5_Dev_Gate_Failure.zip \
  results/dev_candidate_diagnostic \
  models/candidate_selector.json \
  models/candidate_selector_training_report.json \
  results/selector_training_rows.csv \
  results/selector_training_v5.log \
  results/dev_v5_execution.log \
  reproducibility \
  verification \
  reports
!sha256sum NumGuard_v5_Dev_Gate_Failure.zip
```

### Candidate gate pass

When the candidate gate passes, the same command continues into the paired FLAN-T5 development experiment and both calibration procedures. Leave the cell running.

Public-test execution is authorised only when the exact final line is:

```text
SEMANTIC CALIBRATION GATE PASSED. The frozen public-test script is now authorised.
```

Any candidate-gate or semantic-calibration failure keeps the public test blocked.

## 9. Frozen public test — once, only after authorisation

```bash
!mkdir -p results/final_test
!bash -lc 'set -o pipefail; bash run_colab_test.sh 2>&1 | tee -a results/final_test/execution.log'
```

`run_colab_test.sh` already executes the counterfactual audit. Do not run it separately.

The test script verifies the selector hash, development manifest, calibration feasibility, coverage, accepted-example count, source prediction hash and configuration identity before inference.

## 10. Resume after a disconnect

A restarted runtime requires only:

1. remount Drive;
2. return to the existing v5 folder;
3. reinstall requirements and the editable package;
4. restore `sys.path` and `PYTHONPATH`;
5. confirm CUDA;
6. rerun the interrupted script.

The experiment runner resumes matching checkpoints. Do not unzip the project again while progress exists.

## 11. Package final evidence

```bash
!rm -f NumGuard_Fin_ProofLock_v5_Evidence.zip
!zip -qr NumGuard_Fin_ProofLock_v5_Evidence.zip \
  models \
  results/selector_training_rows.csv \
  results/selector_training_v5.log \
  results/dev_candidate_diagnostic \
  results/dev_calibration \
  results/dev_v5_execution.log \
  results/final_test \
  figures/dev_calibration \
  figures/final_test \
  reproducibility \
  verification \
  reports \
  configs \
  README.md \
  RUN_IN_COLAB.md \
  V5_CHANGELOG.md
!sha256sum NumGuard_Fin_ProofLock_v5_Evidence.zip
```

Upload the complete evidence ZIP. Screenshots or summary tables alone are insufficient for checking proof validity, calibration, candidate recall, paired statistics and counterfactual behaviour.
