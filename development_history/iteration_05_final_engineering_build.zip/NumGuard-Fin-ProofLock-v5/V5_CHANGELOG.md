# ProofLock v5 changelog

## Trigger

The official v4 development gate evaluated 871 numeric FinQA development examples and stopped before model inference:

- final candidate recall: 0.3203;
- pre-selector candidate recall: 0.4363;
- unpruned same-retrieval recall: 0.5281;
- expanded-ledger diagnostic recall: 0.5649;
- direct/aggregate recall: 0.7143 against the frozen 0.75 minimum.

The v4 train report also showed that the learned pairwise selector had 0.0058 grouped out-of-fold top-1 accuracy conditional on candidate recall. The deterministic heuristic achieved approximately 0.1377 on the same saved train candidate rows. This meant learned rescoring was materially degrading the lattice.

## Changes

1. Added a grouped out-of-fold safe blend between heuristic and learned selector scores.
2. The learned blend weight is selected on a fixed grid; ties prefer lower learned influence.
3. Added an explicit zero-weight fallback when learned ranking does not improve top-1 selection.
4. Added selector report fields for heuristic, learned and blended top-1 performance.
5. Added bounded contiguous and combinatorial aggregate windows for count-licensed questions.
6. Added metric/entity-conditioned cross-axis aggregate groups for sparse table layouts.
7. Added percentage-marker omission normalisation for percentage-typed candidates and references.
8. Corrected monetary questions containing “margin” so explicit million/thousand scales override implicit percentage typing unless a percent/rate cue is present.
9. Increased frozen retrieval/direct/derived bounds to 48/48/192.
10. Added v5 tests for aggregate windows, percentage formatting, monetary margin typing and selector fallback.
11. Updated Colab scripts, notebook, frozen experiment plan, documentation and integrity controls.

## Unchanged scientific gates

- minimum overall development candidate recall: 0.30;
- minimum direct/aggregate development recall: 0.75;
- semantic target risk: 0.20 at 95% confidence;
- minimum semantic calibration coverage: 0.05;
- minimum accepted development answers: 30;
- provenance target risk: 0.01 at 95% confidence;
- public test remains blocked until explicit development authorisation.

## Claim boundary

V5 engineering tests do not establish that the official FinQA gate or semantic calibration will pass. Only a fresh train/development run can establish that result.
