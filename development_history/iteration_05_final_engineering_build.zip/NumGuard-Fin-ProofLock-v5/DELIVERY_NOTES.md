# Delivery notes — ProofLock v5

## Package scope

This is a clean v5 implementation containing source code, tests, transparent fixtures, Colab scripts, research documentation and local engineering-assurance outputs. It excludes official FinQA files, model weights, prior-version selectors/checkpoints and manufactured empirical findings.

## Evidence that triggered v5

The v4 development archive showed that overall recall passed but direct/aggregate recall remained at 71.43%, below the frozen 75% threshold. It also showed that the learned pairwise ranker materially underperformed the deterministic heuristic under grouped out-of-fold top-1 evaluation. The next version therefore changes selector control, aggregate candidate construction and answer-format normalisation; it does not weaken the gates.

## V5 changes

- cross-validated safe selector blending with deterministic fallback;
- bounded three-/five-period aggregate windows;
- metric/entity-conditioned cross-axis aggregate groups;
- percentage-marker omission normalisation for percentage-typed candidates;
- monetary-scale override for non-percentage margin questions;
- 48 retrieved evidence items, 48 direct candidates and 192 derived candidates plus abstention;
- updated tests, notebook, frozen experiment plan and source manifest.

## Required local status

```text
145 passed
QUALITY GATE PASSED
SOURCE MANIFEST PASSED
```

Local execution verifies parser, ledger, retrieval, candidate construction, trie legality, proof certificates, safe selector semantics, paired method output, perturbation behaviour, reports and package integrity. It does not establish v5 FinQA candidate-gate performance or model accuracy.

## Required next action

Fit a fresh v5 selector and run the development gate. Do not run public-test inference unless `run_colab_dev.sh` ends with:

```text
SEMANTIC CALIBRATION GATE PASSED. The frozen public-test script is now authorised.
```
