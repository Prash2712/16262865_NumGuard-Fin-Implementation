# Verification outputs

This directory is populated by `run_local_verification.sh`. Outputs are transparent engineering assurance only and are not official FinQA model results.
