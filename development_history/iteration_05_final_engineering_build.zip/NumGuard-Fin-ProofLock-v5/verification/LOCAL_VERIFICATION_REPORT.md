# Local verification report

**Status: PASS**

This report records engineering verification of the research artefact. It does not substitute for the official FinQA development and public-test experiments with FLAN-T5.

## Executed checks

- 145 unit and integration tests passed.
- All 11 supported transparent cases were present in the question-conditioned proof lattice.
- The deliberately unsupported case produced `INSUFFICIENT_EVIDENCE`.
- Thirteen methods produced 156 paired records under one configuration ID.
- Direct, derivation, selector-guided and risk-controlled hard locks produced zero unsupported complete-answer escapes.
- Every committed hard-lock answer carried structured evidence claims and a confidence value.
- All applicable candidate-mechanism counterfactual checks passed across five perturbation families.
- The maximum lattice size remained within 48 direct + 192 derived + one abstention candidate.
- Separate direct and derived candidate bounds were respected.
- Prediction records include selector margin plus semantic- and provenance-risk fields.
- JSONL proof certificates remained nested objects and the blinded manual-review package was generated.
- Prompt diagnostics, operation diagnostics and corrected end-to-end timing fields were present.

## Three-role review

### Supervisor gate
The design directly addresses evaluation trade-offs, operational definitions, model limitations, artefact–narrative integration, failure analysis and data provenance. The novelty claim is narrow and positioned against constrained decoding, selective prediction, table robustness and recent finance-aware work.

### Scientist gate
The parser, ledger, retrieval, bounded lattice, proof verifier, sequence trie, calibration, statistical summaries, checkpoints and counterfactual transformations are separately testable. Reference answers remain isolated from inference-time construction.

### Marker gate
The package contains a frozen split protocol, integrity validator, claim–evidence register, paired statistical treatment, blinded manual review, model-output perturbation audit and explicit limitations. Final claims remain conditional on official development and public-test evidence.

## Commands executed

```bash
PYTHONPATH=src pytest -q
PYTHONPATH=src python scripts/run_engineering_verification.py
PYTHONPATH=src python scripts/quality_gate.py
```
