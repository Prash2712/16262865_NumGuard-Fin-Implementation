# Development diagnostic v4 findings

## Status

The v4 development candidate gate failed and correctly blocked FLAN-T5 inference and public-test execution.

## Frozen-gate results

| Metric | Result | Requirement | Status |
|---|---:|---:|---|
| Final candidate recall | 32.03% | 30.00% | Pass |
| Pre-selector candidate recall | 43.63% | Diagnostic | — |
| Unpruned same-retrieval recall | 52.81% | Diagnostic | — |
| Expanded-ledger recall | 56.49% | Diagnostic | — |
| Direct/aggregate recall | 71.43% | 75.00% | Fail |

## Failure-stage counts

- candidate generation: 197;
- selector ranking: 123;
- operation schema: 119;
- retrieval or bounded context: 68;
- bounded pruning: 33;
- extraction or program constant: 29;
- retrieval: 23;
- successful recall: 279.

## Selector finding

The train selector report contained 1,309,380 candidate rows and 4,710 positive rows. Grouped out-of-fold top-1 accuracy conditional on candidate recall was 0.58%. Recalculation from the saved train rows showed that the deterministic heuristic obtained approximately 13.77% on the same operational top-1 criterion. The learned selector therefore lacked evidence to control deployment ranking.

## Direct/aggregate error pattern

The missed direct/aggregate cases included table averages, sums and maxima over three-year windows, percentage references without a percent marker, and a monetary gross-margin question incorrectly typed as a percentage. Several correct answers existed before bounded retrieval or before selector ranking, confirming that both representation and pruning—not only arithmetic grammar—required correction.

## V5 response

V5 introduces safe learned/heuristic blending, bounded aggregate windows, cross-axis semantic aggregate pools, percentage-marker normalisation and monetary-scale answer typing. The frozen gate thresholds are not weakened.
