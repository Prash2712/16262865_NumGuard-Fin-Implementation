# Claim–evidence register

No headline conclusion may be written until the corresponding frozen evidence satisfies this register.

| Candidate claim | Required evidence | Decision rule | Prohibited overclaim |
|---|---|---|---|
| Whole-sequence locking reduces unsupported complete answers | Frozen public-test paired comparison against baseline | Effect direction, interval, paired test and constraint escapes reported | “The model cannot hallucinate” |
| Sequence locking is stronger than fragment masking | Fragment ablation versus hard locks plus escape examples | Lower unsupported rate or an honest null finding | “All token constraints are equivalent” |
| V5 improves direct/aggregate candidate availability over v4 | Frozen v4 diagnostic and fresh v5 development candidate audit under disclosed bounds | Material improvement with operation and failure-stage breakdown | “Aggregate windows guarantee recall” |
| Safe blending prevents selector degradation on train OOF ranking | Selector training report | Blended grouped OOF top-1 is not below heuristic under the frozen grid/tie rule | “The selector is always correct” |
| Learned influence improves ranking | Grouped train report plus dev/test conditional selection | Positive learned weight and improved downstream selection with uncertainty | “Learning necessarily beats rules” |
| Typed derivations preserve semantic roles | Certificates, operation diagnostics and worked cases | Correct operands, periods and scales demonstrated; failures retained | “A valid derivation is always the right derivation” |
| Semantic calibration controls committed-answer error | Feasible development threshold and frozen public-test risk–coverage curve | Risk and confidence bound reported with non-zero coverage | “Abstention solves errors” |
| Provenance calibration controls uncertified commitment | Separate provenance threshold and curve | Unsupported/proof-invalid risk reported separately | “Provenance equals correctness” |
| Certificates are auditable | Certificate completeness and manual inspection | Every committed hard-lock answer carries structured claims | “A certificate proves the reference answer” |
| Decisions depend on relevant evidence | Candidate and model-output counterfactual audits | Pass rates and failures by perturbation and layer | “The model understands the report” |
| The system remains useful | Accuracy, coverage, invalid rate, abstention and latency | Safety benefits and costs presented together | Safety rate without usefulness cost |
| Residual errors have identifiable causes | Completed blinded review and agreement check | Manual labels frozen before key join | Automatic suggestions presented as findings |

## Adverse-result policy

Null or negative outcomes remain valid results. The public-test configuration, selector and thresholds must not be changed after outcomes are viewed. Any changed run is exploratory unless a new untouched evaluation split is available.
