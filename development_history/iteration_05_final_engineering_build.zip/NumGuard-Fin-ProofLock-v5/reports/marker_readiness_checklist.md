# Marker-readiness checklist

## V5 package assurance

- [x] Research question, scope and inference-time boundary are explicit.
- [x] V1–v4 adverse diagnostics are preserved rather than hidden.
- [x] V4 failure mechanisms and v5 responses are documented.
- [x] Source manifest, decision log and frozen experiment plan are present.
- [x] Local tests and quality-gate outputs are labelled engineering assurance.
- [x] No official FinQA model result is manufactured in the package.

## Before official development execution

- [ ] ZIP checksum matches the released SHA-256.
- [ ] Fresh v5 folder; no v1–v4 selector, checkpoints or results copied in.
- [ ] CUDA preflight passes.
- [ ] Source manifest passes after removing generated `egg-info` only.
- [ ] Fresh v5 selector is trained on FinQA train.
- [ ] Selector report records heuristic, learned and blended grouped OOF top-1.

## Development gate and calibration

- [ ] Overall candidate recall is at least 0.30.
- [ ] Direct/aggregate recall is at least 0.75.
- [ ] Failure-stage audit is retained regardless of outcome.
- [ ] Full paired development experiment runs only after candidate-gate pass.
- [ ] Semantic calibration is feasible at non-zero coverage and ≥30 accepts.
- [ ] Provenance calibration is reported separately.
- [ ] Exact public-test authorisation line is present.

## Final evaluation and dissertation

- [ ] Public test is run once under frozen hashes and thresholds.
- [ ] All 13 methods use identical test examples.
- [ ] Accuracy, unsupported rate, coverage, abstention, latency and truncation are reported together.
- [ ] Candidate recall and conditional selection accuracy are separated.
- [ ] Confidence intervals and paired tests are included.
- [ ] Counterfactual audits report denominators and failures.
- [ ] Blinded manual failure review is completed before joining the key.
- [ ] Claims follow the claim–evidence register.
- [ ] Limitations explicitly distinguish provenance validity from semantic correctness.
