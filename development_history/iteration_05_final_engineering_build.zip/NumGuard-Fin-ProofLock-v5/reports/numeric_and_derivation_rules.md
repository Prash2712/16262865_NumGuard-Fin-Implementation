# Numeric normalisation and typed derivation rules

## Complete-span numeric parsing

The parser consumes complete numeric spans and supports integers, decimals, leading decimals, comma-grouped values, explicit signs, accounting negatives, currency symbols, percentages and thousand/million/billion/trillion scales. It does not split years or long integers into digit fragments.

Each evidence item stores its displayed value and, where applicable, a base-unit value. Percentages remain percentage magnitudes for answer comparison and are converted to fractions only inside licensed multiplication.

## Frozen equality rules

- absolute tolerance: `0.01`;
- relative tolerance: `0.005`;
- percentage compatibility is normally required;
- a missing `%` marker is accepted only when the candidate is independently typed as a percentage and its numeric magnitude matches under the frozen tolerances;
- scale or unit mismatches are not hidden by tolerance.

The percentage-marker rule handles benchmark formatting such as reference `27.9` for a question explicitly asking for a percentage. It does not equate `0.279` with `27.9`.

## Answer typing

Explicit percentage/rate language licenses a percentage answer. Words such as “margin” alone do not override an explicit monetary target such as “in millions”; such answers remain plain monetary values.

## Direct proof

A direct candidate must originate from retrieved evidence and retain a stable source ID. Its certificate records row, column, period, metric, currency, scale and source type where available. A period-only match is insufficient when the question names a specific metric.

## Typed derivation schemas

### Subtraction and absolute difference

For ordered periods, the default direction is later minus earlier. Absolute difference is permitted only when requested.

### Percentage change and indexed return

```text
(new - old) / old * 100
indexed_value - 100
```

Division by zero is forbidden.

### Ratio, percentage of total and margin

```text
numerator / denominator
numerator / denominator * 100
profit_or_income / revenue_or_sales * 100
```

Roles are inferred from question structure. Cross-scale operands are converted through base-unit values before division.

### Sum, average, minimum and maximum

```text
sum(x1, ..., xn)
average(x1, ..., xn) = sum(x1, ..., xn) / n
min(x1, ..., xn)
max(x1, ..., xn)
```

Operands must form a compatible question-conditioned table group. V5 considers requested-period sets, contiguous windows and bounded combinations within compatible rows or columns. This permits a requested three-year window inside a longer table while avoiding unrestricted subset enumeration.

Precomputed total, subtotal, average, mean, minimum, maximum, highest and lowest cells remain available as direct evidence but are excluded when recomputing the same aggregate from atomic members.

### Product and licensed constants

Product is permitted for compatible quantity/rate calculations. Constants such as 100, 12, 4 or a stated period count are licensed only when justified by the question, operation schema or evidence.

### Bounded two-stage forms

V5 supports typed composites such as subtract-then-divide, add-then-divide, aggregate comparison and percentage conversion. Every stage records its operands and operation in the certificate.

## Candidate bounds and pruning

The frozen v5 deployment limits are:

- retrieval top-k: 48 evidence items;
- at most 48 direct numeric candidates;
- at most 192 derived numeric candidates;
- one exact abstention candidate;
- maximum complete lattice size: 241.

Candidate generation may create a bounded pre-pruning pool, but final deployment respects these limits. Ranking and diversity rules cannot change proof validity.

## Certificate validity

A valid certificate contains the complete answer, proof type, operation, evidence IDs, structured evidence claims, expression, answer type and candidate confidence. Certificate validity establishes provenance structure, not semantic correctness.
