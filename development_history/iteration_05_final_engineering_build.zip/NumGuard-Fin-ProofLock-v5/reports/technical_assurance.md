# Technical assurance

## Scope

Local verification demonstrates software integrity on transparent fixtures. It is not an official FinQA/FLAN-T5 empirical result.

## Numeric and evidence assurance

Unit tests cover complete-span parsing, signs, accounting negatives, scale conversion, percentages, year/value disambiguation, table orientation, period inheritance and stable evidence IDs. Retrieval tests exercise protected metric, period and operand-role evidence.

## Proof-language assurance

Transparent cases cover direct lookup, difference, percentage change, ratio, percentage of total, average, sum, product, table aggregates, negative values and explicit abstention. V5 adds tests for a requested three-year aggregate window embedded inside a longer row, percentage-marker normalisation and monetary “margin” typing.

## Safe-selector assurance

The learned selector is fitted only on train candidate labels. Grouped cross-validation is by source report. Its operational objective is within-question top-1 selection conditional on candidate availability. The frozen blend grid selects learned influence only when grouped out-of-fold top-1 improves over the deterministic heuristic; ties favour less learned influence. The selected blend weight, heuristic top-1, learned OOF top-1, blended OOF top-1 and fallback status are written to the training report.

The train candidate population uses the same 48/192 deployment bounds, avoiding a hidden distribution change and reducing memory compared with an unnecessary two-times-wide pool. The complete selector JSON is hashed and checked before public-test execution.

## Constraint assurance

Whole-answer trie tests confirm that legal prefixes can terminate only at certified answers or exact abstention. Engineering verification requires zero hard-lock escapes and a structured proof certificate for every committed numeric hard-lock response. Selector-guided priors apply only among legal trie branches.

## Capacity and prompt assurance

The deployment lattice is capped at 48 direct + 192 derived + one abstention. Prompt displays are separately bounded; the full certified lattice remains enforced outside the prompt. Input token counts and truncation flags are recorded.

## Reproducibility assurance

The package records configuration IDs, dependency versions, hardware, seed, dataset hashes, selector hash, source manifest, experiment manifests, thresholds and checkpoint state. Scripts use fail-fast shell behaviour and resumable checkpoints. Source-manifest verification excludes generated results but detects changes to frozen source and documentation.

## Claim control

Engineering outputs, v1–v4 development diagnostics and any future v5 official development/public-test evidence are separated. No statement that v5 passes the candidate or calibration gate is permitted until a fresh official run produces that evidence.
