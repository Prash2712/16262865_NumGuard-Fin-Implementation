# Supervisor-feedback alignment

## Evaluation rigour and safety–coverage trade-off

V5 reports accuracy, valid-response rate, unsupported-answer rate, abstention, coverage, latency, candidate recall and conditional selection. Semantic and provenance risk are calibrated separately with full risk–coverage curves, confidence bounds, minimum coverage and minimum accepted-example requirements. Hard blocking is not presented as success without its usefulness cost.

## Operational definition of provenance and derivation

The numeric rules define supported parsing, scales, percentage handling, tolerances, table coordinates, evidence IDs, permitted operations, constants, aggregate windows, rounding and certificate fields. The proof grammar is bounded rather than unrestricted arithmetic closure.

## Model choice and generalisation

FLAN-T5-base is retained because it has open weights, direct logits access and reproducible Hugging Face generation. Results are bounded to this model and disclosed configuration unless a separately frozen robustness experiment is executed. No universal safeguard claim is made.

## Artefact integration

The Evidence Ledger, question-conditioned retrieval, typed proof lattice, prefix-trie `LogitsProcessor`, safe selector, proof certificates and calibrated abstention are integrated in the research design and experiment outputs. Worked transparent fixtures and failure taxonomy support inspection.

## Adverse development findings

The project does not suppress failed gates. V1–v4 diagnostics are retained. V4 passed overall recall but failed direct/aggregate recall and exposed a learned selector that underperformed the deterministic heuristic. V5 addresses those measured defects while keeping the same candidate and calibration decision rules.

## Ethics and data

The study uses public secondary benchmark data, no human participants and no newly collected personal data. Dataset, source, model and configuration hashes are recorded. The dissertation must state licences accurately and avoid claims of regulatory compliance.

## Claim discipline

The claim–evidence register prevents conclusions before frozen public-test evidence exists. Engineering fixtures, development diagnostics and official model results are kept distinct.
