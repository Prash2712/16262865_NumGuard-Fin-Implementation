# Research design

## Aim and research question

NumGuard-Fin ProofLock v5 evaluates whether a table-aware, proof-locked decoding lattice can reduce unsupported numerical generation while preserving useful answer coverage and derivation fidelity in financial question answering, without fine-tuning the language model.

The intervention is inference-time only. Within each paired comparison, the model, FinQA example, random seed and output budget remain fixed while the answer-control mechanism changes.

## Development history and v5 rationale

V1 established that complete-answer locking can prevent outputs outside a certified lattice, but its shallow candidate generator and heuristic confidence score produced low useful coverage. V2 failed its candidate gate at 27.44% overall recall and 45.71% direct/aggregate recall. V3 increased those figures to 43.40% and 68.57%, but still failed the frozen 75% direct/aggregate requirement.

V4 added bidirectional aggregation and a pairwise selector. Its official development candidate gate stopped before FLAN-T5 inference. On 871 numeric development examples, final frozen-lattice recall was 32.03%, pre-selector recall was 43.63%, unpruned recall under the same retrieval was 52.81%, expanded-ledger recall was 56.49%, and direct/aggregate recall was 71.43%. The train report also showed that the learned ranker had only 0.58% grouped out-of-fold top-1 accuracy conditional on candidate availability, while the disclosed deterministic heuristic achieved approximately 13.77% on the same saved candidate rows.

V5 therefore addresses two measured failure mechanisms without weakening any gate:

1. the learned selector is a cross-validated safe blend and is allowed zero influence when it does not improve grouped out-of-fold within-question top-1 selection;
2. aggregate generation covers bounded contiguous and question-conditioned table windows, including periods embedded within longer rows or columns;
3. percentage marker omission is normalised only for percentage-typed candidates with equal numeric magnitude;
4. monetary metrics containing words such as “margin” remain plain numeric answers when the question explicitly asks for a monetary scale;
5. retrieval and lattice bounds are expanded but remain frozen and finite: 48 evidence items, 48 direct candidates, 192 derived candidates and exact abstention.

Earlier diagnostics remain development evidence and are excluded from public-test claims.

## Architecture

### 1. Structured financial evidence ledger

Each numeric item retains its source type, raw and canonical forms, base-unit value, percentage status, table coordinates or narrative offsets, row and column labels, period, scale, currency and stable evidence ID. Values in the 1900–2099 range are classified as years only when table structure assigns them a period role.

### 2. Question-conditioned retrieval

The intent parser identifies operation families, metric/entity terms, numerator and denominator roles, requested periods, target scale, aggregation cues and question-licensed constants. Retrieval protects relevant rows, columns, periods and role-bearing evidence before global filling.

### 3. Bounded typed proof language

The proof lattice supports direct lookup, subtraction, percentage change, indexed return, ratio, percentage of total, margin, sum, average, product, table minimum/maximum, row/column aggregates, aggregate composites and bounded two-stage forms. Aggregate windows are enumerated only from compatible table groups and are capped before deduplication and final pruning. Precomputed summary cells are not recombined with their atomic members.

### 4. Safe selector

The train-only linear selector uses retrieval, metric, type, period, role, proof-family, depth, magnitude and interaction features. A grouped out-of-fold search chooses the learned blend weight from a frozen grid. Deployment score is:

```text
(1 - alpha) * heuristic_score + alpha * learned_score
```

Ties favour smaller `alpha`. `alpha = 0` is an explicit, recorded fallback rather than a hidden failure. Reference answers supply train labels only and never enter inference-time retrieval, proof construction, prompting or decoding.

### 5. Whole-sequence proof locks

Certified complete answer strings are encoded in a token-prefix trie. A token is legal only when the resulting prefix can terminate as a certified answer or exact abstention. Selector-guided locking may alter ranking among legal branches but cannot admit a non-certified answer. Fragment-level masking remains a deliberately weak ablation.

### 6. Separate risk controls

Semantic risk and provenance risk are calibrated separately. A development threshold is feasible only when its one-sided confidence bound satisfies the target with at least 5% coverage and 30 accepted examples. Zero-coverage or infeasible calibration blocks public-test execution.

## Split discipline

- **Train:** selector fitting only.
- **Development:** candidate-quality gate, paired model experiment and calibration.
- **Public test:** one frozen execution only after explicit authorisation.

No public-test outcome may be used to revise v5.

## Hypotheses

- H1: whole-sequence locking reduces unsupported complete answers relative to unconstrained generation.
- H2: whole-sequence locking produces fewer escapes than fragment-token masking.
- H3: v5 bounded aggregate-window construction improves direct/aggregate candidate recall over the frozen v4 diagnostic.
- H4: safe blended ranking is never worse than the heuristic on grouped out-of-fold train top-1 selection by construction of the frozen blend rule.
- H5: selector-guided hard decoding improves semantic selection without weakening trie-level provenance guarantees.
- H6: development-calibrated abstention reduces semantic risk at measurable non-zero coverage.
- H7: proof-carrying outputs respond correctly to period, metric, support and scale perturbations while remaining invariant to irrelevant-number injection.

## Interpretive limits

A proof-valid answer may still be semantically wrong because the wrong evidence, operation, period, unit or scale was certified. V5 has not passed the official development gate until a fresh Colab train/development run establishes that result. The artefact does not establish universal factuality, regulatory compliance or production readiness.
