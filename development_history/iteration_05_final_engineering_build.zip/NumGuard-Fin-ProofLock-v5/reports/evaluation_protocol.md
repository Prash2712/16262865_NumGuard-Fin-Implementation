# Evaluation protocol

## Objective

Evaluate whether ProofLock v5 reduces unsupported numerical generation while preserving numeric correctness, derivation fidelity and useful answer coverage, without fine-tuning FLAN-T5.

## Data discipline

- FinQA train: selector fitting only.
- FinQA development: candidate gate, paired model experiment and threshold calibration.
- FinQA public test: one frozen final execution after explicit development authorisation.
- Numeric-answer examples are filtered by the disclosed loader; all methods use identical example IDs and seed.
- Reference answers and programs are isolated from inference-time retrieval, lattice construction, prompting and decoding.

## Frozen configuration

- model: `google/flan-t5-base`;
- seed: 42;
- input budget: 512 tokens;
- output budget: 24 tokens;
- beams: 4;
- retrieval top-k: 48;
- direct candidates: 48;
- derived candidates: 192;
- exact abstention: one;
- maximum lattice: 241.

## Candidate-quality gate

Before expensive model inference, the development split must satisfy:

- overall candidate recall ≥ 0.30;
- direct/aggregate reference recall ≥ 0.75.

The gate also records pre-selector, unpruned-same-retrieval and expanded-ledger recall, plus failure-stage attribution. A failed gate blocks model inference and public-test execution. Thresholds are not lowered after viewing diagnostics.

## Methods

1. baseline;
2. provenance prompt;
3. candidate-menu prompt;
4. post-hoc verifier;
5. fragment-token-lock ablation;
6–9. soft prefix biases 1, 3, 5 and 10;
10. direct proof lock;
11. derivation proof lock;
12. selector-guided proof lock;
13. risk-controlled proof lock.

All methods are paired on the same examples.

## Primary metrics

- numeric answer accuracy;
- valid numeric response rate;
- unsupported complete-answer rate;
- candidate recall;
- selection accuracy conditional on candidate recall;
- proof-validity rate conditional on numeric response;
- coverage and abstention metrics;
- semantic and provenance risk–coverage curves;
- latency and input truncation;
- coarse proof-operation agreement.

Candidate recall and conditional selection are reported separately so a construction failure is not mistaken for a ranking failure.

## Calibration

Semantic calibration uses `selector_guided_proof_lock` with target risk 0.20. Provenance calibration uses target risk 0.01. Both require:

- 95% one-sided confidence;
- minimum coverage 0.05;
- at least 30 accepted examples.

An infeasible or zero-coverage threshold is recorded as a negative result and blocks public-test execution.

## Statistical analysis

- paired bootstrap confidence intervals with 2,000 repetitions;
- exact McNemar tests for paired binary outcomes;
- full risk–coverage curves rather than a single favourable threshold;
- effect sizes and denominators reported alongside p-values.

## Counterfactual audits

Candidate-mechanism and model-output audits cover irrelevant-number injection, period swap, metric swap, support masking and scale change. A pass requires the expected invariant or directional response, not merely a valid certificate.

## Manual failure analysis

A blinded workbook and separate key support review of retrieval, extraction, operation schema, candidate construction, pruning, ranking, scale/unit, rounding, constraint escape, correct abstention, over-refusal, under-refusal and annotation ambiguity. Automatic suggestions are not presented as manual findings.

## Integrity blocks

Public-test execution is rejected when selector/configuration hashes, development predictions, manifest, calibration feasibility, coverage or accepted-example requirements do not match the frozen development state. Candidate lattices above 48 direct + 192 derived + abstention are invalid.
