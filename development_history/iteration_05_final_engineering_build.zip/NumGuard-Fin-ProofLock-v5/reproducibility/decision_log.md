# Decision log

## Frozen design decisions for v5

1. The language model remains `google/flan-t5-base`; no language-model fine-tuning is performed.
2. FinQA train is used only to fit the candidate selector.
3. FinQA development is used for the candidate gate, paired model evaluation and calibration.
4. FinQA public test is executed once only after explicit development authorisation.
5. Retrieval is bounded to 48 evidence items with protected row, column, role and period slots.
6. The deployment lattice is bounded to 48 direct candidates, 192 derived candidates and one abstention.
7. The selector is a grouped cross-validated safe blend of deterministic heuristic confidence and a within-question pairwise linear proof ranker.
8. The learned blend weight is selected from `0.00, 0.05, ..., 1.00`; ties favour the lower learned weight.
9. Selector training uses the frozen deployment candidate population, 24 strongest within-question negatives per positive and grouping by source report.
10. Pure whole-sequence locking and selector-guided whole-sequence locking are reported separately.
11. Selector-guided locking cannot admit tokens outside the certified trie.
12. Semantic calibration uses `selector_guided_proof_lock`, target risk 0.20, 95% one-sided confidence, minimum coverage 0.05 and at least 30 accepted examples.
13. Provenance calibration is separate at target risk 0.01 under the same coverage/sample gates.
14. Candidate gates remain 0.30 overall recall and 0.75 direct/aggregate recall; they were not lowered after v1–v4 diagnostics.
15. Maximum input length remains 512 tokens; compact prompt displays do not replace full-lattice enforcement.
16. Reference answers/programs never enter inference-time retrieval, candidate construction, prompting or decoding.
17. Any source, selector, configuration or calibration change after public-test execution creates an exploratory run rather than replacing the frozen result.

## Development evidence retained

- V1: proof-lock safety effect but low semantic quality and no feasible semantic-risk coverage.
- V2: failed candidate gate at 27.44% overall and 45.71% direct/aggregate recall.
- V3: 43.40% overall and 68.57% direct/aggregate recall; gate failed.
- V4: 32.03% final recall and 71.43% direct/aggregate recall; gate failed before FLAN-T5. The learned ranker achieved 0.58% grouped OOF top-1 conditional on recall versus approximately 13.77% for the deterministic heuristic on the saved train rows.

These diagnostics motivate v5 but are not public-test findings. V5 has no official result until a fresh train/development execution is completed.
