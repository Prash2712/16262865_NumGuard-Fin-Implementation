# Alignment with supervisor feedback

## 1. Evaluation rigour and safety–coverage cost

The repository reports numeric accuracy, valid coverage, explicit abstention, invalid responses, unsupported complete answers, proof validity, candidate recall, conditional selection accuracy, semantic risk, provenance risk, latency and confidence intervals. Four soft-prefix strengths provide a constraint curve. Public-test execution is blocked unless development calibration achieves the declared semantic-risk bound with at least 5% coverage and 30 accepted examples.

The v1 zero-coverage calibration is explicitly classified as infeasible rather than presented as a successful safety result.

## 2. Operational definitions

`reports/numeric_and_derivation_rules.md` fixes whole-span parsing, scale/percentage semantics, equality tolerances, typed operations, operand ordering, question-licensed constants, proof fields and the 16-direct/48-derived candidate bounds.

Provenance means membership in an allowed evidence-linked proof program with complete source claims. Semantic correctness is evaluated separately.

## 3. FLAN-T5 justification and limits

FLAN-T5 is used as the principal baseline because its weights and decoder logits are accessible, Hugging Face supports prefix/logit intervention, and the model is reproducible on a standard Colab GPU. The candidate selector is a separate lightweight logistic model fitted on FinQA train; FLAN-T5 weights remain unchanged.

Conclusions are restricted to the tested model, dataset and frozen configuration. A stronger open-weight model may be added only as a clearly labelled robustness experiment after the principal analysis is frozen.

## 4. Controlled claims

The artefact constrains complete numerical outputs relative to its proof lattice. It is not described as:

- universally correct;
- incapable of hallucination;
- a regulatory compliance guarantee;
- a substitute for professional financial review.

## 5. Artefact–narrative integration

- Evidence ledger operationalises source provenance.
- Row-complete retrieval preserves metric/period/operand roles.
- Intent parsing licenses operations, periods, constants and scale.
- The typed proof lattice exposes candidate recall and derivation coverage.
- The learned selector addresses ranking separately from generation.
- The whole-sequence trie implements the decoder-level lock.
- The post-hoc verifier provides a fallback comparison.
- Semantic/provenance calibration quantifies different safety notions.
- Counterfactual audits test evidence dependence.
- The blinded taxonomy explains residual failure modes.

## 6. Failure analysis and worked examples

The output package contains a blinded review workbook and separate key. The codebook distinguishes retrieval, extraction, intent, candidate recall, operand, operation, scale, rounding, ranking, constraint escape and abstention errors. Automatic routing suggestions are not treated as observed findings.

## 7. Ethics and data

The study uses public secondary benchmark data, no human participants and no newly collected personal data. Dataset hashes, split discipline and model/configuration provenance are recorded. The final dissertation must identify dataset and model licences accurately.

## 8. Marker-facing evidence

The claim–evidence register prevents conclusions from being written before the associated public-test evidence exists. Engineering fixtures, v1 diagnostic evidence and v2 official empirical evidence are separated so that mechanical assurance is not mistaken for model performance.
