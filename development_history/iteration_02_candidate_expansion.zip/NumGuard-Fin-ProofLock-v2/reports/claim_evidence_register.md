# Claim–evidence register

No headline conclusion may be written until the corresponding frozen evidence satisfies this register.

| Candidate claim | Required evidence | Decision rule | Prohibited overclaim |
|---|---|---|---|
| Whole-sequence locking reduces unsupported complete answers | Frozen public-test paired comparison against baseline | Effect direction, interval, paired test and zero hard-lock escapes reported | “The model cannot hallucinate” |
| Sequence locking is stronger than fragment masking | Fragment ablation versus hard locks plus escape examples | Lower unsupported rate or an honest null finding | “All token constraints are equivalent” |
| V2 improves candidate availability over v1 | V1 diagnostic and v2 dev/test candidate recall under disclosed bounds | Material improvement with operation-level breakdown; no claim before rerun | “Multi-step proofs guarantee recall” |
| Typed derivations preserve semantic roles | Proof-operation diagnostic, certificates and worked cases | Correct operands/periods/scale demonstrated; failures retained | “A valid derivation is always the right derivation” |
| The learned selector improves ranking | Grouped train diagnostics plus dev/test selection accuracy conditional on recall | Improvement over heuristic ranking with uncertainty | “The selector predicts correctness perfectly” |
| Semantic calibration controls committed-answer error | Feasible dev threshold and frozen public-test risk–coverage curve | Risk and confidence bound reported with non-zero coverage | “Abstention solves errors” |
| Provenance calibration controls uncertified commitment | Separate provenance threshold/curve | Unsupported/proof-invalid risk reported separately | “Provenance equals correctness” |
| Certificates are auditable | Certificate completeness, proof-validity rate and manual inspection | Every committed hard-lock answer carries structured claims | “A certificate proves the reference answer” |
| Decisions depend on the relevant evidence | Candidate and model-output counterfactual audits | Pass rates by perturbation, layer and denominator; failures analysed | “The model understands the report” |
| The system remains useful | Accuracy, coverage, invalid rate, abstention and latency | Safety benefits and costs presented together | Safety rate without usefulness cost |
| Residual errors have identifiable causes | Completed blinded manual review and agreement check | Manual labels frozen before key join | Automatic suggestions presented as findings |

## Adverse-result policy

Null or negative outcomes remain valid results. The public-test configuration, selector and thresholds must not be changed after outcomes are viewed. Any revised run is exploratory unless a new untouched evaluation split is available.
