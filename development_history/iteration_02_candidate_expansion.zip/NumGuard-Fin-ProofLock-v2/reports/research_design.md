# Research design

## Aim and research question

NumGuard-Fin ProofLock v2 evaluates whether a table-aware, proof-locked decoding lattice can reduce unsupported numerical generation while preserving useful answer coverage and derivation fidelity in financial question answering, without fine-tuning the language model.

The intervention is applied at inference time. The frozen language model, FinQA example, decoding seed and output budget are held constant across paired methods; the answer-control strategy is varied.

## Why v2 was necessary

The first official development diagnostic showed that whole-sequence locking was mechanically effective at preventing answers outside the certified lattice, but the shallow one-step lattice recalled only a small fraction of reference answers and its heuristic confidence score could not support non-zero semantic-risk-controlled coverage. V2 therefore changes the upstream evidence, proof and selection mechanisms before any public-test execution.

The v1 diagnostic is retained as development evidence, not used as a final public-test result.

## Architecture

### 1. Structured financial evidence ledger

Every extracted number retains:

- a stable evidence identifier;
- source type (table or narrative);
- displayed and canonical numeric forms;
- table row, column, period and metric labels, or narrative offsets;
- currency, scale, sign and percentage status.

Percentage values do not inherit monetary scales. Base-unit values are used only where scale-aware arithmetic requires them; FinQA comparison remains based on the displayed answer convention.

### 2. Question-conditioned, row-complete retrieval

The intent parser extracts a bounded operation family, requested periods, target scale, aggregation cues, question-licensed constants and numerator/denominator role terms. Retrieval ranks table rows and then expands the requested cells, rather than treating isolated cells as unrelated text fragments. This preserves row identity, cross-period alignment and numerator/denominator candidates.

### 3. Bounded typed proof language

The proof lattice supports direct lookup and bounded financial schemas:

- subtraction and absolute difference when licensed;
- percentage change;
- ratio and percentage-of-total;
- margin;
- addition and n-ary sum;
- average and n-ary table average;
- product, including percentage-by-amount calculations;
- table minimum and maximum;
- question-licensed constants and period counts.

Candidate construction is capped at 16 direct and 48 derived numeric candidates, plus the exact abstention sequence. It is therefore not an unrestricted arithmetic search.

### 4. Candidate correctness selector

A lightweight logistic selector is fitted on FinQA **train** candidate labels. Its features concern retrieval, semantic compatibility, proof structure and ambiguity; it does not change FLAN-T5 weights. Reference answers are used only as selector-training labels and are never exposed to retrieval, candidate construction, prompts or decoding.

Grouped cross-validation is recorded by source report to reduce leakage between questions from the same document. The selector is frozen before development calibration.

### 5. Whole-sequence proof lock

Every certified answer is encoded as a complete token sequence in a prefix trie. A token is legal only when the resulting prefix can terminate as a certified answer or the exact abstention response `INSUFFICIENT_EVIDENCE`. This is stricter than masking digit fragments, which remains only as a deliberately weak ablation.

### 6. Separate risk controls

Two risks are reported separately:

- **semantic risk:** the committed numeric answer is incorrect for the question;
- **provenance risk:** the committed answer is unsupported or lacks a valid proof certificate.

Development calibration selects a threshold only when the stated risk upper bound is achieved with at least 5% coverage and at least 30 accepted examples. An infeasible or zero-coverage calibration blocks the public-test script instead of being presented as a successful safety result.

## Split discipline

- **FinQA train:** fit the lightweight candidate selector only.
- **FinQA development:** candidate-quality gate, paired model evaluation and risk calibration.
- **FinQA public test:** one frozen final execution, authorised only after all development gates pass.

No public-test labels are used to revise the method.

## Primary hypotheses

- H1: whole-sequence proof locking reduces unsupported complete-answer generation relative to unconstrained generation.
- H2: whole-sequence locking produces fewer constraint escapes than fragment-token masking.
- H3: the typed multi-step lattice materially improves candidate recall over the v1 shallow lattice.
- H4: the learned selector improves candidate choice conditional on the correct answer being present.
- H5: development-calibrated abstention can reduce semantic risk at a measurable, non-zero coverage cost.
- H6: proof-carrying answers respond correctly to period, metric, support and scale perturbations while remaining invariant to irrelevant-number injection.

## Causal and interpretive limits

Paired comparisons estimate the effect of answer-control strategy under this implementation. Retrieval, intent parsing, proof construction, model ranking and selector quality remain interacting mediators. A proof-valid answer can still be semantically wrong when the wrong row, period, operation, unit or operand is certified.

Claims are restricted to the disclosed FinQA splits, models, prompts, candidate rules and thresholds. The system is not claimed to guarantee regulatory compliance, universal factuality or correctness outside this evaluation.
