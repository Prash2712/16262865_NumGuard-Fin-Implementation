# Exact Google Colab workflow for ProofLock v2

Use Google Colab for the empirical runs. Keep the complete project folder in Google Drive so checkpoints survive runtime disconnections.

## 1. Mount Drive

```python
from google.colab import drive
drive.mount('/content/drive')
```

## 2. Enter the v2 project folder

```bash
%cd "/content/drive/MyDrive/NumGuard-Fin-ProofLock-v2"
!pwd
!ls
```

Do not merge this folder with the earlier v1 project.

## 3. Install the environment after every new runtime

```bash
!python -m pip install -q -r requirements.txt
!python -m pip install -q -e . --no-deps
```

```python
import os, sys
PROJECT = "/content/drive/MyDrive/NumGuard-Fin-ProofLock-v2"
SRC = PROJECT + "/src"
os.chdir(PROJECT)
if SRC not in sys.path:
    sys.path.insert(0, SRC)
os.environ["PYTHONPATH"] = SRC
import numguard_fin
print(numguard_fin.__file__)
```

## 4. Confirm the GPU

```python
import torch
print("CUDA available:", torch.cuda.is_available())
print("GPU:", torch.cuda.get_device_name(0) if torch.cuda.is_available() else "NO GPU")
assert torch.cuda.is_available(), "Select Runtime -> Change runtime type -> T4 GPU"
```

## 5. Run engineering verification

```bash
!bash run_local_verification.sh
!python scripts/verify_source_manifest.py
```

Required outcome:

```text
121 passed
QUALITY GATE PASSED
SOURCE MANIFEST PASSED
```

A larger test count is acceptable. No failed test may be ignored.

## 6. Download official FinQA and run preflight

```bash
!python scripts/download_finqa.py
!python scripts/preflight.py --require-cuda
!ls -lh data/raw
```

Required preflight fields:

```text
"status": "passed"
"problems": []
```

## 7. Fit the candidate selector on FinQA train

This stage does not fine-tune FLAN-T5. It fits a lightweight logistic candidate scorer using train-split candidate labels only.

```bash
!mkdir -p results models
!set -o pipefail; bash run_colab_train_selector.sh 2>&1 | tee -a results/selector_training.log
```

Inspect:

```bash
!ls -lh models/candidate_selector.json
!cat models/candidate_selector_training_report.json
!cat models/candidate_selector.json | head -n 40
```

The main files are:

```text
models/candidate_selector.json
models/candidate_selector_training_report.json
results/selector_training_rows.csv
results/selector_training.log
```

## 8. Run development candidate gate and calibration

```bash
!set -o pipefail; bash run_colab_dev.sh 2>&1 | tee -a results/dev_v2_execution.log
```

The script performs these stages in order:

1. candidate recall diagnostic on the development split;
2. candidate-quality gate;
3. paired FLAN-T5 development experiment only when the candidate gate passes;
4. semantic-risk calibration;
5. provenance-risk calibration;
6. public-test authorisation only when semantic calibration has non-zero useful coverage.

### Candidate gate failure

When the output says:

```text
CANDIDATE QUALITY GATE FAILED
```

stop. Do not run the public test. Package and upload:

```text
results/dev_candidate_diagnostic/
models/candidate_selector.json
results/selector_training.log
results/dev_v2_execution.log
```

### Calibration gate failure

When the output says:

```text
SEMANTIC CALIBRATION GATE FAILED
```

stop. Do not run the public test. Preserve and upload the development outputs for another method revision.

### Development success

The public test is authorised only when the final line states:

```text
SEMANTIC CALIBRATION GATE PASSED. The frozen public-test script is now authorised.
```

Confirm:

```bash
!cat results/dev_calibration/calibration.json
!cat results/dev_calibration/provenance_calibration.json
```

The semantic calibration file must contain:

```text
"feasible": true
```

Do not edit either calibration file.

## 9. Run the frozen public test once

```bash
!set -o pipefail; bash run_colab_test.sh 2>&1 | tee -a results/final_test_execution.log
```

The script refuses to run when the frozen selector or feasible calibration is missing.

## 10. Resume after a Colab disconnection

After a new runtime:

1. mount Drive;
2. return to the v2 project folder;
3. reinstall requirements and editable package;
4. restore `sys.path`;
5. confirm CUDA;
6. rerun the exact interrupted script.

The experiment uses per-example checkpoints and `--resume`. Do not delete or re-extract the project while a run is in progress.

## 11. Package evidence

```bash
!zip -r NumGuard_Fin_ProofLock_v2_Evidence.zip \
  models \
  results/selector_training.log \
  results/dev_candidate_diagnostic \
  results/dev_calibration \
  results/final_test \
  figures/dev_calibration \
  figures/final_test \
  reproducibility \
  verification \
  reports
```

```bash
!sha256sum NumGuard_Fin_ProofLock_v2_Evidence.zip
```

Upload the complete evidence ZIP for audit before writing final findings.
