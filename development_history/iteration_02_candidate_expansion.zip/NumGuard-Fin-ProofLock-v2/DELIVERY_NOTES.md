# Delivery notes — ProofLock v2

## Delivered state

This package is a clean engineering revision built after reviewing the genuine 871-example FinQA development diagnostic from v1. It contains no manufactured FLAN-T5 findings and no official FinQA data or model weights.

## V1 diagnostic retained separately

The earlier archive `NumGuard_Dev_Diagnostic_v1.zip` must be preserved as development evidence. Its main finding was that whole-sequence locks greatly reduced unsupported complete answers, but shallow candidate recall and heuristic confidence produced an infeasible zero-coverage semantic calibration.

## V2 changes

- typed multi-step proof language;
- row-complete retrieval;
- cross-scale arithmetic through base values;
- percentage × amount correction;
- multi-operand table aggregation;
- train-only lightweight candidate selector;
- development candidate-quality gate;
- separate semantic and provenance calibration;
- automatic public-test blocking when calibration is infeasible;
- 121 passing unit and integration tests;
- unchanged whole-answer trie and explicit abstention mechanism.

## Required execution order

```text
local verification
-> FinQA download and preflight
-> train candidate selector
-> development candidate gate
-> paired development model run
-> semantic/provenance calibration
-> public test only when authorised
```

Do not copy v1 checkpoints into v2. Do not run the public test merely because the code executes; the development gate is part of the frozen research protocol.
