# Reproducibility decision log

## Frozen design decisions for v2

- Research question: table-aware proof-locked numeric decoding with useful coverage and derivation fidelity, without language-model fine-tuning.
- FinQA train is used only to fit the lightweight candidate selector.
- FinQA development is used for candidate gates, paired method evaluation and risk calibration.
- FinQA public test is executed once only after development gates pass.
- Model: `google/flan-t5-base` as the principal open-weight, logit-accessible baseline.
- Seed: 42.
- Numeric examples only.
- Retrieval limit: 16 evidence items after row-aware expansion.
- Candidate bounds: 16 direct, 48 derived and one abstention.
- Whole-answer token-prefix trie is the principal hard-lock mechanism.
- Fragment-token masking is retained only as a weak ablation.
- Selector: class-balanced logistic regression with the frozen feature schema in `selector.py`.
- Selector grouping: source report/document during cross-validation.
- Semantic risk target: 0.20 with 95% one-sided upper confidence bound.
- Provenance risk target: 0.01 with 95% one-sided upper confidence bound.
- Minimum calibration coverage: 0.05.
- Minimum accepted development examples: 30.
- Candidate gate: overall recall >= 0.30 and direct/aggregate recall >= 0.75.
- Public-test execution is blocked when the candidate gate or semantic calibration is infeasible.
- No threshold or selector retuning after public-test inspection.
- Reference answers are excluded from inference-time retrieval, candidate construction, prompts, certificates and decoding.
- Official FinQA programs are used only for post-prediction diagnostic operation-family comparison.

## V1 diagnostic decision

The preserved v1 development run showed low candidate recall and zero feasible semantic-risk-controlled coverage. It is treated as a method-development finding and is not used as the final public-test evaluation.

## Change control

Any code, selector, threshold, prompt, candidate-bound or retrieval change after an authorised public-test run creates a new exploratory configuration. The original frozen run and manifests must remain unchanged.
