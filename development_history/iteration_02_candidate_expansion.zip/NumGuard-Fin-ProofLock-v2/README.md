# NumGuard-Fin ProofLock v2

**Proof-locked numerical decoding with typed financial derivations, row-complete retrieval, learned candidate risk scoring and non-zero coverage gates**

NumGuard-Fin is a reproducible research artefact for evaluating whether an inference-time numeric safety layer can reduce unsupported complete-number generation in financial question answering without fine-tuning the underlying language model.

## Research question

> Can a table-aware, proof-locked decoding lattice reduce unsupported numerical generation while preserving useful answer coverage and derivation fidelity in financial question answering, without model fine-tuning?

## Why v2 exists

The first official development diagnostic was scientifically useful but not suitable for a final public-test run. Whole-sequence locking reduced uncertified answers, yet the shallow candidate lattice recalled only a small share of correct FinQA answers and the heuristic confidence score could not produce a non-zero operating point under the declared semantic-risk target. That run remains archived separately as `NumGuard_Dev_Diagnostic_v1.zip`.

V2 addresses the diagnosed causes rather than hiding the result:

- row-complete evidence retrieval preserves comparison years and denominator rows;
- percentages no longer inherit table-wide monetary scales;
- arithmetic uses base values when scales differ;
- percentage values are treated as fractions during multiplication;
- bounded multi-operand sum, average, minimum and maximum proofs are supported;
- multi-step percentage-change and percentage-of-total proofs are represented explicitly;
- a lightweight candidate selector is trained on the FinQA **train** split only;
- the FinQA **development** split is reserved for candidate gates and abstention calibration;
- public-test execution is automatically blocked when calibration is infeasible or coverage is zero.

## Core architecture

```text
FinQA example
  -> structured numerical evidence ledger
  -> question intent, periods, scale and operand-role cues
  -> row-complete table/narrative retrieval
  -> bounded typed proof lattice
  -> optional train-fitted candidate selector
  -> prompt, post-hoc, soft-prefix and whole-sequence proof-lock conditions
  -> proof certificate with evidence coordinates and expression
  -> separate provenance-risk and semantic-risk evaluation
  -> non-zero coverage calibration gate
  -> public test only after the development gate passes
```

## Proof language

The lattice is bounded to a maximum of **16 direct candidates, 48 derived candidates and one explicit abstention**. Supported proof families include:

- direct table or narrative lookup;
- subtraction and absolute difference;
- percentage change: `(new - old) / old × 100`;
- ratio and percentage-of-total using scale-normalised operands;
- margin;
- pairwise and multi-operand sum;
- pairwise and multi-period average;
- table minimum and maximum;
- multiplication, including percentage × amount;
- question-licensed constants such as explicit day, month or year counts.

The system does not enumerate unrestricted arithmetic combinations.

## Experimental conditions

All methods are paired on the same examples, evidence and model configuration:

1. `baseline`
2. `provenance_prompt`
3. `candidate_menu_prompt`
4. `posthoc_verifier`
5. `fragment_token_lock_ablation`
6. `soft_prefix_bias_1`
7. `soft_prefix_bias_3`
8. `soft_prefix_bias_5`
9. `soft_prefix_bias_10`
10. `direct_proof_lock`
11. `derivation_proof_lock`
12. `risk_controlled_proof_lock`

The hard lock operates over complete answer sequences through a token-prefix trie. A token is admissible only when the resulting prefix can terminate in a certified answer or `INSUFFICIENT_EVIDENCE`.

## Data split discipline

- **FinQA train:** fit the lightweight candidate selector. Language-model weights remain frozen.
- **FinQA development:** run the candidate-recall gate, evaluate paired methods and calibrate abstention.
- **FinQA public test:** run once, only when development calibration is marked feasible.

Reference answers are used only for training labels, diagnostics and evaluation. They are never exposed to retrieval, candidate construction, prompts, constrained decoding or certificate generation.

## Local engineering verification

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt
pip install -e . --no-deps
./run_local_verification.sh
python scripts/verify_source_manifest.py
```

The supplied package passes 121 unit and integration tests plus transparent proof, constraint, reporting and counterfactual checks. Outputs under `verification/` are engineering assurance, not dissertation findings.

## Official Colab workflow

```bash
python scripts/download_finqa.py
python scripts/preflight.py --require-cuda
bash run_colab_train_selector.sh
bash run_colab_dev.sh
```

`run_colab_dev.sh` first performs a cheap candidate-quality gate. If candidate recall is below the frozen thresholds, it stops before the expensive model run. After the paired development run, it blocks the public test unless semantic calibration achieves the declared risk bound with at least 5% coverage and 30 accepted development examples.

Only after the script prints:

```text
SEMANTIC CALIBRATION GATE PASSED
```

may the frozen public test be executed:

```bash
bash run_colab_test.sh
```

See `RUN_IN_COLAB.md` and `notebooks/NumGuard_Fin_Colab.ipynb` for exact cells.

## Primary outputs

```text
models/candidate_selector.json
models/candidate_selector_training_report.json
results/selector_training_rows.csv
results/dev_candidate_diagnostic/dataset_audit.csv
results/dev_candidate_diagnostic/candidate_quality_gate.json
results/dev_calibration/predictions.csv
results/dev_calibration/calibration.json
results/dev_calibration/calibration_curve.csv
results/dev_calibration/provenance_calibration.json
results/dev_calibration/provenance_calibration_curve.csv
results/final_test/predictions.csv
results/final_test/method_summary.csv
results/final_test/paired_comparisons.csv
results/final_test/research_tables.xlsx
results/final_test/failure_review_blinded.xlsx
results/final_test/failure_review_key.csv
results/final_test/counterfactual_candidate_mechanism.csv
results/final_test/counterfactual_model_output.csv
figures/final_test/
```

## Scientific boundaries

A valid proof certificate establishes that a complete answer belongs to the constructed question-conditioned lattice and is traceable to evidence. It does not prove that the chosen row, operation or interpretation is semantically correct. Provenance safety and answer correctness are therefore reported separately.

The method is a research artefact, not a universal financial safeguard, legal guarantee or regulatory compliance system. Final claims must remain conditional on the frozen development and public-test evidence.
