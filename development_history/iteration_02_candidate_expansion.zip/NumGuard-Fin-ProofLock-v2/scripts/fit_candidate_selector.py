from numguard_fin.cli import main

raise SystemExit(main([
    "fit-selector",
    "--data-dir", "data/raw",
    "--split", "train",
    "--retrieval-top-k", "16",
    "--max-direct-candidates", "16",
    "--max-derived-candidates", "48",
    "--folds", "5",
    "--seed", "42",
    "--output", "models/candidate_selector.json",
    "--rows-output", "results/selector_training_rows.csv",
]))
