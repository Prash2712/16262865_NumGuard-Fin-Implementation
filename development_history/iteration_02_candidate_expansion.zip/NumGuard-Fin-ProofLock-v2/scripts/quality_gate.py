from __future__ import annotations

import json
import re
from datetime import datetime, timezone
from pathlib import Path

import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
VERIFICATION = ROOT / "verification"
ENGINEERING = VERIFICATION / "engineering_checks"


def require(condition: bool, message: str, checks: list[dict]) -> None:
    checks.append({"check": message, "passed": bool(condition)})
    if not condition:
        raise RuntimeError(message)


def _test_count() -> int:
    text = (VERIFICATION / "test_run.txt").read_text(encoding="utf-8")
    matches = re.findall(r"(\d+) passed", text)
    if not matches:
        raise RuntimeError("Could not read the passing pytest count from verification/test_run.txt")
    return int(matches[-1])


def _certificate(value: object) -> dict:
    if isinstance(value, dict):
        return value
    if not isinstance(value, str) or not value.strip():
        return {}
    try:
        payload = json.loads(value)
    except json.JSONDecodeError:
        return {}
    return payload if isinstance(payload, dict) else {}


def main() -> int:
    checks: list[dict] = []
    test_count = _test_count()
    predictions = pd.read_csv(ENGINEERING / "predictions.csv")
    audit = pd.read_csv(VERIFICATION / "dataset_audit.csv")
    counterfactual = pd.read_csv(VERIFICATION / "counterfactual_audit.csv")

    require(test_count >= 121, "At least 121 unit and integration tests passed", checks)
    require(len(audit) == 12, "All 12 transparent engineering cases were audited", checks)
    require(
        int(audit["candidate_recall"].sum()) == 11,
        "The proof lattice recalled all 11 supported fixture answers",
        checks,
    )

    unsupported = predictions[
        (predictions["method"] == "derivation_proof_lock")
        & (predictions["example_id"].str.endswith("report_12.pdf-1"))
    ]
    require(
        len(unsupported) == 1 and bool(unsupported.iloc[0]["abstained"]),
        "The deliberately unsupported case produced an explicit abstention",
        checks,
    )

    hard_methods = {
        "direct_proof_lock",
        "derivation_proof_lock",
        "risk_controlled_proof_lock",
    }
    hard = predictions[predictions["method"].isin(hard_methods)]
    require(
        not hard["unsupported_complete_answer"].astype(bool).any(),
        "Hard proof locks produced zero constraint escapes",
        checks,
    )
    require(
        (
            ~hard["valid_numeric_response"].astype(bool)
            | hard["proof_valid"].astype(bool)
        ).all(),
        "Every hard-lock numeric response carried a valid proof",
        checks,
    )

    hard_committed = hard[hard["valid_numeric_response"].astype(bool)]
    certificates = hard_committed["proof_certificate"].map(_certificate)
    require(
        all(bool(certificate.get("evidence_claims")) for certificate in certificates),
        "Every committed hard-lock certificate contains structured evidence claims",
        checks,
    )
    require(
        all(certificate.get("candidate_confidence") is not None for certificate in certificates),
        "Every committed hard-lock certificate records candidate confidence",
        checks,
    )

    required_prediction_fields = {
        "input_token_count",
        "input_truncated",
        "verification_seconds",
        "total_method_seconds",
        "reference_operation",
        "predicted_operation",
        "proof_operation_match",
        "selected_candidate_margin",
        "provenance_risk_score",
        "semantic_risk_score",
    }
    require(
        required_prediction_fields.issubset(predictions.columns),
        "Prompt, timing and operation-diagnostic fields are present",
        checks,
    )
    require(
        predictions.groupby("method")["example_id"].nunique().nunique() == 1,
        "Every method was evaluated on the same examples",
        checks,
    )
    require(
        predictions["method"].nunique() == 12 and len(predictions) == 144,
        "Twelve methods produced 144 paired engineering records",
        checks,
    )
    require(
        predictions["configuration_id"].nunique() == 1,
        "The verification run used one frozen configuration",
        checks,
    )
    require(
        counterfactual["passed"].astype(bool).all(),
        "All applicable structured counterfactual checks passed",
        checks,
    )
    require(
        set(counterfactual["audit_layer"]) == {"candidate_mechanism"},
        "Local counterfactual output is explicitly labelled candidate-mechanism assurance",
        checks,
    )
    require(
        counterfactual["perturbation"].nunique() == 5,
        "All five provenance perturbation families were exercised",
        checks,
    )
    require(
        predictions["candidate_count"].max() <= 65,
        "The proof lattice remained within 16 direct + 48 derived + one abstention",
        checks,
    )
    require(
        predictions["direct_candidate_count"].max() <= 16
        and predictions["derived_candidate_count"].max() <= 48,
        "Direct and derived candidate counts respected their separate frozen bounds",
        checks,
    )
    require(
        "gold_answer" not in predictions.columns
        and "generated_answer" not in predictions.columns,
        "Submission-facing output uses clean field names",
        checks,
    )

    required_outputs = [
        ENGINEERING / "method_summary.csv",
        ENGINEERING / "paired_comparisons.csv",
        ENGINEERING / "research_tables.xlsx",
        ENGINEERING / "failure_review_blinded.xlsx",
        ENGINEERING / "failure_review_key.csv",
        ENGINEERING / "predictions.jsonl",
        VERIFICATION / "engineering_check_figures" / "proof_operation_agreement.png",
        VERIFICATION / "engineering_check_figures" / "method_latency.png",
    ]
    require(
        all(path.exists() and path.stat().st_size > 0 for path in required_outputs),
        "Engineering reports, blinded review files and assurance figures were generated",
        checks,
    )

    first_jsonl = json.loads(
        (ENGINEERING / "predictions.jsonl").read_text(encoding="utf-8").splitlines()[0]
    )
    require(
        isinstance(first_jsonl.get("proof_certificate"), dict),
        "JSONL stores proof certificates as nested objects",
        checks,
    )

    required_docs = [
        "README.md",
        "RUN_IN_COLAB.md",
        "DELIVERY_NOTES.md",
        "V2_CHANGELOG.md",
        "reports/research_design.md",
        "reports/dev_diagnostic_v1_findings.md",
        "reports/evaluation_protocol.md",
        "reports/numeric_and_derivation_rules.md",
        "reports/failure_taxonomy_codebook.md",
        "reports/literature_positioning.md",
        "reports/novelty_stress_test.md",
        "reports/claim_evidence_register.md",
        "reports/marker_readiness_checklist.md",
        "reports/supervisor_alignment.md",
        "reports/technical_assurance.md",
        "reproducibility/decision_log.md",
        "reproducibility/frozen_experiment_plan.json",
        "notebooks/NumGuard_Fin_Colab.ipynb",
        "scripts/preflight.py",
        "scripts/fit_candidate_selector.py",
        "run_colab_train_selector.sh",
        "src/numguard_fin/selector.py",
        "scripts/verify_source_manifest.py",
        "reproducibility/source_manifest.sha256",
    ]
    require(
        all((ROOT / path).exists() for path in required_docs),
        "Research, execution, claim-control and assurance documentation is complete",
        checks,
    )

    payload = {
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "status": "passed",
        "scope": "local engineering verification; not an empirical FinQA model result",
        "checks": checks,
        "summary": {
            "unit_and_integration_tests": test_count,
            "transparent_fixture_examples": 12,
            "supported_fixture_candidate_recall": "11/11",
            "deliberately_unsupported_cases": 1,
            "paired_method_rows": len(predictions),
            "methods": predictions["method"].nunique(),
            "counterfactual_cases": len(counterfactual),
            "counterfactual_passes": int(counterfactual["passed"].sum()),
            "hard_lock_constraint_escapes": int(
                hard["unsupported_complete_answer"].astype(bool).sum()
            ),
            "maximum_candidate_count_including_abstention": int(
                predictions["candidate_count"].max()
            ),
        },
    }
    (VERIFICATION / "quality_gate.json").write_text(
        json.dumps(payload, indent=2), encoding="utf-8"
    )

    lines = [
        "# Local verification report",
        "",
        "**Status: PASS**",
        "",
        "This report records engineering verification of the research artefact. It does not substitute for the official FinQA development and public-test experiments with FLAN-T5.",
        "",
        "## Executed checks",
        "",
        f"- {test_count} unit and integration tests passed.",
        "- All 11 supported transparent cases were present in the question-conditioned proof lattice.",
        "- The deliberately unsupported case produced `INSUFFICIENT_EVIDENCE`.",
        "- Twelve methods produced 144 paired records under one configuration ID.",
        "- Direct, derivation and risk-controlled hard locks produced zero unsupported complete-answer escapes.",
        "- Every committed hard-lock answer carried structured evidence claims and a confidence value.",
        "- All applicable candidate-mechanism counterfactual checks passed across five perturbation families.",
        "- The maximum lattice size remained within 16 direct + 48 derived + one abstention candidate.",
        "- Separate direct and derived candidate bounds were respected.",
        "- Prediction records include selector margin plus semantic- and provenance-risk fields.",
        "- JSONL proof certificates remained nested objects and the blinded manual-review package was generated.",
        "- Prompt diagnostics, operation diagnostics and corrected end-to-end timing fields were present.",
        "",
        "## Three-role review",
        "",
        "### Supervisor gate",
        "The design directly addresses evaluation trade-offs, operational definitions, model limitations, artefact–narrative integration, failure analysis and data provenance. The novelty claim is narrow and positioned against constrained decoding, selective prediction, table robustness and recent finance-aware work.",
        "",
        "### Scientist gate",
        "The parser, ledger, retrieval, bounded lattice, proof verifier, sequence trie, calibration, statistical summaries, checkpoints and counterfactual transformations are separately testable. Reference answers remain isolated from inference-time construction.",
        "",
        "### Marker gate",
        "The package contains a frozen split protocol, integrity validator, claim–evidence register, paired statistical treatment, blinded manual review, model-output perturbation audit and explicit limitations. Final claims remain conditional on official development and public-test evidence.",
        "",
        "## Commands executed",
        "",
        "```bash",
        "PYTHONPATH=src pytest -q",
        "PYTHONPATH=src python scripts/run_engineering_verification.py",
        "PYTHONPATH=src python scripts/quality_gate.py",
        "```",
    ]
    (VERIFICATION / "LOCAL_VERIFICATION_REPORT.md").write_text(
        "\n".join(lines) + "\n", encoding="utf-8"
    )
    print(json.dumps(payload["summary"], indent=2))
    print("QUALITY GATE PASSED")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
