from __future__ import annotations

import re
from decimal import Decimal
from typing import Iterable, Optional

from .numeric import normalise_scale
from .schemas import QuestionIntent


YEAR_RE = re.compile(r"\b(?:19|20)\d{2}\b")
TOKEN_RE = re.compile(r"[a-z0-9]+")
NUMBER_RE = re.compile(r"(?<![\w.])(?:\d+(?:\.\d+)?|\.\d+)(?![\w.])")

STOPWORDS = {
    "what", "was", "were", "is", "are", "the", "a", "an", "of", "in", "for",
    "to", "from", "during", "how", "much", "many", "did", "does", "do", "by",
    "and", "or", "between", "compared", "with", "according", "reported", "company",
    "year", "years", "amount", "approximately", "respectively", "given", "data",
    "considering", "observed", "ended", "ending", "period", "as", "at", "on",
}

GENERIC_FINANCE_TERMS = {
    "revenue", "sales", "income", "expense", "expenses", "cost", "costs", "profit",
    "loss", "assets", "liabilities", "debt", "cash", "equity", "shares", "tax",
    "interest", "margin", "capital", "inventory", "receivables", "payables", "dividend",
    "operating", "net", "gross", "diluted", "basic", "earnings", "compensation",
    "depreciation", "amortization", "goodwill", "investment", "investments", "lease",
    "payments", "commitments", "obligations", "stock", "price", "return", "volume",
    "mortgages", "balance", "value", "rate", "benefits", "facilities", "securities",
}

NUMBER_WORDS = {
    "one": 1, "two": 2, "three": 3, "four": 4, "five": 5,
    "six": 6, "seven": 7, "eight": 8, "nine": 9, "ten": 10,
    "twelve": 12, "twenty": 20, "twenty-four": 24, "thirty-six": 36,
}


def _matches(text: str, patterns: Iterable[str]) -> bool:
    return any(re.search(pattern, text, flags=re.IGNORECASE) for pattern in patterns)


def _year_range(question: str) -> Optional[tuple[str, str]]:
    match = re.search(
        r"\b(?:from|between|during|considering(?: the)? years?)\s+"
        r"((?:19|20)\d{2})\s*(?:-|to|and|through)\s*((?:19|20)\d{2})\b",
        question,
        flags=re.IGNORECASE,
    )
    if match:
        return match.group(1), match.group(2)
    match = re.search(r"\b((?:19|20)\d{2})\s*-\s*((?:19|20)\d{2})\b", question)
    return (match.group(1), match.group(2)) if match else None


def _ordered_periods(question: str, periods: tuple[str, ...]) -> tuple[str, ...]:
    year_range = _year_range(question)
    if year_range:
        return year_range
    return periods


def _period_count_hint(question: str, periods: tuple[str, ...]) -> Optional[int]:
    year_range = _year_range(question)
    if year_range:
        first, last = map(int, year_range)
        if 0 < abs(last - first) <= 20:
            return abs(last - first) + 1
    if len(periods) >= 2:
        return len(periods)
    q = question.lower().replace("-", " ")
    for word, number in NUMBER_WORDS.items():
        if re.search(rf"\b{re.escape(word.replace('-', ' '))}\s+(?:year|month|quarter|day)s?\b", q):
            return number
    numeric = re.search(r"\b(\d{1,3})\s+(?:year|month|quarter|day)s?\b", q)
    return int(numeric.group(1)) if numeric else None


def _target_scale(question: str) -> Optional[str]:
    match = re.search(r"\b(?:in|into)\s+(thousands?|millions?|billions?|trillions?)\b", question, re.I)
    if not match:
        return None
    return normalise_scale(match.group(1).lower().rstrip("s"))


def _meaningful_tokens(text: str, periods: tuple[str, ...]) -> list[str]:
    period_set = set(periods)
    output = []
    for token in TOKEN_RE.findall(text.lower()):
        if token in STOPWORDS or token in period_set or token.isdigit():
            continue
        output.append(token)
    return output


def _metric_terms(question: str, periods: tuple[str, ...]) -> tuple[str, ...]:
    meaningful = _meaningful_tokens(question, periods)
    # Preserve modifiers around finance nouns. Purely generic question words have already
    # been removed. Unlike v1, "total" is deliberately retained because it often
    # distinguishes denominator rows from component rows.
    finance_positions = [i for i, token in enumerate(meaningful) if token in GENERIC_FINANCE_TERMS]
    selected: list[str] = []
    if finance_positions:
        for position in finance_positions:
            selected.extend(meaningful[max(0, position - 2): position + 2])
    else:
        selected = meaningful
    seen: set[str] = set()
    ordered: list[str] = []
    for term in selected:
        if term not in seen:
            seen.add(term)
            ordered.append(term)
    return tuple(ordered[:14])


def _phrase_terms(text: str, periods: tuple[str, ...]) -> tuple[str, ...]:
    return tuple(dict.fromkeys(_meaningful_tokens(text, periods)))[:10]


def _role_terms(question: str, periods: tuple[str, ...]) -> tuple[tuple[str, ...], tuple[str, ...]]:
    q = " ".join(question.lower().split())
    patterns = [
        r"(?:what|which)\s+(?:percentage|percent|portion)\s+of\s+(.+?)\s+(?:is|was|were|are)\s+(.+)",
        r"(.+?)\s+as\s+a\s+percentage\s+of\s+(.+)",
        r"ratio\s+of\s+(.+?)\s+to\s+(.+)",
        r"(.+?)\s+relative\s+to\s+(.+)",
        r"(.+?)\s+divided\s+by\s+(.+)",
    ]
    for pattern in patterns:
        match = re.search(pattern, q)
        if match:
            return _phrase_terms(match.group(1), periods), _phrase_terms(match.group(2), periods)
    # "what percent of total X was Y" places the denominator before numerator.
    match = re.search(r"what\s+percent(?:age)?\s+of\s+(.+?)\s+(?:was|were|is|are)\s+(.+)", q)
    if match:
        return _phrase_terms(match.group(2), periods), _phrase_terms(match.group(1), periods)
    return (), ()


def _explicit_constants(question: str, periods: tuple[str, ...]) -> tuple[Decimal, ...]:
    years = set(periods)
    values: list[Decimal] = []
    for raw in NUMBER_RE.findall(question):
        if raw in years:
            continue
        try:
            value = Decimal(raw)
        except Exception:
            continue
        # Numbers attached to common units can legitimately be program constants.
        if re.search(rf"\b{re.escape(raw)}\s*(?:day|month|quarter|year|share|vote)s?\b", question, re.I):
            values.append(value)
    q = question.lower().replace("-", " ")
    for word, number in NUMBER_WORDS.items():
        normalised = word.replace("-", " ")
        if re.search(rf"\b{re.escape(normalised)}\s+(?:day|month|quarter|year)s?\b", q):
            values.append(Decimal(number))
    return tuple(dict.fromkeys(values))


def parse_question_intent(question: str) -> QuestionIntent:
    q = " ".join(question.strip().split())
    q_lower = q.lower()
    periods = tuple(dict.fromkeys(YEAR_RE.findall(q)))
    range_bounds = _year_range(q)
    if range_bounds:
        first, last = map(int, range_bounds)
        step = 1 if last >= first else -1
        periods = tuple(str(year) for year in range(first, last + step, step))

    aggregation: Optional[str] = None
    if _matches(q_lower, (r"\b(?:highest|greatest|maximum|max)\b",)):
        operation, aggregation = "table_max", "max"
    elif _matches(q_lower, (r"\b(?:lowest|least|minimum|min)\b",)):
        operation, aggregation = "table_min", "min"
    elif _matches(q_lower, (
        r"^(?:what|which) (?:was|is|were|are)? ?the average\b",
        r"\baverage (?:amount|value|price|percentage|number|cost|revenue|expense|margin)\b",
        r"\bmean of\b", r"\bannual average\b",
    )):
        operation, aggregation = "average", "average"
    elif _matches(q_lower, (
        r"percentage\s+(?:change|increase|decrease|growth|reduction)",
        r"percent\s+(?:change|increase|decrease|higher|lower|growth|reduction)",
        r"growth\s+rate", r"rate\s+of\s+return", r"\broi\b",
        r"percentual\s+(?:increase|decrease|reduction)",
        r"cumulative\s+(?:total\s+)?return", r"change.*percent",
    )):
        operation = "percentage_change"
    elif _matches(q_lower, (
        r"\bdifference\b", r"how much (?:more|less|higher|lower|bigger)",
        r"\bchange in\b", r"\bincrease in\b", r"\bdecrease in\b",
        r"\bnet change\b", r"(?:more|less) than", r"percentage point",
    )):
        operation = "difference"
    elif _matches(q_lower, (
        r"\bsum\b", r"\bcombined\b", r"\btogether\b", r"\btotal of\b",
        r"what were the total", r"what was the total (?:amount|value|in)",
        r"for .* and .* what (?:was|were) the total",
    )):
        operation, aggregation = "sum", "sum"
    elif _matches(q_lower, (
        r"\bmargin\b", r"as a percentage of", r"what percent(?:age)? of",
        r"what portion of", r"represented by", r"represented .* percentage",
    )):
        operation = "margin"
    elif _matches(q_lower, (
        r"\bratio\b", r"divided by", r"relative to", r"times as",
        r"(?:cost|amount|volume|revenue|price) per (?:transaction|car|tower|gwh)",
    )):
        operation = "ratio"
    elif _matches(q_lower, (r"\bproduct\b", r"multiplied by", r"market capitalization", r"total votes")):
        operation = "product"
    else:
        operation = "direct_lookup"

    answer_type = "plain"
    if _matches(q_lower, (r"percent", r"percentage", r"\bmargin\b", r"growth rate", r"tax rate", r"\broi\b", r"rate of return")):
        answer_type = "percentage"
    elif _matches(q_lower, (r"what year", r"which year", r"in which year")):
        answer_type = "year"
    elif _matches(q_lower, (r"\bratio\b", r"times as")):
        answer_type = "ratio"
    elif _matches(q_lower, (r"how many", r"number of", r"count of")):
        answer_type = "count"

    if operation in {"percentage_change", "margin"}:
        answer_type = "percentage"

    metric_terms = _metric_terms(q, periods)
    numerator_terms, denominator_terms = _role_terms(q, periods)
    entity_terms = tuple(
        term for term in _meaningful_tokens(q, periods)
        if term not in GENERIC_FINANCE_TERMS and term not in {"total", "average", "highest", "lowest"}
    )[:12]
    signal_count = sum((bool(metric_terms), bool(periods), operation != "direct_lookup", bool(numerator_terms or denominator_terms)))
    confidence = min(1.0, 0.40 + 0.15 * signal_count)

    return QuestionIntent(
        operation=operation,
        expected_answer_type=answer_type,
        metric_terms=metric_terms,
        periods=periods,
        ordered_periods=_ordered_periods(q, periods),
        asks_for_change=operation in {"difference", "percentage_change"},
        asks_for_absolute_change=bool(re.search(r"absolute|amount of (?:the )?change", q_lower)),
        confidence=confidence,
        aggregation=aggregation,
        target_scale=_target_scale(q),
        period_count_hint=_period_count_hint(q, periods),
        explicit_constants=_explicit_constants(q, periods),
        numerator_terms=numerator_terms,
        denominator_terms=denominator_terms,
        entity_terms=entity_terms,
    )
