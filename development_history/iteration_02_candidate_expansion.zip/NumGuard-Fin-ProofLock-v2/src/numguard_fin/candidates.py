from __future__ import annotations

import hashlib
import itertools
import math
from dataclasses import dataclass, replace
from decimal import Decimal, DivisionByZero, InvalidOperation
from typing import Callable, Iterable, Optional

from .numeric import SCALE_MULTIPLIERS, format_answer, numeric_equal, parse_single_number
from .retrieval import tokens
from .schemas import (
    AnswerCandidate,
    CandidateProof,
    EvidenceItem,
    QuestionIntent,
    RetrievedEvidence,
)


ABSTAIN_RESPONSE = "INSUFFICIENT_EVIDENCE"
DERIVATION_OPERATIONS = {
    "difference", "percentage_change", "sum", "average", "ratio", "margin",
    "product", "table_sum", "table_average", "table_min", "table_max",
}

CandidateScorer = Callable[[AnswerCandidate], float]


@dataclass(frozen=True)
class CandidateLattice:
    candidates: tuple[AnswerCandidate, ...]
    direct_count: int
    derived_count: int
    retrieval_count: int

    @property
    def answer_strings(self) -> tuple[str, ...]:
        return tuple(candidate.answer for candidate in self.candidates)

    def numeric_candidates(self) -> tuple[AnswerCandidate, ...]:
        return tuple(candidate for candidate in self.candidates if candidate.proof.proof_type != "abstain")

    def find_by_answer(self, response: str) -> Optional[AnswerCandidate]:
        cleaned = response.strip()
        exact = [candidate for candidate in self.candidates if candidate.answer == cleaned]
        if exact:
            return max(exact, key=lambda candidate: candidate.confidence)
        parsed_response = parse_single_number(cleaned)
        if parsed_response is None:
            return None
        matches: list[AnswerCandidate] = []
        for candidate in self.numeric_candidates():
            parsed_candidate = parse_single_number(candidate.answer)
            if parsed_candidate is not None and numeric_equal(
                parsed_response, parsed_candidate, require_percent_compatibility=True
            ):
                matches.append(candidate)
        return max(matches, key=lambda candidate: candidate.confidence) if matches else None

    def contains_reference(self, reference_answer: Optional[str]) -> Optional[bool]:
        if reference_answer is None:
            return None
        parsed_reference = parse_single_number(reference_answer)
        if parsed_reference is None:
            return False
        return any(
            (parsed := parse_single_number(candidate.answer)) is not None
            and numeric_equal(parsed_reference, parsed, require_percent_compatibility=True)
            for candidate in self.numeric_candidates()
        )

    def confidence_margin(self, response: str) -> Optional[float]:
        selected = self.find_by_answer(response)
        if selected is None:
            return None
        scores = sorted(
            (candidate.confidence for candidate in self.numeric_candidates()), reverse=True
        )
        if not scores:
            return None
        alternatives = [candidate.confidence for candidate in self.numeric_candidates() if candidate.candidate_id != selected.candidate_id]
        return selected.confidence - max(alternatives) if alternatives else selected.confidence


def _stable_id(prefix: str, payload: str) -> str:
    return f"{prefix}_{hashlib.sha1(payload.encode('utf-8')).hexdigest()[:12]}"


def _sigmoid(value: float) -> float:
    return 1.0 / (1.0 + math.exp(-max(-20.0, min(20.0, value))))


def _clamp(value: float) -> float:
    return max(0.0, min(1.0, value))


def _candidate_answer(value: Decimal, answer_type: str) -> str:
    return format_answer(value, answer_type, places=4)


def _normalised_metric(item: EvidenceItem) -> str:
    return " ".join((item.row_label or item.metric_text or "").strip().lower().split())


def _same_metric(left: EvidenceItem, right: EvidenceItem) -> bool:
    a, b = _normalised_metric(left), _normalised_metric(right)
    if not a or not b:
        return False
    if a == b or a in b or b in a:
        return True
    ta, tb = set(tokens(a)), set(tokens(b))
    return bool(ta and tb and len(ta & tb) / max(1, min(len(ta), len(tb))) >= 0.67)


def _term_overlap(terms: Iterable[str], item: EvidenceItem) -> float:
    terms = set(tokens(" ".join(terms)))
    if not terms:
        return 0.0
    item_terms = set(tokens(f"{item.row_label or ''} {item.metric_text} {item.text}"))
    return len(terms & item_terms) / len(terms)


def _scale_multiplier(scale: Optional[str]) -> Decimal:
    return SCALE_MULTIPLIERS.get(scale or "", Decimal("1"))


def _value_in_scale(item: EvidenceItem, scale: Optional[str]) -> Decimal:
    if scale:
        return item.base_value / _scale_multiplier(scale)
    return item.value


def _common_output_scale(intent: QuestionIntent, operands: Iterable[EvidenceItem]) -> Optional[str]:
    if intent.target_scale:
        return intent.target_scale
    scales = {item.scale for item in operands if item.scale}
    return next(iter(scales)) if len(scales) == 1 else None


def _safe_divide(numerator: Decimal, denominator: Decimal) -> Optional[Decimal]:
    try:
        return None if denominator == 0 else numerator / denominator
    except (DivisionByZero, InvalidOperation, ZeroDivisionError):
        return None


def _compatible_units(items: Iterable[EvidenceItem], operation: str) -> bool:
    items = list(items)
    currencies = {item.currency for item in items if item.currency}
    if len(currencies) > 1:
        return False
    if operation in {"addition", "subtraction", "average", "table_sum", "table_average", "table_min", "table_max"}:
        # Different scales are convertible because every EvidenceItem stores base_value.
        return all(not item.is_percent for item in items) or all(item.is_percent for item in items)
    return True


def _answer_type_for(operation: str, intent: QuestionIntent, operands: Iterable[EvidenceItem]) -> str:
    operands = list(operands)
    if operation in {"percentage_change", "margin", "percentage_of_total"}:
        return "percentage"
    if intent.expected_answer_type == "percentage":
        return "percentage"
    if operation in {"table_min", "table_max", "table_average", "average", "addition", "subtraction"} and operands and all(item.is_percent for item in operands):
        return "percentage"
    return intent.expected_answer_type if intent.expected_answer_type in {"plain", "ratio", "count", "year"} else "plain"


def _feature_values(
    *,
    operation: str,
    operands: list[RetrievedEvidence],
    intent: QuestionIntent,
    compatible: bool,
    depth: int,
    role_fit: float,
    period_fit: float,
) -> dict[str, float]:
    retrieval = sum(_sigmoid(entry.score) for entry in operands) / max(1, len(operands))
    metric = sum(max(0.0, entry.metric_score) for entry in operands) / max(1, len(operands))
    type_fit = sum(max(0.0, entry.type_score) for entry in operands) / max(1, len(operands))
    operation_match = float(
        operation in {
            intent.operation,
            {"difference": "subtraction", "sum": "addition", "ratio": "division", "product": "multiplication"}.get(intent.operation, ""),
        }
        or (intent.operation == "average" and operation in {"average", "table_average"})
        or (intent.operation == "margin" and operation in {"margin", "percentage_of_total"})
    )
    return {
        "retrieval": retrieval,
        "metric_fit": metric,
        "type_fit": type_fit,
        "period_fit": _clamp(period_fit),
        "role_fit": _clamp(role_fit),
        "proof_valid": float(compatible),
        "operation_match": operation_match,
        "proof_depth": float(depth),
        "operand_count": float(len(operands)),
        "direct": 0.0,
        "percentage_answer": float(intent.expected_answer_type == "percentage"),
    }


def _base_confidence(features: dict[str, float]) -> float:
    score = (
        0.18 * features["retrieval"]
        + 0.24 * features["metric_fit"]
        + 0.08 * features["type_fit"]
        + 0.17 * features["period_fit"]
        + 0.18 * features["role_fit"]
        + 0.10 * features["proof_valid"]
        + 0.14 * features["operation_match"]
        - 0.015 * max(0.0, features["proof_depth"] - 1.0)
        - 0.005 * max(0.0, features["operand_count"] - 2.0)
    )
    return _clamp(score)


def _direct_candidate(entry: RetrievedEvidence, intent: QuestionIntent) -> AnswerCandidate:
    item = entry.item
    value = _value_in_scale(item, intent.target_scale) if intent.target_scale and item.scale else item.value
    answer_type = "percentage" if item.is_percent else (
        "year" if item.is_year and intent.expected_answer_type == "year" else intent.expected_answer_type
    )
    if answer_type not in {"percentage", "year", "count", "ratio", "plain"}:
        answer_type = "plain"
    metric_fit = entry.metric_score if intent.metric_terms else max(0.0, entry.lexical_score)
    period_fit = max(0.0, entry.period_score) if intent.periods else 1.0
    type_fit = 1.0 if not item.is_year or answer_type == "year" else 0.0
    semantic = _clamp(0.50 * metric_fit + 0.30 * period_fit + 0.20 * type_fit)
    features = {
        "retrieval": _sigmoid(entry.score), "metric_fit": metric_fit, "type_fit": type_fit,
        "period_fit": period_fit, "role_fit": max(_term_overlap(intent.numerator_terms, item), _term_overlap(intent.denominator_terms, item)),
        "proof_valid": 1.0, "operation_match": float(intent.operation == "direct_lookup"),
        "proof_depth": 0.0, "operand_count": 1.0, "direct": 1.0,
        "percentage_answer": float(answer_type == "percentage"),
    }
    confidence = _clamp(0.18 * features["retrieval"] + 0.47 * semantic + 0.20 * features["operation_match"] + 0.15)
    if intent.metric_terms and entry.metric_score == 0.0:
        confidence *= 0.30
    if intent.operation in DERIVATION_OPERATIONS:
        confidence *= 0.48
    answer = _candidate_answer(value, answer_type)
    proof = CandidateProof("direct", "lookup", (item.evidence_id,), item.evidence_id, True, True)
    return AnswerCandidate(
        candidate_id=_stable_id("direct", f"{item.evidence_id}|{answer}"), answer=answer,
        value=value, answer_type=answer_type, proof=proof, evidence_ids=(item.evidence_id,),
        retrieval_score=entry.score, semantic_score=semantic, proof_score=1.0,
        confidence=confidence, explanation=f"Direct value from {item.evidence_id}: {item.text}",
        feature_values=features,
    )


def _role_fit(operation: str, operands: list[RetrievedEvidence], intent: QuestionIntent) -> float:
    if not operands:
        return 0.0
    if operation in {"subtraction", "percentage_change"}:
        return 1.0 if len(operands) >= 2 and _same_metric(operands[0].item, operands[1].item) else 0.45
    if operation in {"addition", "average", "table_sum", "table_average", "table_min", "table_max"}:
        same_row = len({_normalised_metric(entry.item) for entry in operands}) == 1
        entity_hits = sum(_term_overlap(intent.entity_terms, entry.item) > 0 for entry in operands)
        return max(float(same_row), min(1.0, entity_hits / max(1, len(operands))))
    if operation in {"division", "margin", "percentage_of_total"} and len(operands) >= 2:
        num = _term_overlap(intent.numerator_terms, operands[0].item)
        den = _term_overlap(intent.denominator_terms, operands[1].item)
        if intent.numerator_terms or intent.denominator_terms:
            return (num + den) / 2.0
        if operation == "margin":
            left = _normalised_metric(operands[0].item)
            right = _normalised_metric(operands[1].item)
            n = any(token in left for token in ("income", "profit", "earnings", "component", "segment"))
            d = any(token in right for token in ("revenue", "sales", "total", "obligation", "commitment"))
            return 1.0 if n and d else 0.45
        return 0.75
    if operation == "multiplication":
        return 1.0 if any(entry.item.is_percent for entry in operands) else 0.70
    return 0.65


def _period_fit(operands: list[RetrievedEvidence], intent: QuestionIntent) -> float:
    if not intent.periods:
        return 1.0
    represented = {entry.item.period for entry in operands if entry.item.period}
    return len(set(intent.periods) & represented) / max(1, len(intent.periods))


def _derived_candidate(
    operation: str,
    operands: list[RetrievedEvidence],
    result: Decimal,
    intent: QuestionIntent,
    expression: str,
    *,
    depth: int = 1,
    answer_type: Optional[str] = None,
) -> Optional[AnswerCandidate]:
    if not result.is_finite() or abs(result) > Decimal("1e18"):
        return None
    compatible = _compatible_units((entry.item for entry in operands), operation)
    if not compatible:
        return None
    role_fit = _role_fit(operation, operands, intent)
    period_fit = _period_fit(operands, intent)
    features = _feature_values(
        operation=operation, operands=operands, intent=intent, compatible=compatible,
        depth=depth, role_fit=role_fit, period_fit=period_fit,
    )
    semantic = _clamp(
        0.28 * features["metric_fit"] + 0.22 * period_fit + 0.30 * role_fit
        + 0.20 * features["operation_match"]
    )
    confidence = _base_confidence(features)
    if role_fit == 0.0:
        confidence *= 0.25
    answer_type = answer_type or _answer_type_for(operation, intent, (entry.item for entry in operands))
    answer = _candidate_answer(result, answer_type)
    ids = tuple(entry.item.evidence_id for entry in operands)
    proof = CandidateProof("derived", operation, ids, expression, compatible, True)
    return AnswerCandidate(
        candidate_id=_stable_id("derived", f"{operation}|{'|'.join(ids)}|{answer}|{expression}"),
        answer=answer, value=result, answer_type=answer_type, proof=proof, evidence_ids=ids,
        retrieval_score=sum(entry.score for entry in operands) / max(1, len(operands)),
        semantic_score=semantic, proof_score=1.0, confidence=confidence,
        explanation=f"{operation}: {expression}", feature_values=features,
    )


def _row_groups(retrieved: list[RetrievedEvidence]) -> list[list[RetrievedEvidence]]:
    groups: dict[tuple[int | None, str], list[RetrievedEvidence]] = {}
    for entry in retrieved:
        if entry.item.source_type != "table" or entry.item.is_year:
            continue
        key = (entry.item.row_index, _normalised_metric(entry.item))
        groups.setdefault(key, []).append(entry)
    return [sorted(group, key=lambda e: (e.item.column_index or 0, e.item.evidence_id)) for group in groups.values()]


def _requested_row_values(group: list[RetrievedEvidence], intent: QuestionIntent) -> list[RetrievedEvidence]:
    requested = [entry for entry in group if entry.item.period in intent.periods]
    values = requested or group
    if intent.period_count_hint and len(values) > intent.period_count_hint:
        values = sorted(values, key=lambda e: (-e.score, e.item.evidence_id))[: intent.period_count_hint]
    return values


def _aggregate_candidates(retrieved: list[RetrievedEvidence], intent: QuestionIntent) -> list[AnswerCandidate]:
    output: list[AnswerCandidate] = []
    operation = intent.operation
    if operation not in {"sum", "average", "table_sum", "table_average", "table_min", "table_max"}:
        return output
    for group in _row_groups(retrieved):
        values = _requested_row_values(group, intent)
        if len(values) < (1 if operation in {"table_min", "table_max"} else 2):
            continue
        scale = _common_output_scale(intent, (entry.item for entry in values))
        numbers = [_value_in_scale(entry.item, scale) for entry in values]
        op = operation
        if operation in {"sum", "table_sum"}:
            result, op = sum(numbers, Decimal("0")), "table_sum" if len(values) > 2 else "addition"
            expression = " + ".join(entry.item.evidence_id for entry in values)
        elif operation in {"average", "table_average"}:
            result, op = sum(numbers, Decimal("0")) / Decimal(len(numbers)), "table_average" if len(values) > 2 else "average"
            expression = f"({' + '.join(entry.item.evidence_id for entry in values)}) / {len(values)}"
        elif operation == "table_min":
            result, op = min(numbers), "table_min"
            expression = f"min({','.join(entry.item.evidence_id for entry in values)})"
        else:
            result, op = max(numbers), "table_max"
            expression = f"max({','.join(entry.item.evidence_id for entry in values)})"
        candidate = _derived_candidate(op, values, result, intent, expression, depth=max(1, len(values) - 1))
        if candidate:
            output.append(candidate)
    return output


def _ordered_period_pairs(retrieved: list[RetrievedEvidence], intent: QuestionIntent) -> list[tuple[RetrievedEvidence, RetrievedEvidence]]:
    if len(intent.ordered_periods) < 2:
        return []
    earlier, later = intent.ordered_periods[:2]
    old_items = [e for e in retrieved if e.item.period == earlier and not e.item.is_year]
    new_items = [e for e in retrieved if e.item.period == later and not e.item.is_year]
    same = [(old, new) for old in old_items for new in new_items if _same_metric(old.item, new.item)]
    return same or [(old, new) for old in old_items for new in new_items]


def _top_numeric(retrieved: list[RetrievedEvidence], limit: int = 12) -> list[RetrievedEvidence]:
    return [entry for entry in retrieved if not entry.item.is_year][:limit]


def _pair_candidates(retrieved: list[RetrievedEvidence], intent: QuestionIntent) -> list[AnswerCandidate]:
    output: list[AnswerCandidate] = []
    operation = intent.operation
    if operation not in {"difference", "percentage_change", "ratio", "margin", "sum", "average", "product"}:
        return output

    period_pairs = _ordered_period_pairs(retrieved, intent)
    top = _top_numeric(retrieved)
    if operation in {"difference", "percentage_change"} and period_pairs:
        pairs = period_pairs
    else:
        pairs = [(a, b) for a in top for b in top if a.item.evidence_id != b.item.evidence_id]

    for first, second in pairs:
        if len(output) >= 180:  # pre-pruning safety bound
            break
        a_item, b_item = first.item, second.item
        if operation == "difference":
            scale = _common_output_scale(intent, (a_item, b_item))
            a, b = _value_in_scale(a_item, scale), _value_in_scale(b_item, scale)
            # Period pairs are old,new; natural answer is new-old.
            if period_pairs:
                result, operands = b - a, [second, first]
                expression = f"{b_item.evidence_id} - {a_item.evidence_id}"
            else:
                result, operands = a - b, [first, second]
                expression = f"{a_item.evidence_id} - {b_item.evidence_id}"
            if intent.asks_for_absolute_change:
                result, expression = abs(result), f"abs({expression})"
            candidate = _derived_candidate("subtraction", operands, result, intent, expression)
        elif operation == "percentage_change":
            old, new = (first, second) if period_pairs else (second, first)
            ratio = _safe_divide(new.item.base_value - old.item.base_value, old.item.base_value)
            candidate = None if ratio is None else _derived_candidate(
                "percentage_change", [new, old], ratio * Decimal("100"), intent,
                f"(({new.item.evidence_id} - {old.item.evidence_id}) / {old.item.evidence_id}) * 100",
                depth=3, answer_type="percentage",
            )
        elif operation in {"ratio", "margin"}:
            ratio = _safe_divide(a_item.base_value, b_item.base_value)
            if ratio is None:
                candidate = None
            else:
                percent = intent.expected_answer_type == "percentage" or operation == "margin"
                result = ratio * Decimal("100") if percent else ratio
                op = "margin" if operation == "margin" else "division"
                expression = f"({a_item.evidence_id} / {b_item.evidence_id})" + (" * 100" if percent else "")
                candidate = _derived_candidate(op, [first, second], result, intent, expression, depth=2 if percent else 1, answer_type="percentage" if percent else None)
        elif operation == "sum":
            scale = _common_output_scale(intent, (a_item, b_item))
            candidate = _derived_candidate(
                "addition", [first, second], _value_in_scale(a_item, scale) + _value_in_scale(b_item, scale),
                intent, f"{a_item.evidence_id} + {b_item.evidence_id}",
            )
        elif operation == "average":
            scale = _common_output_scale(intent, (a_item, b_item))
            candidate = _derived_candidate(
                "average", [first, second], (_value_in_scale(a_item, scale) + _value_in_scale(b_item, scale)) / Decimal("2"),
                intent, f"({a_item.evidence_id} + {b_item.evidence_id}) / 2", depth=2,
            )
        else:  # product
            if a_item.is_percent and not b_item.is_percent:
                result = (a_item.value / Decimal("100")) * _value_in_scale(b_item, intent.target_scale or b_item.scale)
            elif b_item.is_percent and not a_item.is_percent:
                result = (b_item.value / Decimal("100")) * _value_in_scale(a_item, intent.target_scale or a_item.scale)
            else:
                result = a_item.value * b_item.value
            candidate = _derived_candidate("multiplication", [first, second], result, intent, f"{a_item.evidence_id} * {b_item.evidence_id}")
        if candidate:
            output.append(candidate)
    return output


def _constant_candidates(retrieved: list[RetrievedEvidence], intent: QuestionIntent) -> list[AnswerCandidate]:
    output: list[AnswerCandidate] = []
    if not intent.explicit_constants:
        return output
    top = _top_numeric(retrieved, limit=8)
    for entry in top:
        for constant in intent.explicit_constants:
            if constant == 0:
                continue
            pseudo_expression = f"const_{constant}"
            if intent.operation == "average":
                result = entry.item.value / constant
                op, expression = "average", f"{entry.item.evidence_id} / {pseudo_expression}"
            elif intent.operation == "ratio":
                result = entry.item.value / constant
                op, expression = "division", f"{entry.item.evidence_id} / {pseudo_expression}"
            elif intent.operation == "product":
                result = entry.item.value * constant
                op, expression = "multiplication", f"{entry.item.evidence_id} * {pseudo_expression}"
            elif intent.operation == "sum" and constant in {Decimal("12"), Decimal("24"), Decimal("36")}:
                # Month counts license aggregation over annual values; the row aggregation
                # path remains preferred. Do not multiply a monetary amount by months.
                continue
            else:
                continue
            candidate = _derived_candidate(op, [entry], result, intent, expression, depth=1)
            if candidate:
                output.append(candidate)
    return output


def _nary_cross_row_candidates(retrieved: list[RetrievedEvidence], intent: QuestionIntent) -> list[AnswerCandidate]:
    if intent.operation not in {"sum", "average"}:
        return []
    top = _top_numeric(retrieved, 10)
    if intent.periods:
        matching = [entry for entry in top if entry.item.period in intent.periods]
        if matching:
            top = matching
    output: list[AnswerCandidate] = []
    max_size = min(5, intent.period_count_hint or 4, len(top))
    for size in range(3, max_size + 1):
        for operands in itertools.combinations(top, size):
            row_names = {_normalised_metric(entry.item) for entry in operands}
            entity_hits = sum(_term_overlap(intent.entity_terms, entry.item) > 0 for entry in operands)
            if len(row_names) > 1 and intent.entity_terms and entity_hits < min(2, size):
                continue
            scale = _common_output_scale(intent, (entry.item for entry in operands))
            values = [_value_in_scale(entry.item, scale) for entry in operands]
            if intent.operation == "sum":
                result, op = sum(values, Decimal("0")), "addition"
                expression = " + ".join(entry.item.evidence_id for entry in operands)
            else:
                result, op = sum(values, Decimal("0")) / Decimal(size), "average"
                expression = f"({' + '.join(entry.item.evidence_id for entry in operands)}) / {size}"
            candidate = _derived_candidate(op, list(operands), result, intent, expression, depth=size)
            if candidate:
                output.append(candidate)
            if len(output) >= 80:
                return output
    return output


def _deduplicate(candidates: Iterable[AnswerCandidate]) -> list[AnswerCandidate]:
    # Keep the strongest proof for each complete answer. Proof type is intentionally not
    # part of the key: the verifier should return the best certificate for that answer.
    best: dict[str, AnswerCandidate] = {}
    for candidate in candidates:
        previous = best.get(candidate.answer)
        candidate_rank = (
            candidate.feature_values.get("operation_match", 0.0),
            candidate.proof_score,
            candidate.confidence,
            candidate.semantic_score,
            len(candidate.evidence_ids),
        )
        previous_rank = None if previous is None else (
            previous.feature_values.get("operation_match", 0.0),
            previous.proof_score,
            previous.confidence,
            previous.semantic_score,
            len(previous.evidence_ids),
        )
        if previous is None or candidate_rank > previous_rank:
            best[candidate.answer] = candidate
    return sorted(best.values(), key=lambda candidate: (-candidate.confidence, candidate.candidate_id))


def build_candidate_lattice(
    retrieved: Iterable[RetrievedEvidence],
    intent: QuestionIntent,
    *,
    include_derived: bool = True,
    max_direct: int = 16,
    max_derived: int = 48,
    minimum_direct_confidence: float = 0.08,
    minimum_derived_confidence: float = 0.18,
    candidate_scorer: Optional[CandidateScorer] = None,
) -> CandidateLattice:
    retrieved_list = list(retrieved)
    direct = [_direct_candidate(entry, intent) for entry in retrieved_list if not entry.item.is_year or intent.expected_answer_type == "year"]
    direct = [candidate for candidate in direct if candidate.confidence >= minimum_direct_confidence]
    direct = _deduplicate(direct)[:max_direct]

    derived: list[AnswerCandidate] = []
    if include_derived:
        derived.extend(_aggregate_candidates(retrieved_list, intent))
        derived.extend(_pair_candidates(retrieved_list, intent))
        derived.extend(_nary_cross_row_candidates(retrieved_list, intent))
        derived.extend(_constant_candidates(retrieved_list, intent))
        derived = [candidate for candidate in derived if candidate.confidence >= minimum_derived_confidence]
        derived = _deduplicate(derived)[:max_derived]

    numeric = _deduplicate([*direct, *derived])
    if candidate_scorer is not None:
        numeric = [replace(candidate, confidence=_clamp(float(candidate_scorer(candidate)))) for candidate in numeric]
        numeric.sort(key=lambda candidate: (-candidate.confidence, candidate.candidate_id))
        # Re-apply type-specific bounds after learned rescoring.
        direct = [candidate for candidate in numeric if candidate.proof.proof_type == "direct"][:max_direct]
        derived = [candidate for candidate in numeric if candidate.proof.proof_type == "derived"][:max_derived]
        numeric = _deduplicate([*direct, *derived])

    abstain = AnswerCandidate(
        candidate_id="abstain", answer=ABSTAIN_RESPONSE, value=None, answer_type="abstain",
        proof=CandidateProof("abstain", "abstain", (), "", True, True), evidence_ids=(),
        retrieval_score=0.0, semantic_score=1.0, proof_score=1.0, confidence=0.0,
        explanation="Explicit abstention when no certified answer is sufficiently supported.",
        feature_values={"direct": 0.0},
    )
    return CandidateLattice(
        candidates=tuple([*numeric, abstain]),
        direct_count=sum(candidate.proof.proof_type == "direct" for candidate in numeric),
        derived_count=sum(candidate.proof.proof_type == "derived" for candidate in numeric),
        retrieval_count=len(retrieved_list),
    )
