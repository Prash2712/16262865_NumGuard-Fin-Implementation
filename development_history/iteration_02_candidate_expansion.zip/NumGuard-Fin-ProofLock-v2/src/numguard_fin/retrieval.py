from __future__ import annotations

import math
import re
from collections import Counter, defaultdict
from typing import Iterable

from .schemas import EvidenceItem, QuestionIntent, RetrievedEvidence


TOKEN_RE = re.compile(r"[a-z0-9]+")
STOPWORDS = {
    "the", "a", "an", "of", "in", "to", "for", "and", "or", "was", "were",
    "is", "are", "what", "how", "much", "many", "during", "from", "by", "with",
    "according", "company", "year", "years", "reported", "considering", "given",
}


def _normalise_token(token: str) -> str:
    token = token.lower()
    if len(token) > 5 and token.endswith("ing"):
        token = token[:-3]
    if len(token) > 4 and token.endswith("ies"):
        return token[:-3] + "y"
    if len(token) > 4 and token.endswith("es"):
        return token[:-2]
    if len(token) > 3 and token.endswith("s"):
        return token[:-1]
    return token


def tokens(text: str) -> list[str]:
    return [
        _normalise_token(token)
        for token in TOKEN_RE.findall((text or "").lower())
        if token not in STOPWORDS
    ]


def _weighted_overlap(query_tokens: list[str], evidence_tokens: list[str]) -> float:
    if not query_tokens or not evidence_tokens:
        return 0.0
    query_counts = Counter(query_tokens)
    evidence_counts = Counter(evidence_tokens)
    overlap = sum(min(query_counts[token], evidence_counts[token]) for token in query_counts)
    return overlap / math.sqrt(max(1, len(query_tokens)) * max(1, len(evidence_tokens)))


def _set_overlap(terms: Iterable[str], text: str) -> float:
    term_set = {_normalise_token(term) for term in terms if term}
    if not term_set:
        return 0.0
    evidence = set(tokens(text))
    return len(term_set & evidence) / len(term_set)


def score_evidence(item: EvidenceItem, question: str, intent: QuestionIntent) -> RetrievedEvidence:
    question_tokens = tokens(question)
    evidence_text = f"{item.row_label or ''} {item.metric_text} {item.column_label or ''} {item.text}"
    evidence_tokens = tokens(evidence_text)
    lexical = _weighted_overlap(question_tokens, evidence_tokens)

    metric_score = _set_overlap(intent.metric_terms, f"{item.row_label or ''} {item.metric_text}")
    entity_score = _set_overlap(intent.entity_terms, f"{item.row_label or ''} {item.metric_text}")
    numerator_score = _set_overlap(intent.numerator_terms, f"{item.row_label or ''} {item.metric_text}")
    denominator_score = _set_overlap(intent.denominator_terms, f"{item.row_label or ''} {item.metric_text}")
    role_score = max(numerator_score, denominator_score)

    period_score = 0.0
    if intent.periods:
        if item.period in intent.periods:
            period_score = 1.0
        elif any(period in (item.column_label or "") or period in item.text for period in intent.periods):
            period_score = 0.7
        else:
            period_score = -0.30

    expected = intent.expected_answer_type
    if expected == "percentage":
        type_score = 0.70 if item.is_percent else 0.15
    elif expected == "year":
        type_score = 1.0 if item.is_year else -1.0
    else:
        type_score = 0.20 if not item.is_year else -0.85

    scale_score = 0.0
    if intent.target_scale:
        if item.scale == intent.target_scale:
            scale_score = 0.35
        elif item.scale:
            scale_score = 0.05  # convertible, but not a direct scale match

    source_bonus = 0.28 if item.source_type == "table" else 0.12
    non_year_bonus = 0.12 if not item.is_year or expected == "year" else -0.65
    score = (
        2.4 * lexical
        + 2.5 * metric_score
        + 1.3 * entity_score
        + 1.6 * role_score
        + 1.9 * period_score
        + type_score
        + scale_score
        + source_bonus
        + non_year_bonus
    )
    return RetrievedEvidence(
        item=item,
        score=score,
        lexical_score=lexical,
        period_score=period_score,
        metric_score=max(metric_score, role_score),
        type_score=type_score,
    )


def _row_key(item: EvidenceItem) -> tuple[str, int | None, str]:
    return item.source_type, item.row_index, (item.row_label or item.metric_text or "").lower()


def retrieve_evidence(
    items: Iterable[EvidenceItem],
    question: str,
    intent: QuestionIntent,
    *,
    top_k: int = 16,
    minimum_score: float = -0.35,
) -> list[RetrievedEvidence]:
    """Return a bounded but row-complete evidence set.

    V1 selected individual cells only, so one high-scoring cell could be retained while its
    comparison year or denominator row was pruned. V2 first ranks rows, then expands the
    best rows with requested periods. No references or gold programs are used.
    """

    scored = [score_evidence(item, question, intent) for item in items]
    scored = [entry for entry in scored if entry.score >= minimum_score]
    scored.sort(key=lambda entry: (-entry.score, entry.item.evidence_id))
    if not scored:
        return []

    table_rows: dict[tuple[str, int | None, str], list[RetrievedEvidence]] = defaultdict(list)
    text_entries: list[RetrievedEvidence] = []
    for entry in scored:
        if entry.item.source_type == "table":
            table_rows[_row_key(entry.item)].append(entry)
        else:
            text_entries.append(entry)

    row_rank = sorted(
        table_rows,
        key=lambda key: (
            -max(entry.score for entry in table_rows[key]),
            -sum(max(0.0, entry.metric_score) for entry in table_rows[key]),
            key,
        ),
    )

    selected: dict[str, RetrievedEvidence] = {}
    row_budget = max(4, min(10, top_k // 2 + 1))
    per_row_budget = 5 if len(intent.periods) >= 3 else 4

    for key in row_rank[:row_budget]:
        entries = sorted(table_rows[key], key=lambda entry: (-entry.score, entry.item.evidence_id))
        requested = [entry for entry in entries if entry.item.period in intent.periods]
        # Preserve every explicitly requested period before taking general row values.
        ordered = requested + [entry for entry in entries if entry not in requested]
        for entry in ordered[:per_row_budget]:
            selected[entry.item.evidence_id] = entry

    # Narrative evidence can contain the only direct percentage or constant.
    for entry in text_entries[: max(2, top_k // 5)]:
        selected[entry.item.evidence_id] = entry

    # Fill remaining slots globally. This supports cross-row numerator/denominator pairs.
    for entry in scored:
        if len(selected) >= top_k:
            break
        selected.setdefault(entry.item.evidence_id, entry)

    output = sorted(selected.values(), key=lambda entry: (-entry.score, entry.item.evidence_id))
    return output[:top_k]
