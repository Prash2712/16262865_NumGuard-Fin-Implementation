# Verification outputs

These files record local engineering assurance on transparent, hand-inspectable FinQA-shaped cases. They demonstrate that complete-number parsing, structured provenance, bounded candidate construction, proof verification, sequence locking, result validation and candidate-mechanism perturbations execute as declared.

Contents:

- `dataset_audit.csv` — fixture-level ledger and candidate-recall audit;
- `engineering_checks/` — paired deterministic method records, summaries, nested proof certificates and blinded review files;
- `engineering_check_figures/` — assurance plots generated from the fixtures;
- `counterfactual_audit.csv` — explicitly labelled candidate-mechanism perturbation checks;
- `quality_gate.json` and `LOCAL_VERIFICATION_REPORT.md` — machine-readable and human-readable assurance records;
- `test_run.txt` — captured pytest result.

These are **not empirical dissertation results** and must not be copied into the final findings chapter. Official findings must come from the development and public-test runs under `results/` using the downloaded FinQA files and frozen FLAN-T5 configuration.
