# ProofLock v4 change log

## Trigger

The official v3 development diagnostic passed overall candidate recall (43.40% versus 30%) but failed direct/aggregate recall (68.57% versus 75%). No FLAN-T5 development or public-test run was authorised.

## Evidence and retrieval

- Disambiguated 1900–2099 financial values from actual year-label cells.
- Inherited periods from row or column labels.
- Scored metric/entity/operand-role overlap against both table axes.
- Reserved requested metric columns before broad row completion.
- Expanded frozen retrieval from 24 to 32 items.

## Proof language

- Added column-oriented table sum, average, minimum and maximum.
- Excluded same-axis summary cells from aggregate recomputation.
- Added `aggregate_difference` certificates for max–average, average–min and max–min constructions.
- Added bounded two-step subtract/divide and add/divide forms.
- Increased deployment bounds to 32 direct and 128 derived candidates plus abstention.

## Selection and decoding

- Replaced row-wise candidate classification with within-question pairwise proof ranking.
- Added proof-family indicators and interaction features.
- Added hard selector-guided prefix decoding: illegal tokens remain blocked while legal branches receive a frozen selector prior.
- Retained pure derivation locking as an ablation.
- Risk-controlled output now thresholds the selector-guided hard-lock response.
- Compacted the displayed candidate menu to protect the 512-token input budget.

## Assurance

- Added bidirectional aggregate, summary-cell, composite-proof, weighted-trie and prompt-budget regression tests.
- Increased the suite from 133 to 141 passing tests.
- Preserved all previous scientific gates and public-test integrity checks.
