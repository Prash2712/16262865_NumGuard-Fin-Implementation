# NumGuard-Fin ProofLock v4

**Bidirectional table provenance, pairwise proof ranking and selector-guided whole-sequence decoding for financial question answering.**

Research question:

> Can a table-aware, proof-locked decoding lattice reduce unsupported numerical generation while preserving useful answer coverage and derivation fidelity in financial question answering, without fine-tuning the language model?

## Why v4 exists

The official v3 development candidate gate stopped before FLAN-T5 inference. On 871 numeric FinQA development examples, v3 achieved:

- final candidate recall: **43.40%**, exceeding the 30% overall minimum;
- direct/aggregate reference recall: **68.57%**, below the frozen 75% minimum;
- unpruned same-retrieval recall: **49.25%**;
- expanded-ledger diagnostic recall: **49.71%**.

The remaining direct/aggregate failures were concentrated in table average, sum and maximum questions. The audit also showed that candidate generation and operation-schema coverage, rather than selector pruning, were the largest pre-ranking failure stages. V4 changes those mechanisms while retaining the original gates.

## V4 architecture

For each question, the system constructs:

1. **Structured Financial Evidence Ledger** — raw and canonical values, base value, row, column, period, scale, currency, percentage status and stable source ID.
2. **Bidirectional Table Retrieval** — protected metric rows and metric columns, requested-period completion and role-balanced numerator/denominator slots.
3. **Typed Proof Lattice** — direct lookup, difference, percentage change, ratio, margin, sum, average, product, table sum/average/min/max, indexed return and bounded composite derivations.
4. **Pairwise Candidate Ranker** — a train-only linear selector fitted on within-question positive-versus-hard-negative proof pairs; FLAN-T5 weights remain frozen.
5. **Whole-Sequence Proof Lock** — only prefixes that can terminate as a certified complete answer or exact abstention are legal.
6. **Selector-Guided Proof Lock** — the hard trie guarantee is preserved while admissible branches receive a frozen proof-quality prior.
7. **Proof Certificate and Calibrated Abstention** — every committed answer records its evidence and derivation; semantic and provenance risks are calibrated separately on development.

The frozen deployment lattice is bounded to **32 direct numeric candidates, 128 derived numeric candidates and one exact abstention sequence**.

## Principal v4 corrections

- Financial values such as `2000` are no longer misclassified as calendar years when they occur in metric cells.
- Periods can be inherited from either row labels or column labels.
- Table aggregation operates across both axes, not only metric-in-row tables.
- Precomputed `Total`, `Average`, `Maximum` and `Minimum` cells are excluded from same-axis recomputation to prevent double counting.
- Aggregate composites such as `max − average` receive explicit proof certificates.
- Requested metric columns are protected before broad row completion can exhaust the retrieval budget.
- Candidate prompts display a compact top-ranked menu instead of allowing hundreds of verbose proof strings to consume the 512-token input budget.
- Candidate ranking optimises within-question preference rather than only candidate-level classification.
- Risk-controlled decoding uses the selector-guided hard lock, while the pure derivation lock remains as an ablation.

## Experimental conditions

The paired experiment contains 13 methods:

1. `baseline`
2. `provenance_prompt`
3. `candidate_menu_prompt`
4. `posthoc_verifier`
5. `fragment_token_lock_ablation`
6. `soft_prefix_bias_1`
7. `soft_prefix_bias_3`
8. `soft_prefix_bias_5`
9. `soft_prefix_bias_10`
10. `direct_proof_lock`
11. `derivation_proof_lock`
12. `selector_guided_proof_lock`
13. `risk_controlled_proof_lock`

## Frozen split protocol

- **FinQA train:** fit the lightweight pairwise candidate selector.
- **FinQA development:** run the candidate-quality gate, paired model experiment and semantic/provenance calibration.
- **FinQA public test:** execute once only after the development script prints the explicit authorisation line.

Reference answers and programs are never exposed to retrieval, candidate construction, prompts or decoding. They are used only after lattice construction for train labels or development/test evaluation.

## Local engineering verification

```bash
python -m pip install -r requirements.txt
python -m pip install -e . --no-deps
bash run_local_verification.sh
```

Required engineering status:

```text
141 passed
QUALITY GATE PASSED
```

Then remove generated editable-install metadata and verify the source manifest:

```bash
rm -rf src/numguard_fin.egg-info
python scripts/verify_source_manifest.py
```

Engineering fixtures establish mechanical integrity only. They are not official FinQA/FLAN-T5 results.

## Official execution

Follow `RUN_IN_COLAB.md` or `notebooks/NumGuard_Fin_Colab.ipynb`:

```text
engineering verification
→ official FinQA download and CUDA preflight
→ fresh v4 selector fit on train
→ development candidate gate
→ development model experiment only if the gate passes
→ semantic and provenance calibration
→ public test only after explicit authorisation
```

Do not copy v1, v2 or v3 selectors, checkpoints, calibration files or results into v4.

## Scientific claim boundary

A hard proof lock guarantees membership in the certified answer lattice, not semantic correctness. A source-linked value can still answer the wrong row, year, metric, unit or operation. Final reporting must therefore distinguish:

- **provenance risk:** whether a committed answer lacks a valid certificate;
- **semantic risk:** whether the committed numeric answer is wrong for the question.

No universal-safety, regulatory-compliance or production-readiness claim is supported.
