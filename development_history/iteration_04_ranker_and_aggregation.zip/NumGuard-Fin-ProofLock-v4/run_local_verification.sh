#!/usr/bin/env bash
set -euo pipefail
export PYTHONPATH="${PYTHONPATH:-}:src"
mkdir -p verification
pytest -q | tee verification/test_run.txt
python scripts/run_engineering_verification.py
python scripts/quality_gate.py
