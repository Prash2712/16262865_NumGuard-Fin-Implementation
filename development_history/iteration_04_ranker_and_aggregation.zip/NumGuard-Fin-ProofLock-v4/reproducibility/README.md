# Reproducibility records

Empirical runs write their own `experiment_manifest.json` into the relevant result directory. The manifest records dataset checksum, split, model revision when available, hardware selection, dependency versions, seed, threshold, configuration hash and command invocation.

`frozen_experiment_plan.json` records the pre-specified final design. `source_manifest.sha256` records the package file hashes at delivery.

Verify delivered source and documentation files with:

```bash
python scripts/verify_source_manifest.py
```

Runtime outputs, downloaded data and engineering verification files are intentionally excluded from the source manifest.
