# Decision log

## Frozen design decisions for v4

1. The language model remains `google/flan-t5-base`; no model fine-tuning is performed.
2. FinQA train is used only to fit the candidate selector.
3. FinQA development is used for the candidate gate, paired model evaluation and calibration.
4. FinQA public test is executed once only after explicit development authorisation.
5. Retrieval is bounded to 32 evidence items with protected row, column, role and period slots.
6. The deployment lattice is bounded to 32 direct candidates, 128 derived candidates and one abstention.
7. The selector objective is within-question pairwise proof ranking with 24 hard negatives per positive and grouped cross-validation by source report.
8. Pure whole-sequence locking and selector-guided whole-sequence locking are reported separately.
9. Selector-guided locking uses a frozen proof prior strength of 2.0 and cannot admit tokens outside the certified trie.
10. Semantic calibration uses `selector_guided_proof_lock`, target risk 0.20, 95% one-sided confidence, minimum coverage 0.05 and minimum 30 accepted examples.
11. Provenance calibration is reported separately at target risk 0.01 under the same coverage/sample gates.
12. Candidate gates remain 0.30 overall recall and 0.75 direct/aggregate recall; they were not lowered after v1–v3 diagnostics.
13. Maximum input length remains 512 tokens; only a compact top-24 candidate display is placed in the prompt while the decoder enforces the full lattice.
14. Reference answers/programs never enter inference-time retrieval, candidate construction, prompting or decoding.
15. Any source-code, selector, configuration or calibration change after test execution creates an exploratory run rather than replacing the frozen result.

## Development evidence retained

- V1: proof-lock safety effect but low semantic quality and zero feasible coverage.
- V2: failed candidate gate at 27.44% overall and 45.71% direct/aggregate recall.
- V3: passed overall recall at 43.40% but failed direct/aggregate recall at 68.57%.

These diagnostics motivate v4 but are not public-test findings.
