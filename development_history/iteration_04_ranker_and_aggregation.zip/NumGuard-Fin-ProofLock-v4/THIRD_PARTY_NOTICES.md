# Third-party notices

This project can download and evaluate the FinQA dataset and the `google/flan-t5-base` model. They are not distributed in this archive. Their respective repository, model card and licence terms govern use.

Primary research references are listed in `reports/literature_positioning.md`.
