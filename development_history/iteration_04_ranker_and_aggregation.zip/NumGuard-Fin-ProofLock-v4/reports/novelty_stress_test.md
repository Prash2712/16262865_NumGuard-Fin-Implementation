# Novelty stress test

This document records the strongest challenge to the proposed contribution and the defensible boundary that remains.

| Prior direction | What it already establishes | What NumGuard-Fin must not claim | Remaining distinction tested here |
|---|---|---|---|
| FinQA | Structured financial tables and annotated programs | A new financial QA benchmark or new program annotations | Safety intervention over the existing benchmark |
| PICARD | Incremental rejection of inadmissible decoder tokens | Invention of constrained decoding | Input-dependent grammar of certified complete numeric answers |
| KCTS | Knowledge-constrained inference for frozen models | First inference-time hallucination control | Deterministic financial proof candidates and certificate-level evaluation |
| Selective QA | Risk–coverage evaluation and abstention | Invention of calibrated refusal | Applying frozen development calibration to proof-locked financial answers |
| RobuT / table robustness work | Controlled table perturbations | First counterfactual table audit | Separate candidate-mechanism and actual model-output provenance audits tied to certificates |
| FAITH / HalluBench | Financial hallucination evaluation and detection | First finance-specific hallucination taxonomy | Prevention relative to a proof lattice rather than detection after free generation |
| FinCARDS | Finance-aware structured evidence constraints | First auditable financial retrieval | Decoder enforcement over complete answers with source claims |
| FIND | Constraint-aware financial reasoning with model adaptation | First constrained financial reasoner | No fine-tuning; frozen-model inference layer |
| DCRC | Trained structuring agent, executable programs and adversarial financial reasoning compilation | First verifiable program-based financial QA system | Lightweight deterministic proof lattice and whole-sequence answer lock without training |

## Defensible novelty statement

> This study evaluates whether a frozen sequence-to-sequence model can be wrapped with a deterministic, table-aware proof language that constrains the decoder to certified complete numeric answers or explicit abstention, and whether that mechanism remains evidence-sensitive under controlled financial table perturbations.

## Falsification conditions

The contribution is not supported if any of the following occurs:

- hard locks emit uncertified complete answers;
- candidate recall is too low for the mechanism to preserve useful coverage;
- fragment masking performs equivalently to sequence locking without observable escapes;
- calibrated abstention does not lower committed-answer risk on the frozen test split;
- model-output counterfactual behaviour does not follow period, metric, support or scale changes;
- the safety improvement is achieved only through near-total abstention.

A null result on one or more hypotheses remains a legitimate dissertation finding if the mechanism, evaluation and failure analysis are reported accurately.
