# ProofLock v2 development candidate-gate findings

## Status

This is development evidence, not public-test evidence. The gate ran on 871 numeric examples from the official FinQA development split and stopped before FLAN-T5 inference.

## Frozen v2 result

| Metric | Observed | Required | Decision |
|---|---:|---:|---|
| Final candidate recall | 27.44% | 30.00% | Fail |
| Direct/aggregate reference recall | 45.71% | 75.00% | Fail |
| Expanded-ledger diagnostic recall | about 30.5% | Diagnostic only | — |

The public test remained blocked.

## Diagnosed mechanisms

1. **Operation classification:** ratio wording containing “average” was sometimes classified as average; percentage-of-total wording containing “increase” was sometimes classified as difference; cumulative stock-return questions lacked a dedicated indexed-return template; some cross-period totals remained direct lookup.
2. **Retrieval truncation:** v2 inserted row-complete evidence and then globally sorted and truncated the provisional set, allowing requested-period or denominator cells to be removed.
3. **Premature pruning:** heuristic candidate bounds were applied before learned selector rescoring, so the selector could not recover a correct candidate that had already been removed.
4. **Operation monopolisation:** prolific ratio or percentage families could consume the derived budget and displace a unique average, sum or indexed-return answer.
5. **Failure attribution:** v2 reported final and full-ledger recall but did not separate extraction, retrieval, operation-schema, candidate-construction and selector failures.

## V3 response

V3 changes the mechanism while retaining the original scientific gates. It adds role-balanced retrieval, a question-licensed operation portfolio, indexed-return derivation, selector-before-pruning ordering, operation-diverse pruning and multi-stage candidate diagnostics.

No claim that v3 passes the official development gate is made until a new train-selector and development-gate run is completed from the clean v3 package.
