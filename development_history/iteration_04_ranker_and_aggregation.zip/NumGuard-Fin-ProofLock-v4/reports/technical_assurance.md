# Technical assurance

## Defects explicitly prevented

- Four-digit years and long integers are parsed as complete spans.
- Leading decimals remain decimals.
- Signs, accounting parentheses, percent markers, currency and scale are retained.
- Percentage values do not inherit monetary scale.
- Table retrieval preserves row, column, period and operand roles across both table orientations.
- Financial values between 1900 and 2099 are not discarded as years unless the table structure assigns a period role.
- Same-axis atomic values are not recombined with a precomputed summary cell.
- Hard decoding admits complete candidate sequences, not an unrestricted union of digit fragments.
- Typed derivations are question-conditioned and bounded.
- Base-unit arithmetic is used for scale-aware ratios; displayed conventions are retained for answers.
- Percentage-by-amount products convert percentages to fractions.
- Arbitrary constants are not enumerated.
- Proof certificates contain complete evidence claims.
- Numbers embedded in prose are rejected as invalid complete answers.
- No-number outputs are not awarded proof validity.
- Reference answers are absent from inference-time retrieval, prompts, candidate construction and decoding.
- The selector uses train labels only and its hash is stored in the run manifest.
- Semantic and provenance risks are recorded separately.
- Zero-coverage or infeasible calibration blocks the public test.
- Prompt token counts, truncation and end-to-end latency are recorded.
- Resume checkpoints require the same configuration ID.
- Submission-facing outputs exclude legacy fields.

## Proof certificate fields

A committed answer records:

- complete response and decision;
- candidate identifier, score and score margin;
- proof type, operation and expression;
- answer type;
- ordered evidence claims with values, source type, row, column, metric, period, scale, currency and source ID;
- selector/configuration provenance where applicable.

CSV and Excel store a serialised certificate; JSONL stores the nested object.

## Selector assurance

The candidate selector has a fixed v4 feature schema and deterministic training seed. It is fitted on a two-times wider pre-pruning train candidate pool using balanced within-question positive-versus-hard-negative proof pairs. Grouped cross-validation is performed by source report. Its report records candidate rows, pairwise rows, positive rows, candidate recall, out-of-fold top-1 accuracy given recall and fold-level metrics. These training diagnostics are not public-test performance.

The selector-guided logits processor applies negative infinity to every illegal token exactly as the pure trie lock does. Its selector prior changes only the relative scores of legal branches, so ranking guidance cannot create a constraint escape.

## Calibration assurance

Calibration reports feasibility, accepted count, coverage, observed risk and a one-sided upper confidence bound. When no operating point satisfies the risk, coverage and sample-size gates, the output records `feasible: false` and the public-test script terminates.

## Local verification boundary

The packaged verification run uses transparent fixtures and a deterministic engineering selector. It tests implementation behaviour only. It does not claim official FinQA or FLAN-T5 performance.

## Reproducibility record

Each empirical run records:

- dataset path and SHA-256;
- ordered example IDs and digest;
- split and eligible example count;
- model name and resolved revision where available;
- selector path and SHA-256;
- hardware, CUDA and package versions;
- seed and deterministic settings;
- prompt and generation limits;
- candidate bounds and risk threshold;
- configuration hash and command;
- checkpoints and final manifest.
