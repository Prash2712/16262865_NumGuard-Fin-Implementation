# Development diagnostic v3 findings

## Status

The official FinQA development candidate gate executed on 871 numeric examples and stopped before FLAN-T5 inference. This is development evidence, not a public-test result.

## Frozen v3 results

| Measure | Result | Gate |
|---|---:|---:|
| Final candidate recall | 43.40% | ≥30% — pass |
| Pre-selector recall | 39.95% | diagnostic |
| Unpruned recall using the same retrieval | 49.25% | diagnostic |
| Expanded-ledger recall | 49.71% | diagnostic |
| Direct/aggregate reference recall | 68.57% | ≥75% — fail |

Failure-stage counts were:

- candidate generation: 238;
- operation schema: 110;
- retrieval or bounded context: 42;
- retrieval: 42;
- extraction/program constant: 30;
- bounded pruning: 28;
- selector ranking: 3.

## Interpretation

The v3 mechanism materially improved candidate availability over v2, but the direct/aggregate gate remained six percentage points below its frozen minimum. Only three failures were attributed to selector ranking at the recall stage. Most remaining misses occurred before final ranking, especially in candidate construction and question-operation schema coverage.

The failed aggregate cases included table averages, sums and maxima whose metric values could be arranged vertically rather than horizontally. Values in the 1900–2099 range could also be mistaken for years even when they were financial amounts. Composite questions such as the difference between the average and highest value required an explicit second-stage proof.

## V4 response

V4 introduces bidirectional table aggregation, structural year/value disambiguation, summary-cell exclusion, aggregate-comparison proofs, protected metric columns and a larger but still bounded lattice. It also improves downstream answer selection with a pairwise proof ranker and selector-guided hard decoding.

No claim that v4 passes the official development gate is made until a fresh train-selector and development-gate run is completed from the clean v4 package.
