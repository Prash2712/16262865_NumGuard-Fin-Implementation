# Research design

## Aim and research question

NumGuard-Fin ProofLock v4 evaluates whether a table-aware, proof-locked decoding lattice can reduce unsupported numerical generation while preserving useful answer coverage and derivation fidelity in financial question answering, without fine-tuning the language model.

The intervention is inference-time only. Within each paired comparison, the model, FinQA example, seed and output budget remain fixed while the answer-control mechanism changes.

## Development history

V1 established that complete-answer locking can prevent outputs outside a certified lattice, but its shallow candidate generator and heuristic confidence score produced low useful coverage. V2 introduced typed derivations and a train-only selector, yet failed its development candidate gate at 27.44% overall recall and 45.71% direct/aggregate recall. V3 improved overall recall to 43.40%, above the frozen 30% minimum, but direct/aggregate recall reached only 68.57% against the unchanged 75% minimum.

V4 responds to the observed v3 failure mechanisms: table-axis asymmetry, year/value ambiguity, aggregate summary double counting, missing aggregate composites, verbose candidate prompts and a selector objective misaligned with within-question ranking. Earlier diagnostics are preserved as development evidence and excluded from public-test claims.

## Architecture

### 1. Structured financial evidence ledger

Each number retains its source type, raw and canonical form, base-unit value, percentage status, table coordinates or narrative offsets, row and column labels, period, scale, currency and stable evidence ID.

A table value between 1900 and 2099 is treated as a year only when the table structure assigns it a period role. This prevents values such as 2,000 from being discarded as dates. Periods can be inherited from either table axis.

### 2. Bidirectional, question-conditioned retrieval

The intent parser identifies a bounded operation portfolio, metric/entity terms, numerator and denominator roles, requested periods, target scale, aggregation cues and question-licensed constants.

Retrieval protects:

- numerator and denominator rows;
- high-scoring metric columns;
- all requested-period cells for a protected axis;
- narrative values that may contain percentages or explicit constants.

Only then does global filling occur. This prevents row-first insertion from exhausting the budget before a metric-in-column table is completed.

### 3. Bounded typed proof language

The proof lattice includes:

- direct lookup;
- subtraction and absolute difference;
- percentage change and indexed return;
- ratio and percentage-of-total/margin;
- pairwise and n-ary sum/average;
- product, including percentage-by-amount calculations;
- row- or column-based table sum, average, minimum and maximum;
- aggregate composites such as maximum minus average;
- bounded two-step subtract/divide and add/divide forms;
- question-licensed constants and period counts.

Precomputed total, average, minimum or maximum cells are not recombined with their same-axis atomic cells. A direct lookup of such a summary remains available.

The frozen deployment bound is 32 direct and 128 derived numeric candidates plus exact abstention. This is not unrestricted arithmetic closure.

### 4. Pairwise candidate selector

The selector is fitted only on FinQA train after candidate construction. Its linear score uses retrieval, metric, period, role, type, proof-family, depth, magnitude and interaction features. It is trained on within-question positive-versus-hard-negative differences, which directly targets proof ranking rather than global candidate classification.

Grouped cross-validation is organised by source report/document. Reference answers provide train labels only; they are never used during inference-time evidence retrieval, proof construction, prompting or decoding.

### 5. Whole-sequence and selector-guided proof locks

The pure proof lock encodes every certified answer as a complete token sequence in a prefix trie. A next token is legal only when the resulting prefix can terminate as a certified answer or the exact abstention response.

The selector-guided lock preserves the same hard mask but adds a frozen log-prior among legal branches based on maximum selector confidence among their completions. Thus:

- trie membership controls provenance admissibility;
- the train-only selector influences ranking among admissible answers;
- FLAN-T5 weights remain unchanged.

Fragment-level token masking is retained only as a deliberately weak ablation.

### 6. Prompt-budget control

Retrieval and proof construction may operate over the full frozen bounds, but the visible model prompt contains only a compact top-ranked evidence/candidate display. This prevents verbose proof expressions from consuming the 512-token input budget while the decoder still enforces the complete lattice.

### 7. Separate risk controls

Two risks are reported separately:

- **semantic risk:** the committed answer is numerically wrong for the question;
- **provenance risk:** the committed answer lacks a valid certificate.

Development calibration is feasible only when its upper confidence bound satisfies the stated risk target with at least 5% coverage and 30 accepted examples. Zero-coverage or infeasible calibration blocks public-test execution.

## Split discipline

- **Train:** selector fitting only.
- **Development:** candidate-quality gate, paired model experiment and calibration.
- **Public test:** one frozen execution after explicit authorisation.

No test result may be used to revise the method.

## Hypotheses

- H1: whole-sequence locking reduces unsupported complete-answer generation relative to unconstrained generation.
- H2: whole-sequence locking produces fewer escapes than fragment-token masking.
- H3: v4 bidirectional aggregation raises direct/aggregate candidate recall relative to the frozen v3 development diagnostic.
- H4: pairwise proof ranking improves answer selection conditional on candidate availability.
- H5: selector-guided hard decoding improves semantic accuracy over the pure derivation lock without weakening provenance guarantees.
- H6: development-calibrated abstention reduces semantic risk at measurable non-zero coverage.
- H7: proof-carrying outputs respond correctly to period, metric, support and scale perturbations while remaining invariant to irrelevant-number injection.

## Interpretive limits

A proof-valid answer can still be semantically incorrect because the wrong evidence, operation, period, unit or scale was certified. Results apply only to the disclosed data splits, models, prompts, proof grammar, bounds and thresholds. The artefact does not establish universal factuality, regulatory compliance or production readiness.
