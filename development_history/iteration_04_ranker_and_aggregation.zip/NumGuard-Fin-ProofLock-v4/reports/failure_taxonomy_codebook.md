# Manual failure taxonomy codebook

The generated `failure_review_blinded.xlsx` is the manual coding sheet. It deliberately omits the method name and automatic routing suggestion. Those fields are stored in `failure_review_key.csv` and should remain hidden during first-pass review. Automatic suggestions are triage aids, not confirmed labels.

## Retrieval and evidence

- `retrieval_wrong_metric`: relevant value exists but another row or sentence is prioritised.
- `retrieval_wrong_period`: evidence from the wrong fiscal period is prioritised.
- `retrieval_missing_support`: required evidence is not retrieved.
- `scale_or_currency_extraction`: scale or currency propagation is incorrect.
- `numeric_span_extraction`: a numeric span is missed or parsed incorrectly.

## Question interpretation

- `operation_schema_error`: lookup/change/ratio/margin/etc. is misclassified.
- `operand_order_error`: old/new, numerator/denominator or minuend/subtrahend is reversed.
- `metric_role_error`: numerator, denominator or component role is wrong.

## Candidate construction

- `candidate_recall_failure`: the reference value cannot be produced by the lattice.
- `invalid_derivation`: a candidate uses an unjustified operation or incompatible operands.
- `rounding_tolerance_error`: a mathematically compatible value is mismatched by the declared rounding rule.

## Selection and decoding

- `ranking_error`: the reference is in the lattice but another candidate is selected.
- `fragment_constraint_escape`: the fragment-level ablation recombines tokens into an uncertified answer.
- `invalid_or_fragmentary_response`: output is not a complete single numeric answer.
- `over_refusal`: the system abstains when the reference is available in the lattice.
- `under_refusal`: the system commits despite absent or invalid support.

## Dataset and ambiguity

- `annotation_issue`: reference answer, program or support appears inconsistent.
- `question_ambiguity`: multiple interpretations are defensible.
- `insufficient_document_evidence`: supplied evidence does not support the reference.

## Review procedure

1. Keep `failure_review_key.csv` closed during first-pass coding.
2. Inspect the question, structured evidence claims, candidate proof and reference.
3. Assign one primary category and optional explanatory notes.
4. Record the exact evidence location and reviewer confidence.
5. Mark ambiguous cases for second review rather than forcing a label.
6. Double-code a predeclared subset and report agreement.
7. Join the key only after manual labels are frozen.
8. Report denominators and uncertainty; do not present automatic suggestions as observations.
