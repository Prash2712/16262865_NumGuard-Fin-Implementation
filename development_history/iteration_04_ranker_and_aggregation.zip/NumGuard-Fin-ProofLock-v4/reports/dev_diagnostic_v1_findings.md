# Development diagnostic v1: findings and redesign decision

## Status

This is a preserved **development diagnostic**, not the frozen public-test evidence. It used the official FinQA development split and was completed before the v2 architecture was designed.

## Run integrity

- 871 eligible numeric development examples;
- 12 paired methods;
- 10,452 prediction rows;
- one configuration ID;
- complete logs, method summaries, paired comparisons and calibration outputs retained in `NumGuard_Dev_Diagnostic_v1.zip`;
- archive SHA-256: `f1745aa8e00c8b5a9754e8f222d036aec961cdeffc6693577c1b5aab13510092`.

## Principal findings

The whole-sequence lock substantially reduced unsupported complete answers, showing that the trie mechanism enforced membership in the candidate lattice. However, the candidate lattice and selection mechanism were inadequate for semantic correctness.

Representative development results:

| Method | Numeric accuracy | Valid numeric response | Unsupported complete answer | Candidate recall |
|---|---:|---:|---:|---:|
| Baseline | 1.26% | 63.26% | 19.40% | 12.17% |
| Candidate-menu prompt | 1.95% | 97.59% | 3.10% | 12.17% |
| Direct proof lock | 0.92% | 96.21% | 0.00% | 2.99% |
| Derivation proof lock | 1.95% | 98.62% | 0.34% | 12.17% |
| Post-hoc verifier | 0.92% | 43.86% | 0.00% | 12.17% |

For the derivation proof lock, selection accuracy conditional on the correct candidate being present was approximately 16.04%. Proof validity among numeric responses was high, but this represented structural certificate validity rather than semantic question correctness.

## Calibration failure

Semantic calibration selected an infeasible sentinel threshold of `1.000001`, accepted zero examples and produced zero coverage. The confidence score did not identify a sufficiently accurate high-confidence subset under the declared 20% semantic-risk target.

This outcome is not interpreted as zero-risk success. It means that no useful operating point was found.

## Diagnosed causes

1. The lattice was dominated by direct values and one-step binary arithmetic.
2. Multi-stage FinQA operations such as subtract-then-divide, ratio-to-percentage and n-ary aggregation were frequently absent.
3. Retrieval did not preserve row/column/period roles strongly enough.
4. The heuristic confidence score was weakly related to correctness.
5. A proof could be valid for the generated candidate while the candidate used the wrong row, period, operand or operation.

## V2 response

V2 introduces:

- row-complete, role-aware retrieval;
- a typed multi-step financial proof language;
- n-ary aggregation and question-licensed constants;
- a train-fitted candidate correctness selector;
- explicit candidate-recall and direct/aggregate-recall gates;
- separate semantic and provenance risk controls;
- minimum coverage and accepted-sample gates;
- automatic public-test blocking when development evidence is inadequate.

## Scientific interpretation

The diagnostic supports a narrow conclusion: **sequence-level proof locking can prevent answers outside a certified lattice, but provenance membership alone does not guarantee semantic correctness.** Final claims about v2 effectiveness remain conditional on a new frozen train/development/public-test execution.
