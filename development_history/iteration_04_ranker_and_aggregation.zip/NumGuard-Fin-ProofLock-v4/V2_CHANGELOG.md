# ProofLock v2 change log

## Reason for revision

The v1 development diagnostic showed strong lattice-membership enforcement but low candidate recall, weak conditional selection and infeasible zero-coverage semantic calibration. The public test was therefore not run.

## Architecture changes

- Replaced isolated-cell retrieval with row-complete, period-aware and operand-role-aware retrieval.
- Expanded question intent with aggregation, scale, period-count, constant and numerator/denominator cues.
- Added bounded typed derivations for ratio-to-percentage, percentage change, margin, n-ary sum/average, min/max and percentage-by-amount products.
- Corrected percentage scale inheritance and scale-aware arithmetic.
- Increased the frozen candidate budget to 16 direct + 48 derived + one abstention.
- Added structured candidate features and a train-fitted logistic selector.
- Added selector hash to experiment configuration and manifests.
- Added semantic and provenance risk scores and candidate score margins to prediction records.

## Evaluation changes

- Added a train-only selector-fitting stage with grouped cross-validation diagnostics.
- Added a cheap development candidate-quality gate before model inference.
- Separated semantic-risk and provenance-risk calibration.
- Added minimum coverage and minimum accepted-example requirements.
- Added automatic public-test blocking for infeasible calibration.
- Preserved v1 results as diagnostic evidence rather than rewriting or discarding them.

## Assurance changes

- Added v2 proof-language and calibration tests.
- Increased the engineering test suite from 111 to 121 tests.
- Retained whole-sequence constraint, certificate and counterfactual checks.
- Updated research, execution, claim-control and reproducibility documentation.
