# ProofLock v3 change log

## Trigger

ProofLock v2 failed its frozen FinQA development candidate-quality gate: 27.44% overall candidate recall and 45.71% direct/aggregate recall. The model experiment and public test were correctly blocked.

## Retrieval

- Replaced provisional row completion followed by global re-truncation with priority-preserving selection.
- Protected numerator and denominator rows.
- Protected all requested-period cells for high-ranked metric rows.
- Expanded the default evidence budget from 16 to 24 items.
- Added row-phrase, role, metric, period, type and scale scoring signals.

## Intent and proof language

- Corrected `per transaction` and similar wording to ratio before broad average matching.
- Corrected `as a percentage of` to margin/percentage-of-total before generic difference matching.
- Added cumulative indexed-return intent and `value - 100` proof template.
- Improved cross-period sum, average, min and max wording.
- Added bounded alternative operation families derived only from explicit question cues.

## Candidate construction and selection

- Increased frozen bounds to 24 direct and 96 derived candidates plus abstention.
- Retained direct candidates for reports that explicitly state a requested ratio, margin or change.
- Fitted the selector on a wider pre-pruning candidate pool and applied learned rescoring before heuristic floors and frozen deployment pruning.
- Added operation-diverse round-robin reservations before global derived-candidate fill.
- Increased row-complete and n-ary aggregate opportunities while retaining hard caps.

## Diagnostics

The development candidate audit now reports:

- final frozen-lattice recall;
- pre-selector recall;
- unpruned recall using the same retrieved evidence;
- full-ledger diagnostic recall;
- reference-operand coverage in the ledger and retrieval set;
- intent/reference-operation compatibility;
- a failure-stage label.

Gold programs and answers are used only after candidate construction for diagnostics; they remain isolated from inference.

## Assurance

- Added twelve v3 regression tests, increasing the suite from 121 to 133 tests.
- Updated candidate-bound validation to 24 + 96 + abstention.
- Updated documentation, frozen plan, notebook and source manifest.
