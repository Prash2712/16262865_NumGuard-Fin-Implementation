# Delivery notes — ProofLock v4

## Delivered artefact

This is a clean v4 implementation containing source code, 141 tests, transparent fixtures, Colab scripts, research documentation and local engineering-assurance outputs. It excludes official FinQA files, model weights, prior-version selectors/checkpoints and manufactured empirical findings.

## Evidence that triggered v4

The official v3 development candidate gate reported 43.40% overall candidate recall and 68.57% direct/aggregate recall. The overall gate passed, but the frozen 75% direct/aggregate gate failed. The public test was correctly blocked.

The v3 failure archive showed that the remaining aggregate misses were dominated by candidate generation and table-orientation problems. V4 therefore changes table interpretation, candidate construction and selection; it does not weaken the thresholds.

## V4 changes

- bidirectional row/column aggregate retrieval;
- context-sensitive year/value disambiguation;
- row- or column-derived periods;
- summary-cell double-count protection;
- explicit aggregate-comparison proofs;
- bounded two-step ratio/change programs;
- 32 direct + 128 derived + abstention frozen deployment bounds;
- compact prompt menus to protect the model input budget;
- train-only pairwise proof ranker with grouped cross-validation;
- selector-guided hard prefix decoding as a separate method;
- semantic calibration based on the selector-guided proof lock;
- v3 diagnostic report and new regression tests.

## Local verification boundary

Local execution verifies parser, ledger, retrieval, candidate construction, trie legality, proof certificates, pairwise method output, perturbation behaviour, reports and package integrity. It does not establish v4 FinQA candidate-gate performance or model accuracy.

## Student execution rule

Fit a fresh v4 selector and run the development gate. Do not run public-test inference unless `run_colab_dev.sh` ends with:

```text
SEMANTIC CALIBRATION GATE PASSED. The frozen public-test script is now authorised.
```

A failed candidate or calibration gate must be preserved and reported rather than bypassed.
