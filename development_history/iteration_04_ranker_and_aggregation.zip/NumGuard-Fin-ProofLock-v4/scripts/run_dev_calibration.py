import json
from pathlib import Path

from numguard_fin.cli import main

selector = Path("models/candidate_selector.json")
if not selector.exists():
    raise SystemExit(
        "Missing models/candidate_selector.json. Run bash run_colab_train_selector.sh first."
    )

# Cheap CPU gate before any full model inference. References are used only for this
# development diagnostic, never for candidate construction or decoding.
gate = [
    "inspect", "--data-dir", "data/raw", "--split", "dev",
    "--retrieval-top-k", "32", "--max-direct-candidates", "32",
    "--max-derived-candidates", "128",
    "--selector-file", str(selector),
    "--minimum-candidate-recall", "0.30",
    "--minimum-direct-recall", "0.75",
    "--enforce-gates",
    "--output", "results/dev_candidate_diagnostic/dataset_audit.csv",
]
if main(gate):
    raise SystemExit(2)

run = [
    "run", "--data-dir", "data/raw", "--split", "dev",
    "--model-name", "google/flan-t5-base", "--device", "cuda",
    "--retrieval-top-k", "32", "--max-direct-candidates", "32",
    "--max-derived-candidates", "128", "--seed", "42",
    "--selector-file", str(selector),
    "--resume",
    "--output-dir", "results/dev_calibration", "--figures-dir", "figures/dev_calibration",
]
if main(run):
    raise SystemExit(1)

semantic = [
    "calibrate", "--predictions", "results/dev_calibration/predictions.csv",
    "--method", "selector_guided_proof_lock", "--risk-type", "semantic",
    "--target-risk", "0.20", "--confidence", "0.95",
    "--minimum-coverage", "0.05", "--minimum-accepted", "30",
    "--output", "results/dev_calibration/calibration.json",
]
if main(semantic):
    raise SystemExit(1)

provenance = [
    "calibrate", "--predictions", "results/dev_calibration/predictions.csv",
    "--method", "selector_guided_proof_lock", "--risk-type", "provenance",
    "--target-risk", "0.01", "--confidence", "0.95",
    "--minimum-coverage", "0.05", "--minimum-accepted", "30",
    "--output", "results/dev_calibration/provenance_calibration.json",
]
if main(provenance):
    raise SystemExit(1)

payload = json.loads(Path("results/dev_calibration/calibration.json").read_text())
if not payload.get("feasible", False):
    raise SystemExit(
        "SEMANTIC CALIBRATION GATE FAILED. Public test remains blocked. "
        "Upload results/dev_candidate_diagnostic and results/dev_calibration for review."
    )
print("SEMANTIC CALIBRATION GATE PASSED. The frozen public-test script is now authorised.")
