# NumGuard-Fin Implementation

**Student:** Prasanth Balisetty  
**Student ID:** 16262865  
**Module:** 7005SCN Individual Research Project

This repository contains the technical implementation for provenance-constrained numerical decoding in financial question answering. The language model is kept frozen. A source-conditioned candidate lattice, proof certificates and a complete-answer trie restrict numerical outputs to values admitted by the implemented evidence policy.

## Repository structure

- `src/numguard_fin/` — reusable Python package.
- `scripts/` — dataset download, training, evaluation, calibration, packaging and validation commands.
- `notebooks/` — clean Google Colab workflow.
- `data/fixtures/` — transparent synthetic fixtures used for technical validation.
- `models/` — fitted candidate selector and its training summary.
- `results/` — stored development evidence and a separate location for a fresh rerun.
- `validation/` — unit, integration, counterfactual and package-hygiene checks.
- `reproducibility/` — experiment plan and source-file checksums.

## Stored development evidence

The retained FinQA development run contains 871 numerical examples evaluated under 13 methods, giving 11,323 paired prediction records. The unconstrained baseline answered 6 examples correctly and produced 46 complete numerical outputs rejected by the implemented certificate policy. Selector-guided ProofLock answered 14 examples correctly and produced no certificate-invalid complete numerical outputs. Candidate recall was 424/871. The semantic calibration gate was infeasible, so the public test was not executed.

These findings support a narrow conclusion: complete-answer constraints enforced the implemented provenance rule, but they did not establish reliable financial reasoning.

## Local validation

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
pip install -e . --no-deps
bash run_validation.sh
```

The supplied package passes 145 automated tests and additional checks covering transparent fixtures, counterfactual perturbations, result integrity, source checksums, strict JSON, metadata hygiene and repository cleanliness.

## Full Colab rerun

Upload this folder to Google Drive as `NumGuard-Fin-Implementation`, open `notebooks/NumGuard_Fin_Colab.ipynb`, select a T4 GPU runtime and execute the cells in order. Fresh outputs are written under `results/rerun/`; the retained development evidence under `results/development/` is not overwritten. The public-test command remains blocked when semantic calibration is infeasible.

## Git preparation

Raw FinQA files, model downloads, checkpoints, virtual environments, caches and duplicate exports are excluded by `.gitignore`. The fresh rerun results remain available for review and can be committed after they have been checked.

```bash
git init
git add .
git commit -m "Add NumGuard-Fin implementation and reproducibility evidence"
```

## Reproducibility boundary

FinQA files and model weights are not redistributed. They are downloaded by the supplied scripts. Stored development results are retained as evidence, while a new run creates separate manifests, logs, checksums and a compact rerun-evidence ZIP.
